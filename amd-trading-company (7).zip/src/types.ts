/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ActivePage = 'home' | 'products' | 'about' | 'why-choose-us' | 'contact' | 'shop' | 'admin' | 'workspace-chat';

export interface Order {
  id: string;
  date: string;
  productName: string;
  packetSize: string;
  quantity: number;
  pricePerUnit: number;
  totalPrice: number;
  customerName: string;
  customerPhone: string;
  customerEmail?: string;
  address: string;
  pincode: string;
  city: string;
  state: string;
  status: 'Pending' | 'Shipped' | 'Delivered' | 'Cancelled';
  subTotal?: number;
  deliveryCharge?: number;
  gstNumber?: string;
}

export interface MakhanaSize {
  size: string; // "3mm", "4mm", "5mm", "3+ mm", "4+ mm", "5+ mm", "6+ mm"
  diameter: string;
  premiumGrades: string[];
  bestFor: string;
  description: string;
}

export interface BrandDetails {
  id: 'shuddh' | 'rozana';
  name: string;
  tagline: string;
  description: string;
  segment: string;
  features: string[];
  sizesAvailable: string[];
  image: string;
}

export interface InquiryFormData {
  name: string;
  phone: string;
  email?: string;
  companyName?: string;
  brand: 'shuddh' | 'rozana' | 'both';
  size: string;
  quantity: string;
  requirement: string;
}

export interface Testimonial {
  id: number;
  author: string;
  role: string;
  location: string;
  comment: string;
}
