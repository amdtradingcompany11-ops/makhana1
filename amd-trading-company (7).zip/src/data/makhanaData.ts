/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrandDetails, MakhanaSize, Testimonial } from '../types';

import heroBanner from '../assets/images/makhana_hero_banner_1780317482895.png';
import sutaMix from '../assets/images/makhana_suta_mix_1780918050195.png';
import suta7 from '../assets/images/makhana_7_suta_1780918068126.png';
import suta6 from '../assets/images/makhana_6_suta_1780918085868.png';
import suta5 from '../assets/images/makhana_5_suta_1780918103278.png';
import suta4 from '../assets/images/makhana_4_suta_1780918119532.png';
import roastedMint from '../assets/images/makhana_roasted_mint_1780918133756.png';
import roastedCheese from '../assets/images/makhana_roasted_cheese_1780918151597.png';
import rawSeeds from '../assets/images/makhana_raw_seeds_1780918169507.png';
import makhanaPowder from '../assets/images/makhana_powder_1780918184471.png';
import assamTea from '../assets/images/assam_tea_premium_1780918202928.png';
import chiaSeeds from '../assets/images/chia_seeds_organic_1780918218171.png';

export const IMAGES = {
  hero: heroBanner,
  shuddh: suta6,
  shuddhRaw: rawSeeds,
  rozana: sutaMix,
  sutaMix,
  suta7,
  suta6,
  suta5,
  suta4,
  roastedMint,
  roastedCheese,
  rawSeeds,
  makhanaPowder,
  assamTea,
  chiaSeeds,
};

export const BRANDS: BrandDetails[] = [
  {
    id: 'shuddh',
    name: 'Shuddh Premium Makhana',
    tagline: 'Elite Handpicked White Gold Foxnuts',
    description: 'Double-sorted, premium export quality foxnuts. Characterized by flawless snowy white color, exceptionally large puff sizes, high crispiness, and zero debris or moisture. Crafted specifically for premium retail shops, gifting partners, and elite commercial snacks.',
    segment: 'High Quality Premium Segment',
    features: [
      'Moisture level strictly below 5% for long-lasting crispiness',
      'Double-sorted to ensure 100% spotless white seeds',
      'Ideal for premium commercial roasting and luxury retail packaging',
      'Zero chemical polish - completely natural & processed with extreme hygiene'
    ],
    sizesAvailable: ['5 Suta', '5 Suta+', '6 Suta+'],
    image: suta6,
  },
  {
    id: 'rozana',
    name: 'Rozana Makhana',
    tagline: 'High Nutrition Daily Consumer Foxnuts',
    description: 'Reliable, highly nutritious daily grade makhana. Wholesome and ideal for high-volume processors, everyday home consumption, and general retail. It contains the same premium nutrition at an affordable, highly competitive wholesaling price.',
    segment: 'Affordable Daily Use Segment',
    features: [
      'Fresh and crispy supply directly from Bihar’s harvest',
      'Ideal for local spice & dry fruit retailers, flour mills, and spice mixes',
      'Excellent puff consistency & value-packed pricing for daily consumption',
      'Sortex clean with reliable grading'
    ],
    sizesAvailable: ['3 Suta', '3 Suta+', '4 Suta', '4 Suta+', '5 Suta'],
    image: sutaMix,
  },
];

export const SIZES: MakhanaSize[] = [
  {
    size: '6 Suta+',
    diameter: 'Over 19.05 mm (King Size)',
    premiumGrades: ['Jumbo King', 'Export Elite', '6 Suta Premium'],
    bestFor: 'High-end branding, premium dry-fruit gifting hampers, gourmet chocolate-coating.',
    description: 'The maximum possible puff size available in the makhana market (based on the traditional Bihar 6+ Suta riddle screen size). Offers stellar visual presentation and maximum volume to weight ratio. Absolute premium export quality.',
  },
  {
    size: '5 Suta+',
    diameter: '15.87 mm - 19.05 mm (Super XL Size)',
    premiumGrades: ['Shuddh Gold XL', 'Super Sorter', '5 Suta+ Grade'],
    bestFor: 'Supermarket retail brands, commercial flavored roasting, upscale bulk buyers.',
    description: 'Highly demanded premium commercial size representing uniform big sizes, extremely low broken counts, and snowy white premium density.',
  },
  {
    size: '5 Suta',
    diameter: 'Exactly 15.87 mm (Large)',
    premiumGrades: ['Gold Sorter', 'Standard Premium', '5 Suta Standard'],
    bestFor: 'General wholesale packaging, sweet makers, catering, and hotel groups.',
    description: 'Standard luxury grade size boasting excellent crunch, spotless body, and consistent density across all batches (exact 5/8 inch sieve screen sorting).',
  },
  {
    size: '4 Suta+',
    diameter: '12.70 mm - 15.87 mm (Standard Medium)',
    premiumGrades: ['Makhana Classic Plus', 'Medium Sorted', '4 Suta+ Grade'],
    bestFor: 'Local general shops, daily home roasting, value-addition mixes (chivda/makhana flour).',
    description: 'Highly consumer-friendly size that balances generous volume, solid bite feel, and highly economical rates (sorted with 4 Suta+ sieves).',
  },
  {
    size: '4 Suta',
    diameter: 'Exactly 12.70 mm (Medium)',
    premiumGrades: ['Classic Sorter', 'Retail Pack Standard', '4 Suta Standard'],
    bestFor: 'Flour mills, healthy snack-bar manufacturers, regional wholesaling chains.',
    description: 'Balanced performance grade, highly affordable and selected for pure nutritive profiles without a hefty price premium (4/8 inch or 1/2 inch sieve screen).',
  },
  {
    size: '3 Suta+',
    diameter: '9.52 mm - 12.70 mm (Economy Small)',
    premiumGrades: ['Eco Clean Premium', 'Mixed Wholesome', '3 Suta+ Grade'],
    bestFor: 'Bulk ground powder, health supplements, institutions, large-scale catering.',
    description: 'Cleaned, deshelled small-medium-mix. Perfect for buyers focused on raw protein content and high-volume utility at standard rates.',
  },
  {
    size: '3 Suta',
    diameter: 'Exactly 9.52 mm (Compact)',
    premiumGrades: ['Eco-Value Daily', 'Mini Crunchers', '3 Suta Standard'],
    bestFor: 'Ready-to-eat powder blends, industrial food thickeners, value buyers.',
    description: 'The most cost-effective and nutritious compact grade. Corresponds to 3/8 inch sorting screens and provides extreme value for high-volume dietary uses.',
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 1,
    author: 'Rajesh Mehra',
    role: 'Managing Partner, Mehra Dry Fruits & Co.',
    location: 'Khari Baoli, New Delhi',
    comment: 'AMD Trading Company has changed our supply chain game. We buy Shuddh Premium 5+ mm in metric tons. The moisture levels are always under 5%, and the sorting is completely clean. Perfect for our premium retail packaging.',
  },
  {
    id: 2,
    author: 'Sanjay Thadani',
    role: 'Founder, Superb Snacks LLP',
    location: 'Mumbai, Maharashtra',
    comment: 'We manufacture peri-peri and cheese flavored makhana snacks. Consistent sizing is critical for our automatic packaging machines. AMD Trading provides precise 5mm grading with zero delivery delays.',
  },
  {
    id: 3,
    author: 'Aditya Gupta',
    role: 'Wholesale Distributor',
    location: 'Kanpur, Uttar Pradesh',
    comment: 'For regional distributorship, we count on Rozana Makhana (4+ mm). It represents the absolute best value-for-money. Their pricing is fair, stable, and the response time over WhatsApp is within minutes.',
  }
];

export const SUPPLY_STATS = [
  { value: '100% +', label: 'Bihar Harvest Source' },
  { value: '25 +', label: 'Wholesale Distributors' },
  { value: '100 Tons', label: 'Monthly Supply Capacity' },
  { value: 'Double', label: 'Hygienic Sortex Clean' },
];
