/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ActivePage } from './types';
import { BRANDS, TESTIMONIALS, SUPPLY_STATS, IMAGES } from './data/makhanaData';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import SizeGuide from './components/SizeGuide';
import BulkCalculator from './components/BulkCalculator';
import ShopPage from './components/ShopPage';
import GoogleChatCenter from './components/GoogleChatCenter';
import { 
  Leaf, 
  MessageCircle, 
  Phone, 
  Award, 
  Truck, 
  CheckCircle, 
  FileText, 
  ShieldCheck, 
  TrendingUp, 
  Users, 
  Timer, 
  Briefcase, 
  Send,
  Zap,
  MapPin,
  Mail,
  UserCheck,
  CheckCheck,
  ChevronRight,
  X,
  Bot,
  Sparkles,
  MessageSquare,
  Loader2
} from 'lucide-react';

export default function App() {
  const [activePage, setActivePage] = useState<ActivePage>('home');
  const [preselectedSize, setPreselectedSize] = useState<string>('');

  // AI Chat Bot state variables
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([
    { 
      role: 'assistant', 
      text: 'Namaste! Welcome to AMD Trading Company. I am "AMD Makhana Sahayak", your personalized makhana business assistant. Ask me anything about Shuddh Premium or Rozana makhana, grading filters, wholesale pricing, or office coordinates!' 
    }
  ]);
  const [chatInput, setChatInput] = useState('');
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Chat message scroll box reference
  const chatEndRef = React.useRef<HTMLDivElement>(null);

  // Auto scroll to latest bubble
  React.useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatMessages, isChatOpen]);

  // Handle sending message
  const handleSendChatMessage = async (textToSend?: string) => {
    const text = textToSend !== undefined ? textToSend : chatInput.trim();
    if (!text) return;

    if (textToSend === undefined) {
      setChatInput('');
    }

    // Append user message
    const updatedMessages = [...chatMessages, { role: 'user' as const, text }];
    setChatMessages(updatedMessages);
    setIsChatLoading(true);

    try {
      // Map history format to backend api structure required by genai
      const apiPayload = updatedMessages.map(msg => ({
        role: msg.role === 'assistant' ? 'assistant' : 'user',
        parts: [{ text: msg.text }]
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ messages: apiPayload }),
      });

      if (!res.ok) {
        throw new Error('Connection failed');
      }

      const data = await res.json();
      setChatMessages(prev => [...prev, { role: 'assistant' as const, text: data.text }]);
    } catch (err) {
      console.error('Chat AI call failed:', err);
      setChatMessages(prev => [...prev, { 
        role: 'assistant' as const, 
        text: 'I ran into a connection concern. However, our executive team is active on WhatsApp to clear your wholesale specifications right now! Feel free to click any WhatsApp button to verify rates.' 
      }]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Handle inquiry submissions locally for the form
  const [formInquiry, setFormInquiry] = useState({
    name: '',
    phone: '',
    company: '',
    requirement: '',
  });
  const [formSubmitted, setFormSubmitted] = useState(false);

  // WhatsApp Global Core Clicker
  const openWhatsAppGeneral = (customText?: string) => {
    const text = encodeURIComponent(customText || "Hello AMD Trading Company! I would like to get a quote on bulk makhana options, pricing, and timelines.");
    window.open(`https://wa.me/919555761477?text=${text}`, '_blank');
  };

  const handleSizeGuideQuote = (sizeName: string) => {
    setPreselectedSize(sizeName);
    setActivePage('contact'); // Go to contact page that holds the calculator
  };

  const handleSimpleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formInquiry.name || !formInquiry.phone) return;

    const message = `Hello AMD Trading Company! I would like to submit a general makhana business inquiry.\n\n` +
      `📋 *General Inquiry Details:*\n` +
      `• Contact Name: ${formInquiry.name}\n` +
      `• Mobile/WhatsApp: ${formInquiry.phone}\n` +
      `• Company/Shop: ${formInquiry.company || 'Not Specified'}\n` +
      `• Requirements: ${formInquiry.requirement}\n\n` +
      `Please get back to me directly over WhatsApp. Thank you!`;
    
    setFormSubmitted(true);
    setTimeout(() => {
      window.open(`https://wa.me/919555761477?text=${encodeURIComponent(message)}`, '_blank');
      setFormInquiry({ name: '', phone: '', company: '', requirement: '' });
      setFormSubmitted(false);
    }, 1200);
  };

  return (
    <div id="amd-root" className="min-h-screen flex flex-col justify-between font-sans selection:bg-emerald-600/30 selection:text-emerald-950">
      
      {/* Sticky Top Header */}
      <Navbar activePage={activePage} setActivePage={setActivePage} />

      {/* Main Page Area with AnimatePresence Page Transitions */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          
          {/* ==================== HOME PAGE VIEW ==================== */}
          {activePage === 'home' && (
            <motion.div
              key="home-tab"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.25 }}
              className="space-y-16 md:space-y-24 pb-20"
            >
              {/* Hero Banner Section */}
              <section className="relative bg-stone-900 text-stone-100 overflow-hidden py-16 md:py-28 px-4 sm:px-6 lg:px-8 border-b-4 border-emerald-700">
                
                {/* Visual Image Overlay */}
                <div className="absolute inset-0 z-0">
                  <img 
                    src={IMAGES.hero} 
                    alt="Premium Sourced Makhana" 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover opacity-25 object-center scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-stone-950 via-stone-900/90 to-transparent"></div>
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-transparent to-transparent"></div>
                </div>

                <div className="max-w-7xl mx-auto relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  
                  {/* Left Column Content */}
                  <div className="lg:col-span-7 space-y-6 md:space-y-8 text-center lg:text-left">
                    <span className="inline-flex items-center space-x-2 bg-emerald-900/50 border border-emerald-800/80 text-emerald-400 text-xs font-semibold px-4 py-2 rounded-full uppercase tracking-widest leading-none">
                      <Award className="h-4 w-4" />
                      <span>Direct Sorter Farm to Warehouse Wholesaler</span>
                    </span>

                    <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-tight">
                      Premium Quality <br />
                      <span className="text-emerald-400">Makhana Supplier</span>
                    </h1>

                    <p className="text-stone-300 text-base sm:text-lg max-w-2xl leading-relaxed mx-auto lg:mx-0">
                      AMD Trading Company is a trusted bulk supplier and distributor of elite organic foxnuts (makhana). We secure the finest, double-sorted harvest to supply retailers, groceries, and spice buyers nationwide.
                    </p>

                    {/* CTAs */}
                    <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
                      <button
                        onClick={() => openWhatsAppGeneral()}
                        className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-8 py-4 rounded-xl shadow-lg transition-all duration-200 flex items-center justify-center space-x-2 text-base hover:-translate-y-0.5 cursor-pointer"
                      >
                        <MessageCircle className="h-5.5 w-5.5 fill-current" />
                        <span>Contact on WhatsApp</span>
                      </button>

                      <button
                        onClick={() => {
                          setActivePage('contact');
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="w-full sm:w-auto bg-white hover:bg-stone-100 text-stone-900 font-bold px-8 py-4 rounded-xl shadow-xs transition-all duration-200 border border-stone-200 text-base hover:-translate-y-0.5 cursor-pointer"
                      >
                        Request Bulk Quote
                      </button>
                    </div>

                    {/* Confidence checklist */}
                    <div className="flex flex-wrap justify-center lg:justify-start gap-x-6 gap-y-2 pt-4 border-t border-stone-800 text-xs text-stone-400">
                      <span className="flex items-center space-x-1.5 font-mono">
                        <CheckCheck className="h-4 w-4 text-emerald-500" />
                        <span>Consistent Sizes</span>
                      </span>
                      <span className="flex items-center space-x-1.5 font-mono">
                        <CheckCheck className="h-4 w-4 text-emerald-500" />
                        <span>Moisture Protected Supply</span>
                      </span>
                      <span className="flex items-center space-x-1.5 font-mono">
                        <CheckCheck className="h-4 w-4 text-emerald-500" />
                        <span>Fair Wholesaling Rates</span>
                      </span>
                      <span className="flex items-center space-x-1.5 font-mono select-all">
                        <ShieldCheck className="h-4 w-4 text-emerald-500" />
                        <span className="text-emerald-400 font-semibold">FSSAI Certified (Lic. 20826004001411)</span>
                      </span>
                    </div>

                  </div>

                  {/* Right Column Stats Mini Panel */}
                  <div className="lg:col-span-5 grid grid-cols-2 gap-4">
                    {SUPPLY_STATS.map((stat, idx) => (
                      <div 
                        key={idx} 
                        className="bg-black/40 backdrop-blur-xs rounded-2xl border border-stone-800 p-6 text-center shadow-inner"
                      >
                        <span className="font-serif text-3xl sm:text-4xl font-extrabold text-emerald-400 block tracking-tight">
                          {stat.value}
                        </span>
                        <span className="text-xs text-stone-400 font-mono uppercase tracking-wider block mt-1.5 leading-snug">
                          {stat.label}
                        </span>
                      </div>
                    ))}
                  </div>

                </div>
              </section>

              {/* Two Main Brands Showcase */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center space-y-3 mb-12 sm:mb-16">
                  <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest font-mono">Dual Brand Strategy</span>
                  <h2 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900">
                    Two Distinct Brands to Serve Your Markets
                  </h2>
                  <p className="text-stone-500 max-w-2xl mx-auto text-sm sm:text-base">
                    Whether you cater to elite supermarkets looking for spotless premium grades, or standard provision stores seeking high quality daily rations, we have you covered.
                  </p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-stretch">
                  {BRANDS.map((brand) => (
                    <div 
                      key={brand.id}
                      className="bg-white rounded-3xl border border-stone-200/80 shadow-xs hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col justify-between"
                    >
                      <div>
                        {/* Brand Image Header */}
                        <div className="h-64 sm:h-72 w-full relative">
                          <img 
                            src={brand.image} 
                            alt={brand.name} 
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover object-center"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent"></div>
                          
                          {/* Segment Badge */}
                          <div className="absolute top-4 right-4 bg-emerald-900 text-emerald-300 text-xs font-semibold px-3 py-1.5 rounded-lg font-mono tracking-wide uppercase shadow-xs">
                            {brand.segment}
                          </div>

                          <div className="absolute bottom-6 left-6 p-1">
                            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-white leading-tight">
                              {brand.name}
                            </h3>
                            <p className="text-emerald-400 text-xs font-medium font-mono uppercase tracking-wider mt-0.5">
                              {brand.tagline}
                            </p>
                          </div>
                        </div>

                        {/* Brand Description & Features list */}
                        <div className="p-6 sm:p-8 space-y-6">
                          <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
                            {brand.description}
                          </p>

                          <div className="space-y-2.5">
                            <span className="text-xs font-bold text-stone-700 tracking-wider uppercase block">Quality Hallmarks:</span>
                            <ul className="space-y-2">
                              {brand.features.map((feat, fi) => (
                                <li key={fi} className="flex items-start text-xs sm:text-sm text-stone-600">
                                  <CheckCheck className="h-4.5 w-4.5 text-emerald-600 shrink-0 mr-2 mt-0.5" />
                                  <span>{feat}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>

                      {/* Brand Footer Sizing & Quotes */}
                      <div className="p-6 sm:p-8 bg-stone-50 border-t border-stone-200/60 flex flex-col sm:flex-row justify-between items-center gap-4">
                        <div>
                          <span className="text-[10px] text-stone-400 font-mono block uppercase">Available Calibers</span>
                          <div className="flex flex-wrap gap-1.5 mt-1">
                            {brand.sizesAvailable.map((sz) => (
                              <span key={sz} className="bg-stone-200/80 border border-stone-300/30 text-stone-800 text-xs font-semibold font-mono px-2 py-0.5 rounded-md">
                                {sz}
                              </span>
                            ))}
                          </div>
                        </div>

                        <button
                          onClick={() => {
                            setPreselectedSize(brand.sizesAvailable[brand.sizesAvailable.length - 1]);
                            setActivePage('products');
                            window.scrollTo({ top: 0, behavior: 'smooth' });
                          }}
                          className="w-full sm:w-auto bg-stone-900 hover:bg-emerald-800 text-white text-xs sm:text-sm font-semibold tracking-wider px-5 py-3 rounded-xl shadow-xs transition-colors cursor-pointer text-center"
                        >
                          Show Specific Sizes
                        </button>
                      </div>

                    </div>
                  ))}
                </div>
              </section>

              {/* Sourcing & Harvest Story Segment */}
              <section className="bg-emerald-50/50 border-y border-emerald-100/60 py-16 md:py-24">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  
                  <div className="lg:col-span-5 space-y-6">
                    <span className="text-xs font-bold text-emerald-800 tracking-widest font-mono uppercase">Direct Sourcing Guarantee</span>
                    <h2 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900 leading-tight">
                      Sourced Directly from Bihar’s Wetland Farms
                    </h2>
                    <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
                      Foxnuts (Makhana) are water lilies harvested exclusively in the shallow ponds and wetlands of Bihar. This geographical specialization is where 90% of the world’s premium makhana originates.
                    </p>
                    <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
                      At AMD Trading Company, we maintain a robust collection and mandi network in the heart of Darbhanga and Madhubani. Our raw seeds go directly to state-of-the-art grading filters, ensuring that the stock you receive is crispy, debris-free, and size-consistent.
                    </p>

                    <div className="grid grid-cols-2 gap-4 pt-2">
                      <div className="p-4 bg-white rounded-xl border border-stone-200 shadow-2xs">
                        <span className="text-xl">👩‍🌾</span>
                        <p className="text-xs font-bold text-stone-800 mt-1">Ethical Sourcing</p>
                        <p className="text-[11px] text-stone-500">Supporting marginal local wetland farmers.</p>
                      </div>
                      <div className="p-4 bg-white rounded-xl border border-stone-200 shadow-2xs">
                        <span className="text-xl">🌍</span>
                        <p className="text-xs font-bold text-stone-800 mt-1 font-sans">Pan-India Cargo</p>
                        <p className="text-[11px] text-stone-500">Fast road dispatch with robust transport tying.</p>
                      </div>
                    </div>
                  </div>

                  {/* Sourcing workflow visual checklist */}
                  <div className="lg:col-span-7 bg-white p-6 sm:p-10 rounded-3xl border border-stone-200 shadow-sm space-y-6">
                    <h3 className="font-serif font-bold text-stone-900 text-xl sm:text-2xl border-b border-stone-100 pb-3">
                      Our Rigid 4-Stage Sorting Chain
                    </h3>

                    <div className="space-y-4">
                      
                      <div className="flex items-start space-x-4">
                        <div className="bg-emerald-50 text-emerald-800 font-mono font-bold text-xs p-2.5 rounded-lg shrink-0 border border-emerald-100">01</div>
                        <div>
                          <h4 className="font-semibold text-stone-800 text-sm sm:text-base">Mandi Level Grading</h4>
                          <p className="text-xs text-stone-500">Immediately after popping, foxnuts are pre-screened to separate mature seed bodies from flat/undeveloped puffs.</p>
                        </div>
                      </div>

                      <div className="flex items-start space-x-4">
                        <div className="bg-emerald-50 text-emerald-800 font-mono font-bold text-xs p-2.5 rounded-lg shrink-0 border border-emerald-100">02</div>
                        <div>
                          <h4 className="font-semibold text-stone-800 text-sm sm:text-base">Debris & Decortication Removal</h4>
                          <p className="text-xs text-stone-500">Automated Sortex filters and multi-stage vibrating sieves strip shell flakes, black points, and dust particles.</p>
                        </div>
                      </div>

                      <div className="flex items-start space-x-4">
                        <div className="bg-emerald-50 text-emerald-800 font-mono font-bold text-xs p-2.5 rounded-lg shrink-0 border border-emerald-100">03</div>
                        <div>
                          <h4 className="font-semibold text-stone-800 text-sm sm:text-base">Moisture and Crisp Control</h4>
                          <p className="text-xs text-stone-500">Our ex-warehouse stock undergoes hot-air roasting checks to lock moisture below 5%, eliminating dampness or early rot.</p>
                        </div>
                      </div>

                      <div className="flex items-start space-x-4">
                        <div className="bg-emerald-50 text-emerald-800 font-mono font-bold text-xs p-2.5 rounded-lg shrink-0 border border-emerald-100">04</div>
                        <div>
                          <h4 className="font-semibold text-stone-800 text-sm sm:text-base">Heavy Duty PP Bagging</h4>
                          <p className="text-xs text-stone-500">Sacks are tightly sealed in multi-ply food-grade moisture-barrier bags to retain absolute crunchiness during cross-state transport.</p>
                        </div>
                      </div>

                    </div>
                  </div>

                </div>
              </section>

              {/* Live Testimonials Banner */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center space-y-3 mb-12 sm:mb-16">
                  <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest font-mono">Real B2B Trust</span>
                  <h2 className="font-serif text-3xl sm:text-4xl font-bold text-stone-900">
                    Trusted By Top Wholesalers & Retailers
                  </h2>
                  <p className="text-stone-500 max-w-2xl mx-auto text-sm sm:text-base">
                    Here is what regional distributors, dry fruit packers, and grocery chain managers say about working with AMD Trading Company.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
                  {TESTIMONIALS.map((t) => (
                    <div 
                      key={t.id} 
                      className="bg-white border border-stone-200/90 rounded-2xl p-6 flex flex-col justify-between shadow-2xs relative"
                    >
                      <div className="absolute top-6 right-6 text-6xl text-emerald-100 font-serif font-bold h-0 pointer-events-none select-none">“</div>
                      <div className="space-y-4 relative z-10">
                        <div className="flex items-center space-x-1">
                          {[1,2,3,4,5].map((s) => (
                            <span key={s} className="text-amber-500 text-base">★</span>
                          ))}
                        </div>
                        <p className="text-stone-600 text-xs sm:text-sm italic leading-relaxed">
                          "{t.comment}"
                        </p>
                      </div>
                      <div className="mt-6 border-t border-stone-100 pt-4 flex items-center justify-between">
                        <div>
                          <span className="font-semibold text-stone-900 text-xs sm:text-sm block">
                            {t.author}
                          </span>
                          <span className="text-[11px] text-stone-500 block">
                            {t.role}
                          </span>
                        </div>
                        <span className="text-[10px] bg-stone-100 text-stone-600 font-semibold px-2 py-0.5 rounded-md shrink-0">
                          {t.location}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* Bottom Quick Call To Action */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="bg-emerald-950 rounded-3xl border border-emerald-900 p-8 sm:p-12 text-center text-white relative overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:16px_16px] opacity-10"></div>
                  <div className="relative z-10 max-w-2xl mx-auto space-y-6">
                    <span className="bg-emerald-800 text-emerald-300 text-xs font-semibold px-3 py-1.5 rounded-full inline-block font-mono tracking-widest uppercase">
                      Fast Turnaround dispatch
                    </span>
                    <h2 className="font-serif text-3xl sm:text-4xl font-bold leading-snug">
                      Ready to Receive Fresh Makhana Stock?
                    </h2>
                    <p className="text-stone-300 text-sm sm:text-base leading-relaxed">
                      Connect directly over WhatsApp to check today’s mandi dispatch prices or let our team structure custom labeling solutions for your brand.
                    </p>
                    <div className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-2">
                      <button
                        onClick={() => openWhatsAppGeneral("Hello, I am seeking ex-warehouse bulk rates for Shuddh Premium Makhana size 5 Suta+. Please share details.")}
                        className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-stone-950 font-bold px-7 py-3.5 rounded-xl shadow-lg transition-transform hover:-translate-y-0.5 text-sm sm:text-base flex items-center justify-center space-x-2 cursor-pointer"
                      >
                        <MessageCircle className="h-5 w-5 fill-current" />
                        <span>Get Best Bulk Price</span>
                      </button>

                      <a
                        href="tel:+919555761477"
                        className="w-full sm:w-auto border border-emerald-800 hover:border-emerald-500 text-white font-semibold hover:bg-emerald-900 px-7 py-3.5 rounded-xl transition-all hover:-translate-y-0.5 text-sm sm:text-base flex items-center justify-center space-x-2 cursor-pointer"
                      >
                        <Phone className="h-4.5 w-4.5" />
                        <span>Call +91 95557 61477</span>
                      </a>
                    </div>
                  </div>
                </div>
              </section>

            </motion.div>
          )}

          {/* ==================== PRODUCTS DETAIL TAB ==================== */}
          {activePage === 'products' && (
            <motion.div
              key="products-tab"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.25 }}
              className="space-y-16 py-10 pb-20"
            >
              {/* Product Header */}
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center space-y-4 max-w-3xl mx-auto">
                  <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest font-mono bg-emerald-50 border border-emerald-100/70 p-2.5 rounded-full inline-block leading-none">
                    Bulk Product Showcase & Sizing Metrics
                  </span>
                  <h1 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-stone-900 leading-tight">
                    Clean, Double-Sorted Bulk Supply
                  </h1>
                  <p className="text-stone-500 text-sm sm:text-base leading-relaxed">
                    We deal strictly in graded makhana processed to meet meticulous corporate standards. View our brand categories and click standard sizes to obtain ex-warehouse logistics prices.
                  </p>
                </div>
              </div>

              {/* Shuddh Premium Breakdown */}
              <section className="bg-white border-y border-stone-200 py-12 md:py-16">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  
                  <div className="lg:col-span-5 space-y-6">
                    <div className="space-y-2">
                      <span className="text-xs font-bold text-amber-700 tracking-widest font-mono uppercase bg-amber-50 border border-amber-100 px-2.5 py-1 rounded-md">
                        Premium B2B Leader
                      </span>
                      <h2 className="font-serif text-3xl font-bold text-stone-900">
                        Shuddh Premium Brand
                      </h2>
                    </div>

                    <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
                      Sourced with absolute devotion to size consistency, flawless snowy white body, and zero shell residue. Shuddh Premium represents the elite tier sizing suitable for premium retail jars, flavored roasting brands, and packaging that demands flawless product display.
                    </p>

                    <div className="space-y-3 pt-2">
                      <div className="flex items-start space-x-3 text-sm text-stone-600">
                        <CheckCheck className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                        <span><strong>Spotless Sortex Sorting:</strong> Completely unpolished, hand-selected to be 100% spotless.</span>
                      </div>
                      <div className="flex items-start space-x-3 text-sm text-stone-600">
                        <CheckCheck className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                        <span><strong>Elite Suta Calibers:</strong> Exclusively sorted into large 5 Suta, 5 Suta+, and 6 Suta+ diameters (up to 19mm+ puff expansion).</span>
                      </div>
                      <div className="flex items-start space-x-3 text-sm text-stone-600">
                        <CheckCheck className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                        <span><strong>Moisture Guarantee:</strong> Thoroughly dry roasted ex-warehouse to assure zero early damp flavor.</span>
                      </div>
                    </div>

                    <div className="pt-4 flex flex-col sm:flex-row gap-3">
                      <button
                        onClick={() => openWhatsAppGeneral("Hello AMD Trading, I am seeking bulk rate info for Shuddh Premium segment. Please share grades and mandi options.")}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm px-6 py-3.5 rounded-xl flex items-center justify-center space-x-2 shadow-xs cursor-pointer"
                      >
                        <MessageCircle className="h-4.5 w-4.5 fill-current" />
                        <span>Query Best Premium Rate</span>
                      </button>
                    </div>
                  </div>

                  <div className="lg:col-span-7">
                    <img 
                      src={IMAGES.shuddh} 
                      alt="Shuddh Premium Brand Makhana" 
                      referrerPolicy="no-referrer"
                      className="w-full h-96 object-cover rounded-3xl border border-stone-200 shadow-md"
                    />
                  </div>

                </div>
              </section>

              {/* Rozana Makhana Breakdown */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                
                <div className="lg:col-span-7 order-last lg:order-first">
                  <img 
                    src={IMAGES.rozana} 
                    alt="Rozana Makhana Segment" 
                    referrerPolicy="no-referrer"
                    className="w-full h-96 object-cover rounded-3xl border border-stone-200 shadow-md"
                  />
                </div>

                <div className="lg:col-span-5 space-y-6">
                  <div className="space-y-2">
                    <span className="text-xs font-bold text-emerald-800 tracking-widest font-mono uppercase bg-emerald-50 border border-emerald-100 px-2.5 py-1 rounded-md">
                      Highly Economical Segment
                    </span>
                    <h2 className="font-serif text-3xl font-bold text-stone-900">
                      Rozana Makhana Brand
                    </h2>
                  </div>

                  <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
                    Designed to address high-volume consumption, regional spice packer networks, and price-conscious consumers. Rozana segment packs the same premium organic nutrition from the lotus seed body down into more compact size classes suitable for daily frying, snack baking, flour milling, or medicinal powders.
                  </p>

                  <div className="space-y-3 pt-2">
                    <div className="flex items-start space-x-3 text-sm text-stone-600">
                      <CheckCheck className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                      <span><strong>Complete Value Pricing:</strong> Fair wholesaling rates suitable for rapid rotation of stock in daily general stores.</span>
                    </div>
                    <div className="flex items-start space-x-3 text-sm text-stone-600">
                      <CheckCheck className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                      <span><strong>Standard Sieve Density:</strong> Graded strictly within nutritious 3 Suta to 5 Suta specs with zero dusty residues or empty hulls.</span>
                    </div>
                    <div className="flex items-start space-x-3 text-sm text-stone-600">
                      <CheckCheck className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                      <span><strong>Perfect for Blending:</strong> Extensively sourced by manufacturers of healthy food supplement protein powders.</span>
                    </div>
                  </div>

                  <div className="pt-4">
                    <button
                      onClick={() => openWhatsAppGeneral("Hello AMD Trading, I am seeking wholesale bulk rate info for Rozana Makhana segment. Please share mandi ex-warehouse pricing sheet.")}
                      className="bg-stone-900 hover:bg-emerald-900 text-white font-bold text-xs sm:text-sm px-6 py-3.5 rounded-xl flex items-center justify-center space-x-2 shadow-xs cursor-pointer w-full sm:w-auto"
                    >
                      <MessageCircle className="h-4.5 w-4.5 fill-current" />
                      <span>Query Rozana Bulk Pricing</span>
                    </button>
                  </div>
                </div>

              </section>

              {/* Sizing Interactive Table / Selector */}
              <section id="sizing-guide-anchor" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 pt-6">
                <div className="text-center space-y-2">
                  <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-800">Choose Your Precise Diameter Sizing</h3>
                  <p className="text-stone-500 text-sm max-w-xl mx-auto">Click any caliber thickness on our calibrated list below to see its premium grade descriptor, and application guide.</p>
                </div>
                
                {/* Embedded Size Guide Component */}
                <SizeGuide onQuoteRequest={handleSizeGuideQuote} />
              </section>

            </motion.div>
          )}

          {/* ==================== ABOUT US TAB ==================== */}
          {activePage === 'about' && (
            <motion.div
              key="about-tab"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.25 }}
              className="space-y-16 py-10 pb-20"
            >
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
                  
                  {/* Left Story narrative */}
                  <div className="lg:col-span-6 space-y-6">
                    <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest font-mono">B2B Core Heritage</span>
                    <h1 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-stone-900">
                      We Are Trusted Makhana Suppliers
                    </h1>
                    <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
                      At AMD Trading Company, we approach the makhana trade with a passion for quality and transparent commercial ethics. Having deep roots in Bihar’s agrarian dry-fruit zones, we operate a reliable integration chain combining localized farm collection, Sortex grading, ex-warehouse hot-air drying, and dispatch coordination.
                    </p>
                    <p className="text-stone-600 text-sm sm:text-base leading-relaxed">
                      Our trade model revolves around robust reliability. In the high-volume commodities market, consistency in pricing and size calibers across different seasons is what sets us apart. We prioritize building robust, long-term relationships with regional dealers, packaging companies, and supply house wholesalers nationwide.
                    </p>

                    <div className="border-t border-stone-200 pt-6 grid grid-cols-3 gap-4">
                      <div>
                        <span className="font-serif text-2xl font-bold text-emerald-700 block text-stone-900">100%</span>
                        <span className="text-[10px] text-stone-400 font-mono uppercase tracking-wider block mt-1">Hygienic Sortex</span>
                      </div>
                      <div>
                        <span className="font-serif text-2xl font-bold text-emerald-700 block text-stone-900">QC Pure</span>
                        <span className="text-[10px] text-stone-400 font-mono uppercase tracking-wider block mt-1">Tested Moisture</span>
                      </div>
                      <div>
                        <span className="font-serif text-2xl font-bold text-emerald-700 block text-stone-900">Direct</span>
                        <span className="text-[10px] text-stone-400 font-mono uppercase tracking-wider block mt-1">Farm Mandi Proc</span>
                      </div>
                    </div>
                  </div>

                  {/* Right visual blocks */}
                  <div className="lg:col-span-6 bg-stone-900 rounded-3xl border border-stone-800 p-8 text-stone-300 space-y-6 relative overflow-hidden shadow-xs">
                    <div className="absolute inset-0 bg-[radial-gradient(#10b981_1px,transparent_1px)] [background-size:24px_24px] opacity-5 pointer-events-none"></div>
                    
                    <h3 className="font-serif text-2xl font-bold text-white border-b border-stone-800 pb-3">Our Core Principles</h3>

                    <div className="space-y-4">
                      <div className="flex space-x-3.5">
                        <Award className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-semibold text-white text-sm sm:text-base">Absolute Sizing Compliance</h4>
                          <p className="text-xs text-stone-400 mt-1">We honor our sieve calibration labels. When you purchase 5 Suta+ caliber from Shuddh Premium, we verify each batch through rigorous sieve screening tests to ensure consistent sorting.</p>
                        </div>
                      </div>

                      <div className="flex space-x-3.5">
                        <Timer className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-semibold text-white text-sm sm:text-base">Continuous Cargo Guarantee</h4>
                          <p className="text-xs text-stone-400 mt-1">Peak seasonal times (festivals, winter) often cause severe supply gaps. Our warehouses keep strategic stockpiles to satisfy core clients with stable, un-interrupted dispatches.</p>
                        </div>
                      </div>

                      <div className="flex space-x-3.5">
                        <Users className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-semibold text-white text-sm sm:text-base">Sustained Long-Term Association</h4>
                          <p className="text-xs text-stone-400 mt-1">We recognize that B2B relationships thrive on transparency, predictable weighing matrices, and realistic dispatch timelines. We act as reliable strategic structural backbones.</p>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>
              </section>

              {/* Our Processing Workflow Block */}
              <section className="bg-white border-y border-stone-300/60 py-16">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
                  <div className="text-center space-y-2">
                    <span className="text-xs font-bold text-emerald-700 font-mono uppercase tracking-widest block">QC Pipeline</span>
                    <h3 className="font-serif text-2xl sm:text-4xl font-bold text-stone-900">How We Keep Sourcing Standards Pure</h3>
                    <p className="text-stone-500 text-sm max-w-xl mx-auto">A walk-through of the hygienic measures applied to our makhana ex-warehouse storage pipelines.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    <div className="p-5 bg-stone-50 border border-stone-100 rounded-2xl">
                      <span className="text-3xl">🏞️</span>
                      <h4 className="font-bold text-sm sm:text-base text-stone-800 mt-2">1. Local Harvesting</h4>
                      <p className="text-xs text-stone-500 mt-1">Organic lotus seeds are painstakingly hand-gathered from wetland beds by skilled local farmers.</p>
                    </div>
                    <div className="p-5 bg-stone-50 border border-stone-100 rounded-2xl">
                      <span className="text-3xl">🔥</span>
                      <h4 className="font-bold text-sm sm:text-base text-stone-800 mt-2">2. Manual Popping</h4>
                      <p className="text-xs text-stone-500 mt-1">Raw seeds are roasted over clay fires and hot sand, then struck manually to pop into fresh pristine white makhana puffs.</p>
                    </div>
                    <div className="p-5 bg-stone-50 border border-stone-100 rounded-2xl">
                      <span className="text-3xl">⚙️</span>
                      <h4 className="font-bold text-sm sm:text-base text-stone-800 mt-2">3. Mechanical Sieving</h4>
                      <p className="text-xs text-stone-500 mt-1">Specialized sieve screens sort popped seeds cleanly into standardized Suta grades (from compact 3 Suta up to king size 6 Suta+).</p>
                    </div>
                    <div className="p-5 bg-stone-50 border border-stone-100 rounded-2xl">
                      <span className="text-3xl">📦</span>
                      <h4 className="font-bold text-sm sm:text-base text-stone-800 mt-2">4. Smart Bag Packaging</h4>
                      <p className="text-xs text-stone-500 mt-1">Moisture-barrier heavy-duty plastic sacks are packed clean, sealed, and prepared immediately for ex-warehouse dispatch.</p>
                    </div>
                  </div>
                </div>
              </section>

              {/* Bihar & Suta Heritage Section */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                <div className="bg-stone-50 rounded-3xl border border-stone-200/80 p-8 sm:p-12 grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="space-y-5">
                    <span className="text-[10px] font-mono tracking-widest uppercase bg-amber-100 text-amber-900 border border-amber-200 px-3 py-1 rounded-full inline-block leading-none font-bold">
                      The Bihar Sourcing Advantage
                    </span>
                    <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
                      Why Over 90% of Global Makhana Originates Here
                    </h3>
                    <p className="text-stone-600 text-sm leading-relaxed">
                      Makhana (Euryale ferox) is not simply a crop; it is an aquatic treasure native to the shallow wetland ecosystems of North Bihar (including prime hubs like Katihar, Purnia, Darbhanga, and Madhubani). 
                    </p>
                    <p className="text-stone-600 text-sm leading-relaxed">
                      The unique local soil biochemistry, slow-moving waters, and tropical humidity form the perfect habitat. Generations of farming communities possess unmatched indigenous knowledge in collecting, drying, and popping these heavy lotus seeds on clay surfaces at high temperatures. AMD Trading Company coordinates directly with these micro-mandi cooperatives to procure raw popped seeds, guaranteeing fresh supplies with zero chemical bleaches.
                    </p>
                  </div>

                  <div className="space-y-5 border-t lg:border-t-0 lg:border-l border-stone-200 pt-8 lg:pt-0 lg:pl-12">
                    <span className="text-[10px] font-mono tracking-widest uppercase bg-emerald-100 text-emerald-950 border border-emerald-200 px-3 py-1 rounded-full inline-block leading-none font-bold">
                      Understanding Suta Grading
                    </span>
                    <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
                      Deciphering the Traditional Sieve Matrix
                    </h3>
                    <p className="text-stone-600 text-sm leading-relaxed">
                      To buy makhana at wholesale scales without getting over-quoted or receiving substandard small puffs, it is crucial to understand the <strong>Suta</strong> system.
                    </p>
                    <div className="space-y-3 font-sans text-xs sm:text-sm text-stone-600">
                      <div className="flex justify-between border-b border-stone-200/60 pb-1.5">
                        <span className="font-medium text-stone-800">What is 1 Suta?</span>
                        <span className="text-stone-500 font-mono">1/8 inch (~3.175 mm)</span>
                      </div>
                      <div className="flex justify-between border-b border-stone-200/60 pb-1.5">
                        <span className="font-medium text-stone-800">Makhana Premium Grade (6 Suta+)</span>
                        <span className="text-stone-500 font-mono">&gt; 19.05 mm (Export Quality)</span>
                      </div>
                      <div className="flex justify-between border-b border-stone-200/60 pb-1.5">
                        <span className="font-medium text-stone-800">Makhana XL Grade (5 Suta)</span>
                        <span className="text-stone-500 font-mono">15.87 mm (Optimal Retail)</span>
                      </div>
                      <div className="flex justify-between pb-1.5">
                        <span className="font-medium text-stone-800">Makhana Daily Grade (3 - 4 Suta)</span>
                        <span className="text-stone-500 font-mono">9.52 mm - 12.70 mm (Affordable)</span>
                      </div>
                    </div>
                    <p className="text-stone-500 text-xs leading-relaxed italic animate-pulse">
                      Note: Prices fluctuate strictly based on the sieve size. Large 6 Suta+ varieties command premium rates, while daily value brands like Rozana utilize 3 to 4 Suta seeds to deliver maximum nutrition at highly viable price structures.
                    </p>
                  </div>
                </div>
              </section>

            </motion.div>
          )}

          {/* ==================== WHY CHOOSE US TAB ==================== */}
          {activePage === 'why-choose-us' && (
            <motion.div
              key="why-choose-tab"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.25 }}
              className="space-y-16 py-10 pb-20"
            >
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                
                {/* Header block */}
                <div className="text-center space-y-4 max-w-3xl mx-auto mb-16">
                  <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest font-mono bg-emerald-50 border border-emerald-100/70 p-2.5 rounded-full inline-block leading-none">
                    Unrivaled Bulk Integrity
                  </span>
                  <h1 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-stone-900 leading-tight">
                    Reliable Supply & Balanced Rates
                  </h1>
                  <p className="text-stone-500 text-sm sm:text-base leading-relaxed">
                    We avoid race-to-the-bottom "cheapest" quotes that lead directly to rotten batches, delayed dispatches, or mixed caliber thickness. Instead, we offer competitive, fair rates backed by strict, dependable stock quality.
                  </p>
                </div>

                {/* Benefits Showcase Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
                  
                  {/* Benefit 1 */}
                  <div className="bg-white border border-stone-200 p-6 rounded-2xl space-y-4 shadow-2xs hover:shadow-sm transition-all duration-150">
                    <div className="h-10 w-10 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center justify-center text-emerald-700">
                      <ShieldCheck className="h-5 w-5" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-stone-900">Consistent Sizing</h3>
                    <p className="text-stone-500 text-xs sm:text-sm leading-relaxed">
                      Our calibers (ranges from 3 Suta up to premium 6 Suta+) do not contain empty shells or small mixed-grade puffs. You receive exactly the calibrated grade and Suta density specified.
                    </p>
                  </div>

                  {/* Benefit 2 */}
                  <div className="bg-white border border-stone-200 p-6 rounded-2xl space-y-4 shadow-2xs hover:shadow-sm transition-all duration-150">
                    <div className="h-10 w-10 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center justify-center text-emerald-700">
                      <TrendingUp className="h-5 w-5" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-stone-900">Fair Commercial Pricing</h3>
                    <p className="text-stone-500 text-xs sm:text-sm leading-relaxed">
                      We operate with clean, long-term commercial intent. Our quotes track honest mandi market curves, letting you price your local distributorship securely with solid margins close to ex-warehouse costs.
                    </p>
                  </div>

                  {/* Benefit 3 */}
                  <div className="bg-white border border-stone-200 p-6 rounded-2xl space-y-4 shadow-2xs hover:shadow-sm transition-all duration-150">
                    <div className="h-10 w-10 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center justify-center text-emerald-700">
                      <Users className="h-5 w-5" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-stone-900">Trusted By Retailers</h3>
                    <p className="text-stone-500 text-xs sm:text-sm leading-relaxed">
                      Our ex-warehouse makhana grades sit on the shelves of dozens of local dry-fruit shops, modern regional supermarkets, and international packaging exporters who value reliable quality.
                    </p>
                  </div>

                  {/* Benefit 4 */}
                  <div className="bg-white border border-stone-200 p-6 rounded-2xl space-y-4 shadow-2xs hover:shadow-sm transition-all duration-150">
                    <div className="h-10 w-10 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center justify-center text-emerald-700">
                      <Zap className="h-5 w-5" />
                    </div>
                    <h3 className="font-serif text-lg font-bold text-stone-900">Lightning Fast Response</h3>
                    <p className="text-stone-500 text-xs sm:text-sm leading-relaxed">
                      No bureaucratic communication gaps. Our billing managers remain online over phone, email, and WhatsApp to supply custom quotes, transport status, and bills within minutes.
                    </p>
                  </div>

                </div>

                {/* B2B Logistics Capability banner */}
                <div className="mt-16 bg-stone-900 rounded-2xl border border-stone-800 p-6 sm:p-10 text-stone-300 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
                  <div className="space-y-2 relative z-10 max-w-xl">
                    <span className="text-[10px] text-emerald-400 font-mono font-bold tracking-widest block uppercase">Logistics & Freight Handling</span>
                    <h3 className="font-serif text-xl sm:text-2xl font-bold text-white">Full-Truck and Part-Truck Coordination</h3>
                    <p className="text-xs sm:text-sm text-stone-400 leading-relaxed">
                      Whether you require a single regional delivery of 500kg or multiple cargo trucks of 10 Metric Tons, we manage transport tie-ups with dependable road freight partners to secure ex-warehouse logistics and fast clearance.
                    </p>
                  </div>
                  <button
                    onClick={() => openWhatsAppGeneral("Hello AMD Trading. I want to inquire about dispatch freight logistics parameters, transit insurance terms, and delivery schedules.")}
                    className="shrink-0 w-full md:w-auto bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm px-6 py-3.5 rounded-xl flex items-center justify-center space-x-2 shadow-xs transition-colors cursor-pointer"
                  >
                    <Truck className="h-4 w-4" />
                    <span>Inquire Logistics Policy</span>
                  </button>
                </div>

              </section>
            </motion.div>
          )}

          {/* ==================== ECOMMERCE SHOP RETAIL TAB ==================== */}
          {activePage === 'shop' && (
            <motion.div
              key="shop-tab"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.25 }}
            >
              <ShopPage />
            </motion.div>
          )}

          {/* ==================== GOOGLE WORKSPACE CHAT CENTER TAB ==================== */}
          {activePage === 'workspace-chat' && (
            <motion.div
              key="workspace-chat-tab"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.25 }}
            >
              <GoogleChatCenter />
            </motion.div>
          )}

          {/* ==================== CONTACT & ESTIMATOR TAB ==================== */}
          {activePage === 'contact' && (
            <motion.div
              key="contact-tab"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.25 }}
              className="space-y-16 py-10 pb-20"
            >
              
              {/* Premium Quote Section & Sheet */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
                <div className="text-center space-y-2">
                  <span className="text-xs font-bold text-emerald-800 uppercase tracking-widest font-mono bg-emerald-50 border border-emerald-100 p-2 rounded-md inline-block">
                    Interactive B2B Bidding Window
                  </span>
                  <h2 className="font-serif text-3xl sm:text-5xl font-bold tracking-tight text-stone-900">
                    Get Best Bulk Price Quote
                  </h2>
                  <p className="text-stone-500 text-sm max-w-lg mx-auto">
                    Toggle your desired brand segment and calibers below. Live estimations immediately output custom formatted links to communicate with ex-warehouse sales incharge on WhatsApp.
                  </p>
                </div>

                {/* Embedded Bulk Quote Generator */}
                <BulkCalculator preselectedSize={preselectedSize} />
              </section>

              {/* General Contact Form & Location Details */}
              <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 border-t border-stone-200">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
                  
                  {/* General Inquiry Form */}
                  <div className="lg:col-span-7 bg-white rounded-3xl border border-stone-200/90 shadow-sm p-6 sm:p-8 space-y-6">
                    <div className="space-y-1">
                      <h3 className="font-serif text-xl sm:text-2xl font-bold text-stone-950">Send General Business Request</h3>
                      <p className="text-stone-500 text-xs sm:text-sm">Not ready with specific sizes? Write to us generally for partnership proposal, trading requests or catalog demands.</p>
                    </div>

                    <form onSubmit={handleSimpleFormSubmit} className="space-y-4">
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                            Your Name *
                          </label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Anand Sharma"
                            value={formInquiry.name}
                            onChange={(e) => setFormInquiry({...formInquiry, name: e.target.value})}
                            className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                            Mobile / WhatsApp *
                          </label>
                          <input
                            type="tel"
                            required
                            placeholder="e.g. +91 99887 76655"
                            value={formInquiry.phone}
                            onChange={(e) => setFormInquiry({...formInquiry, phone: e.target.value})}
                            className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                          Company Name / Shop Name (Optional)
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Sharma Grocery Store"
                          value={formInquiry.company}
                          onChange={(e) => setFormInquiry({...formInquiry, company: e.target.value})}
                          className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                          Enter Specific Sizing or Trading Requirement *
                        </label>
                        <textarea
                          required
                          rows={4}
                          placeholder="Please let us know which brand (Shuddh Premium / Rozana) or sizing mix you deal in, and ex-warehouse destination location."
                          value={formInquiry.requirement}
                          onChange={(e) => setFormInquiry({...formInquiry, requirement: e.target.value})}
                          className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-stone-900 hover:bg-emerald-900 text-white font-bold py-3.5 px-4 rounded-xl shadow-xs transition-colors flex items-center justify-center space-x-2 cursor-pointer"
                      >
                        <Send className="h-4 w-4" />
                        <span>{formSubmitted ? 'Drafting WhatsApp Message...' : 'Submit Partnership Query'}</span>
                      </button>

                    </form>
                  </div>

                  {/* General office coords */}
                  <div className="lg:col-span-5 bg-stone-50 rounded-3xl border border-stone-200 p-6 sm:p-8 flex flex-col justify-between">
                    <div className="space-y-6">
                      <div className="border-b border-stone-200 pb-4">
                        <h4 className="font-serif text-lg font-bold text-stone-900">Direct Contact Details</h4>
                        <p className="text-xs text-stone-500 mt-1">Get directly in touch with our headquarters for billing registrations.</p>
                      </div>

                      <div className="space-y-4 text-sm text-stone-700">
                        <div className="p-4 bg-white border border-stone-200 rounded-xl space-y-1 shadow-2xs">
                          <span className="text-[10px] font-mono font-bold text-stone-400 block uppercase">SALES HOTLINE</span>
                          <p className="flex items-center space-x-2 font-bold text-stone-900">
                            <Phone className="h-4.5 w-4.5 text-emerald-700" />
                            <a href="tel:+919555761477" className="hover:text-emerald-800">+91 95557 61477</a>
                          </p>
                          <p className="text-[11px] text-stone-500 pl-6">Support is available ex-warehouse 9:00 AM to 7:00 PM.</p>
                        </div>

                        <div className="p-4 bg-white border border-stone-200 rounded-xl space-y-1 shadow-2xs">
                          <span className="text-[10px] font-mono font-bold text-stone-400 block uppercase">EMAIL ENQUIRIES</span>
                          <p className="flex items-center space-x-2 font-bold text-stone-900">
                            <Mail className="h-4.5 w-4.5 text-emerald-700" />
                            <a href="mailto:amdtradingcompany11@gmail.com" className="hover:text-emerald-800">amdtradingcompany11@gmail.com</a>
                          </p>
                          <p className="text-[11px] text-stone-500 pl-6">We respond to email specs sheets within 24 hours.</p>
                        </div>

                        <div className="p-4 bg-white border border-stone-200 rounded-xl space-y-1 shadow-2xs">
                          <span className="text-[10px] font-mono font-bold text-stone-400 block uppercase">Head Office Address</span>
                          <p className="flex items-start space-x-2 font-semibold text-stone-900">
                            <MapPin className="h-4.5 w-4.5 text-emerald-700 shrink-0 mt-0.5" />
                            <span>B-50/A rishi nagar, chawla colony, ballabgarh, faridabad, haryana pincode 121004</span>
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* B2B compliance reminder */}
                    <div className="bg-emerald-50/60 border border-emerald-100 rounded-2xl p-4.5 mt-6 space-y-4">
                      <div>
                        <p className="text-xs text-emerald-950 font-bold leading-none mb-1">✓ GST Compliant Billing</p>
                        <p className="text-[11px] text-emerald-800 leading-normal">
                          Registered AMD Trading company bills will list standard makhana HSN codes with full tax clearing for cross-state road transport.
                        </p>
                      </div>
                      
                      <div className="border-t border-emerald-200/50 pt-3 flex items-center space-x-3">
                        <div className="flex flex-col justify-center items-center h-10 w-12 bg-white border border-emerald-500 rounded-lg select-none px-1 overflow-hidden shrink-0">
                          <div className="w-full bg-orange-500 text-[6px] text-white font-black text-center leading-none py-0.5 uppercase tracking-tighter font-mono">
                            INDIA
                          </div>
                          <div className="text-[10px] font-black italic text-emerald-600 leading-snug tracking-tighter font-serif">
                            fssai
                          </div>
                          <div className="w-full bg-blue-600 text-[4px] text-white font-bold text-center leading-none py-0.5 uppercase font-mono">
                            STANDARDS
                          </div>
                        </div>
                        <div>
                          <p className="text-[9px] text-emerald-800 font-mono font-bold leading-none uppercase tracking-wider">Governing Food Safety</p>
                          <p className="text-xs font-bold text-stone-900 font-mono mt-1">Lic. No. 20826004001411</p>
                        </div>
                      </div>
                    </div>

                  </div>

                </div>
              </section>

            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* Interactive Bottom-Right Customized AI Chatbot (AMD Makhana Sahayak) Widget */}
      <div id="amd-ai-chatbot-root" className="fixed bottom-6 right-6 z-50 flex flex-col items-end pointer-events-none">
        
        <AnimatePresence>
          {isChatOpen && (
            <motion.div
              id="amd-ai-chatbot-panel"
              initial={{ opacity: 0, scale: 0.85, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.85, y: 30 }}
              className="bg-white border-2 border-stone-150 rounded-3xl w-[320px] sm:w-[380px] h-[450px] sm:h-[500px] shadow-2xl flex flex-col overflow-hidden mb-4 pointer-events-auto"
            >
              {/* Chatbot Header */}
              <div className="bg-gradient-to-r from-stone-900 to-stone-850 text-white px-4 py-4.5 flex items-center justify-between border-b border-stone-800">
                <div className="flex items-center space-x-2.5">
                  <div className="bg-emerald-500/15 p-2 rounded-xl text-emerald-400 border border-emerald-500/20 relative">
                    <Sparkles className="h-4 w-4" />
                    <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span>
                    <span className="absolute -bottom-0.5 -right-0.5 w-2 h-2 bg-emerald-500 rounded-full"></span>
                  </div>
                  <div>
                    <h3 className="font-serif text-sm font-bold tracking-tight">AMD Makhana Sahayak</h3>
                    <p className="text-[10px] text-stone-400 flex items-center">
                      <span className="w-1 h-1 bg-emerald-400 rounded-full mr-1 animate-pulse"></span>
                      Active AI Advisor
                    </p>
                  </div>
                </div>
                <button
                  id="chatbot-close-btn"
                  onClick={() => setIsChatOpen(false)}
                  className="p-1 px-2 hover:bg-stone-800 rounded-lg text-stone-400 hover:text-white transition-colors cursor-pointer"
                  aria-label="Close Assistant"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Chatbot Messages - Scroll Area */}
              <div className="flex-grow overflow-y-auto p-4 space-y-3.5 bg-stone-50/50">
                {chatMessages.map((msg, idx) => (
                  <div
                    key={idx}
                    className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[82%] px-3.5 py-2.5 rounded-2xl text-xs gap-1 flex flex-col leading-relaxed ${
                        msg.role === 'user'
                          ? 'bg-stone-900 text-white rounded-tr-none shadow-xs font-medium'
                          : 'bg-white border border-stone-200 text-stone-800 rounded-tl-none shadow-3xs'
                      }`}
                    >
                      {msg.role === 'assistant' && (
                        <div className="flex items-center space-x-1 mb-1 border-b border-stone-100 pb-0.5">
                          <Bot className="h-3 w-3 text-emerald-600" />
                          <span className="text-[9px] font-bold text-stone-400 uppercase tracking-wider font-mono">AMD SAHAYAK</span>
                        </div>
                      )}
                      <p className="whitespace-pre-line">{msg.text}</p>
                    </div>
                  </div>
                ))}

                {isChatLoading && (
                  <div className="flex justify-start">
                    <div className="bg-white border border-stone-200 text-stone-800 px-3.5 py-2.5 rounded-2xl rounded-tl-none shadow-3xs flex items-center space-x-2">
                      <Loader2 className="h-3.5 w-3.5 animate-spin text-emerald-600" />
                      <span className="text-xs text-stone-400 font-medium select-none">Sahayak is drafting...</span>
                    </div>
                  </div>
                )}

                {/* Instant Quick-Action Suggestions */}
                {!isChatLoading && chatMessages.length < 5 && (
                  <div className="pt-2 space-y-1.5">
                    <p className="text-[9px] text-stone-400 uppercase tracking-wider font-bold">Suggested Quick Questions:</p>
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        onClick={() => handleSendChatMessage("What are the wholesale pricing options for Shuddh Premium vs Rozana?")}
                        className="bg-white hover:bg-stone-100 border border-stone-200 text-stone-700 px-2.5 py-1.5 rounded-xl text-[10.5px] font-semibold text-left select-none shadow-3xs cursor-pointer"
                      >
                        🌾 Shuddh vs Rozana Grades?
                      </button>
                      <button
                        onClick={() => handleSendChatMessage("What food safety standard certifications do you hold?")}
                        className="bg-white hover:bg-stone-100 border border-stone-200 text-stone-700 px-2.5 py-1.5 rounded-xl text-[10.5px] font-semibold text-left select-none shadow-3xs cursor-pointer"
                      >
                        ✓ FSSAI Food Safety license?
                      </button>
                      <button
                        onClick={() => handleSendChatMessage("Where is your head office, and what are the contact options?")}
                        className="bg-white hover:bg-stone-100 border border-stone-200 text-stone-700 px-2.5 py-1.5 rounded-xl text-[10.5px] font-semibold text-left select-none shadow-3xs cursor-pointer"
                      >
                        🏢 Head Office Address?
                      </button>
                      <button
                        onClick={() => handleSendChatMessage("How do you procure the makhana raw seeds and grade them?")}
                        className="bg-white hover:bg-stone-100 border border-stone-200 text-stone-700 px-2.5 py-1.5 rounded-xl text-[10.5px] font-semibold text-left select-none shadow-3xs cursor-pointer"
                      >
                        📍 Farmer Procurements?
                      </button>
                    </div>
                  </div>
                )}
                
                <div ref={chatEndRef} />
              </div>

              {/* Chatbot Input Footer */}
              <form
                id="chatbot-input-form"
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendChatMessage();
                }}
                className="p-3 bg-white border-t border-stone-150 space-y-2"
              >
                <div className="flex items-center space-x-1.5">
                  <input
                    id="chatbot-input-field"
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Type bulk specs or ask a question..."
                    disabled={isChatLoading}
                    className="flex-grow bg-stone-50 border border-stone-200 rounded-xl px-3.5 py-2 text-xs outline-hidden focus:bg-white focus:border-stone-400 font-medium text-stone-800"
                  />
                  <button
                    id="chatbot-send-btn"
                    type="submit"
                    disabled={isChatLoading || !chatInput.trim()}
                    className="p-2.5 bg-stone-900 text-white rounded-xl hover:bg-emerald-900 transition-colors disabled:opacity-40 flex items-center justify-center cursor-pointer"
                  >
                    <Send className="h-3.5 w-3.5" />
                  </button>
                </div>

                {/* Quick Link to Direct WhatsApp Hotline */}
                <div className="flex items-center justify-between text-[10.5px] pt-1.5 border-t border-stone-100 text-stone-500 font-medium">
                  <span>Need official ex-warehouse invoices?</span>
                  <button
                    type="button"
                    onClick={() => openWhatsAppGeneral("Hello! I would like to fetch bulk order custom quotes directly.")}
                    className="text-emerald-700 font-bold hover:underline flex items-center space-x-0.5 cursor-pointer ml-1"
                  >
                    <span>Connect WhatsApp</span>
                    <MessageSquare className="h-3 w-3 fill-emerald-700 text-emerald-700 ml-0.5" />
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Floating Triggers Block */}
        <div className="flex items-center space-x-3 pointer-events-auto">
          
          {/* Pulsing label, clicking open the AI Bot panel */}
          {!isChatOpen && (
            <button
              id="chatbot-trigger-pill"
              onClick={() => setIsChatOpen(true)}
              className="hidden sm:inline-flex bg-white hover:bg-stone-50 text-stone-800 border border-stone-200 px-3.5 py-2.5 rounded-xl text-xs font-bold shadow-md animate-bounce items-center space-x-2 shrink-0 cursor-pointer select-none"
            >
              <Sparkles className="h-3.5 w-3.5 text-amber-500 animate-pulse" />
              <span>Ask AMD AI Sahayak</span>
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span>
            </button>
          )}

          {/* Floating Circle Button */}
          <button
            id="chatbot-trigger-circle"
            onClick={() => setIsChatOpen(!isChatOpen)}
            className="bg-stone-950 hover:bg-stone-850 p-4 rounded-full text-white shadow-2xl transition-all duration-200 hover:scale-108 flex items-center justify-center border-2 border-white relative cursor-pointer"
            aria-label="Open AI Assistant"
          >
            {isChatOpen ? (
              <X className="h-6 w-6 relative z-10" />
            ) : (
              <>
                <span className="absolute inset-0 bg-stone-950 rounded-full scale-110 animate-ping opacity-20"></span>
                <Sparkles className="h-6 w-6 text-amber-400 relative z-10" />
              </>
            )}
          </button>
        </div>

      </div>

      {/* Bottom Footer Component */}
      <Footer setActivePage={(page) => {
        setActivePage(page);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }} />

    </div>
  );
}
