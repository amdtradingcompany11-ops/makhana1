/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ActivePage } from '../types';
import { Leaf, Phone, Mail, MapPin, ShieldCheck, ArrowRight } from 'lucide-react';

interface FooterProps {
  setActivePage: (page: ActivePage) => void;
}

export default function Footer({ setActivePage }: FooterProps) {
  const handleNav = (page: ActivePage) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer id="app-footer" className="bg-stone-900 text-stone-300 border-t-2 border-emerald-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 md:gap-12">
          
          {/* Company Brief */}
          <div className="md:col-span-1.5 space-y-4">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-emerald-950 border border-emerald-900 rounded-lg">
                <Leaf className="h-5 w-5 text-emerald-500" />
              </div>
              <span className="font-serif text-xl font-bold tracking-tight text-white">
                AMD <span className="text-emerald-500 font-sans font-semibold">Trading Co.</span>
              </span>
            </div>
            <p className="text-sm text-stone-400 leading-relaxed max-w-sm">
              We are premium makhana (foxnut) wholesalers and suppliers sourcing directly from Bihar’s finest harvests. Trusted by retailers, supermarket chains, and food processing brands nationwide for reliable, double-sorted supplies.
            </p>
            <div className="flex items-center space-x-3 bg-stone-800/50 border border-stone-800/80 p-2.5 rounded-xl w-fit">
              <div className="flex flex-col justify-center items-center h-10 w-12 bg-white border border-emerald-500 rounded-lg select-none px-1 overflow-hidden shrink-0">
                <div className="w-full bg-orange-500 text-[6px] text-white font-black text-center leading-none py-0.5 uppercase tracking-tighter font-mono">
                  INDIA
                </div>
                <div className="text-[10px] font-black italic text-emerald-600 leading-snug tracking-tighter">
                  fssai
                </div>
                <div className="w-full bg-blue-600 text-[4px] text-white font-bold text-center leading-none py-0.5 uppercase font-mono">
                  STANDARDS
                </div>
              </div>
              <div>
                <p className="text-[9px] text-stone-400 font-mono font-medium leading-none uppercase tracking-wider">Food Safety Certified</p>
                <p className="text-xs font-bold text-white font-mono mt-1">Lic. 20826004001411</p>
              </div>
            </div>
          </div>

          {/* Quick Nav Links */}
          <div className="space-y-4">
            <h4 className="text-white font-serif font-semibold text-sm tracking-widest uppercase">Quick Links</h4>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-emerald-400 flex items-center space-x-1 transition-colors text-stone-400 cursor-pointer">
                  <ArrowRight className="h-3 w-3 text-emerald-700" />
                  <span>Home Page</span>
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('products')} className="hover:text-emerald-400 flex items-center space-x-1 transition-colors text-stone-400 cursor-pointer">
                  <ArrowRight className="h-3 w-3 text-emerald-700" />
                  <span>Product Premium & Rozana</span>
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-emerald-400 flex items-center space-x-1 transition-colors text-stone-400 cursor-pointer">
                  <ArrowRight className="h-3 w-3 text-emerald-700" />
                  <span>Our Heritage & Process</span>
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('why-choose-us')} className="hover:text-emerald-400 flex items-center space-x-1 transition-colors text-stone-400 cursor-pointer">
                  <ArrowRight className="h-3 w-3 text-emerald-700" />
                  <span>Why Corporate Buyers Choose Us</span>
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-emerald-400 flex items-center space-x-1 transition-colors text-stone-400 cursor-pointer">
                  <ArrowRight className="h-3 w-3 text-emerald-700" />
                  <span>Submit Inquiry</span>
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('shop')} className="hover:text-emerald-400 flex items-center space-x-1 transition-colors text-stone-400 cursor-pointer">
                  <ArrowRight className="h-3 w-3 text-emerald-700" />
                  <span>Shop Retail Packets 🛒</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Our Brands */}
          <div className="space-y-4">
            <h4 className="text-white font-serif font-semibold text-sm tracking-widest uppercase">Our Brands</h4>
            <div className="space-y-3">
              <div className="p-3 bg-stone-800/55 rounded-lg border border-stone-800/40">
                <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider block">Premium Segment</span>
                <span className="text-sm font-semibold text-white block">Shuddh Premium Makhana</span>
                <span className="text-xs text-stone-400 block mt-0.5 font-mono">Grade 5 Suta, 5 Suta+, 6 Suta+ (Sortex Elite)</span>
              </div>
              <div className="p-3 bg-stone-800/55 rounded-lg border border-stone-800/40">
                <span className="text-xs font-semibold text-amber-500 uppercase tracking-wider block">Daily Segment</span>
                <span className="text-sm font-semibold text-white block">Rozana Makhana</span>
                <span className="text-xs text-stone-400 block mt-0.5 font-mono">Grade 3 Suta to 5 Suta (Daily Use Value)</span>
              </div>
            </div>
          </div>

          {/* Contact Details */}
          <div className="space-y-4">
            <h4 className="text-white font-serif font-semibold text-sm tracking-widest uppercase text-stone-400">Head Office Coordinates</h4>
            <ul className="space-y-3.5 text-sm text-stone-400">
              <li className="flex items-start space-x-2.5">
                <MapPin className="h-5 w-5 text-emerald-500 shrink-0 mt-0.5" />
                <span>
                  <strong>AMD Trading Company</strong><br />
                  B-50/A rishi nagar, chawla colony, ballabgarh,<br />
                  faridabad, haryana pincode 121004
                </span>
              </li>
              <li className="flex items-center space-x-2.5">
                <Phone className="h-4.5 w-4.5 text-emerald-500 shrink-0" />
                <a href="tel:+919555761477" className="hover:text-white transition-colors">
                  +91 95557 61477
                </a>
              </li>
              <li className="flex items-center space-x-2.5">
                <Mail className="h-4.5 w-4.5 text-emerald-500 shrink-0" />
                <a href="mailto:amdtradingcompany11@gmail.com" className="hover:text-white transition-colors">
                  amdtradingcompany11@gmail.com
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Legal Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-stone-800 text-center flex flex-col sm:flex-row justify-between items-center text-xs text-stone-500 gap-4">
          <p>© {currentYear} AMD Trading Company. All Rights Reserved. Processing, Supply and Packing of Premium Makhana.</p>
          <div className="flex space-x-4">
            <span>Direct Sourced</span>
            <span>•</span>
            <span>Hygienically Sorted</span>
            <span>•</span>
            <span>B2B Supplies Dedicated</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
