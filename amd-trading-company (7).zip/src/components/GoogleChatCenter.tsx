/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  MessageSquare, 
  Send, 
  CheckCircle, 
  Lock, 
  Settings, 
  RefreshCw, 
  AlertCircle, 
  Info, 
  HelpCircle, 
  LogOut, 
  ExternalLink,
  PlusCircle,
  Copy,
  Check,
  Smartphone,
  Sparkles,
  Layers,
  ChevronRight,
  Database
} from 'lucide-react';
import { auth } from '../firebase';
import { GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';

interface Space {
  name: string;
  displayName: string;
  spaceType: string;
}

export default function GoogleChatCenter() {
  const [user, setUser] = useState(auth.currentUser);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  
  const [spaces, setSpaces] = useState<Space[]>([]);
  const [isLoadingSpaces, setIsLoadingSpaces] = useState(false);
  const [spacesError, setSpacesError] = useState<string | null>(null);
  const [selectedSpace, setSelectedSpace] = useState<string>('');
  
  // Custom Webhook & Settings persistence
  const [webhookUrl, setWebhookUrl] = useState(() => localStorage.getItem('amd_google_chat_webhook') || '');
  const [autoPostOrders, setAutoPostOrders] = useState(() => localStorage.getItem('amd_auto_post_orders') === 'true');
  const [activeTab, setActiveTab] = useState<'dispatcher' | 'webhooks' | 'guide'>('dispatcher');
  
  // Dispatch Form State
  const [customSpaceId, setCustomSpaceId] = useState('');
  const [messageText, setMessageText] = useState('🛒 *AMD Trading Co. Sourcing Alert* \n\n• *Grade:* Shuddh Premium 6+ Suta\n• *Estimated Price:* ₹340 per kg ex-warehouse\n• *Status:* Fresh Sortex Batch Ready for Dispatch\n\n_Please confirm logistics allocation instructions via response._');
  const [isSending, setIsSending] = useState(false);
  const [sendSuccess, setSendSuccess] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((firebaseUser) => {
      setUser(firebaseUser);
      if (!firebaseUser) {
        setAccessToken(null);
        setSpaces([]);
      }
    });
    return () => unsubscribe();
  }, []);

  const triggerToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  const handleGoogleSignIn = async () => {
    setIsAuthLoading(true);
    setSpacesError(null);
    try {
      const provider = new GoogleAuthProvider();
      // Add Google Chat scopes
      provider.addScope('https://www.googleapis.com/auth/chat');
      provider.setCustomParameters({
        prompt: 'select_account'
      });

      const result = await signInWithPopup(auth, provider);
      const credential = GoogleAuthProvider.credentialFromResult(result);
      if (credential?.accessToken) {
        setAccessToken(credential.accessToken);
        triggerToast("Logged in successfully! Google Chat scopes granted.", "success");
        // Fetch spaces automatically
        fetchChatSpaces(credential.accessToken);
      } else {
        throw new Error("Unable to obtain Google Chat API access token from credential result.");
      }
    } catch (err: any) {
      console.error("Google Chat authentication error:", err);
      // Give a clear, clean message
      setSpacesError(err?.message || "Google Chat authentication not completed. Please try again.");
      triggerToast("Authentication failed", "error");
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
      setAccessToken(null);
      setSpaces([]);
      triggerToast("Logged out successfully.", "success");
    } catch (err) {
      console.error("Sign out error", err);
    }
  };

  const fetchChatSpaces = async (token = accessToken) => {
    if (!token) return;
    setIsLoadingSpaces(true);
    setSpacesError(null);
    try {
      const res = await fetch('https://chat.googleapis.com/v1/spaces', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        const errorDetails = await res.text();
        throw new Error(`Google API returned status ${res.status}: ${errorDetails}`);
      }
      const data = await res.json();
      setSpaces(data.spaces || []);
      if (data.spaces && data.spaces.length > 0) {
        setSelectedSpace(data.spaces[0].name);
      }
      triggerToast(`Discovered ${data.spaces?.length || 0} active Google Chat spaces`, "success");
    } catch (err: any) {
      console.error("Failed to fetch Google Chat Spaces:", err);
      setSpacesError(
        "Could not load Google Chat spaces. Note: personal @gmail.com accounts typically require manually specifying a space identifier, or use the incoming Webhook tab for public integrations."
      );
    } finally {
      setIsLoadingSpaces(false);
    }
  };

  const handleSaveWebhookSettings = () => {
    localStorage.setItem('amd_google_chat_webhook', webhookUrl);
    localStorage.setItem('amd_auto_post_orders', String(autoPostOrders));
    triggerToast("Saved Google Chat Webhook settings successfully!", "success");
  };

  // Dispatch message via Space API or Webhook
  const handlePostMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;

    setIsSending(true);
    setSendSuccess(false);
    setSendError(null);

    // Prompt user confirmation for a mutation/dispatch as mandated by security guidelines
    const userConfirmed = window.confirm(
      "Confirm action: Do you want to dispatch this message directly to Google Chat?"
    );
    if (!userConfirmed) {
      setIsSending(false);
      return;
    }

    try {
      // 1. Check if we should post to Webhook (Priority if active/entered)
      if (webhookUrl.trim()) {
        const res = await fetch(webhookUrl.trim(), {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: JSON.stringify({ text: messageText }),
        });

        if (!res.ok) {
          throw new Error(`Webhook dispatch failed. HTTP status ${res.status}`);
        }
        setSendSuccess(true);
        triggerToast("Message dispatched successfully over Webhook!", "success");
      } 
      // 2. Post to Space API if authenticated
      else {
        const spaceTarget = selectedSpace || customSpaceId.trim();
        if (!spaceTarget) {
          throw new Error("No space target selected or specified. Please sign-in with Google or define a Webhook.");
        }
        if (!accessToken) {
          throw new Error("Local access token is stale or missing. Please login with Google again.");
        }

        const cleanSpaceId = spaceTarget.startsWith('spaces/') ? spaceTarget : `spaces/${spaceTarget}`;
        const targetUrl = `https://chat.googleapis.com/v1/${cleanSpaceId}/messages`;

        const res = await fetch(targetUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: JSON.stringify({ text: messageText }),
        });

        if (!res.ok) {
          const detailStr = await res.text();
          throw new Error(`Chat Space dispatch failed: ${detailStr}`);
        }

        setSendSuccess(true);
        triggerToast("Message posted successfully to Google Chat space!", "success");
      }
    } catch (err: any) {
      console.error("Error dispatching message:", err);
      setSendError(err.message || "Unknown error occurred while communicating with Google Chat services.");
      triggerToast("Google Chat delivery failed", "error");
    } finally {
      setIsSending(false);
    }
  };

  const loadTemplate = (type: 'sourcing' | 'order' | 'mandi') => {
    if (type === 'sourcing') {
      setMessageText(
        `🛒 *AMD TRADING CO. - RAW SOURCING UPDATE*\n\n` +
        `• *Batch ID:* AMD-BATCH-770A\n` +
        `• *Size Grade:* Shuddh Premium (6+ Suta Super XL)\n` +
        `• *Total Harvest:* 1,500 kg ready for bagging\n` +
        `• *Current Cost:* ex-warehouse Mandi value ₹230/kg\n\n` +
        `💡 *Status:* double Sorted, 100% bleach free white puffs available. Reply if interested.`
      );
    } else if (type === 'order') {
      setMessageText(
        `📦 *NEW E-COMMERCE RETAIL CHECKOUT BOOKING!*\n\n` +
        `• *Order Reference:* AMD-R-${Math.floor(1000 + Math.random() * 9000)}\n` +
        `• *Buyer Recipient:* Anand Kumar\n` +
        `• *Contact Number:* 9876543210\n` +
        `• *Cart Allocation:* Shuddh Premium (250g) x5 pkts\n` +
        `• *Full Invoice Total:* ₹1,150/-\n` +
        `• *State Hub:* Delhi NCR Region (Delivery Area Charged)\n\n` +
        `🚚 _Awaiting dispatch assignment and airway tracking link billing confirmation..._`
      );
    } else {
      setMessageText(
        `🌾 *LIVE BIHAR MANDI MARKET SUMMARY*\n\n` +
        `• *Market Date:* ${new Date().toLocaleDateString()}\n` +
        `• *Average Premium Raw:* ₹18,500 per quintal\n` +
        `• *Shorter Mix Caliber (4-7 Suta):* Steady at ₹210/kg wholesale\n` +
        `• *Transport Transit:* Delhi/NCR highways clear for dispatch trucks\n\n` +
        `💡 _Report compiled by AMD Trading Co. Logistics Division._`
      );
    }
    triggerToast("Loaded template preview", "success");
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 font-sans text-stone-850">
      
      {/* Toast Notification */}
      {toast && (
        <div id="chat-toast" className={`fixed bottom-6 left-6 z-[60] flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg border text-xs font-semibold animate-bounce ${
          toast.type === 'success' 
            ? 'bg-emerald-50 text-emerald-850 border-emerald-200' 
            : 'bg-red-50 text-red-900 border-red-200'
        }`}>
          {toast.type === 'success' ? <CheckCircle className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
          <span>{toast.message}</span>
        </div>
      )}

      {/* Header Panel */}
      <div className="bg-stone-900 text-stone-100 rounded-3xl p-6 sm:p-8 relative overflow-hidden border-b-4 border-emerald-700 shadow-md">
        <div className="absolute inset-0 opacity-10 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2">
            <span className="bg-emerald-800 text-emerald-300 text-[10px] uppercase font-bold tracking-widest px-3 py-1 rounded-full border border-emerald-700/60 inline-flex items-center gap-1.5">
              <MessageSquare className="h-3 w-3 fill-current" /> Google Workspace Integration
            </span>
            <h1 className="text-3xl font-serif font-bold tracking-tight text-white">Google Chat Console</h1>
            <p className="text-stone-300 text-xs sm:text-sm max-w-2xl">
              Connect Google Chat Spaces or configure Incoming Webhooks. Push automated retail checkouts, bulk makhana bid specs, or daily logistics alerts directly to work chats.
            </p>
          </div>

          <div className="shrink-0 flex items-center gap-3">
            {user ? (
              <div className="bg-stone-800 border border-stone-700 rounded-2xl p-3 flex items-center gap-3">
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || "User"} className="h-9 w-9 rounded-full border border-stone-600" />
                ) : (
                  <div className="h-9 w-9 rounded-full bg-emerald-700 flex items-center justify-center font-bold text-white text-sm">
                    {user.displayName?.charAt(0) || user.email?.charAt(0) || "U"}
                  </div>
                )}
                <div className="text-left">
                  <span className="text-xs font-semibold block text-white leading-tight">{user.displayName || "Authenticated Team"}</span>
                  <span className="text-[9px] text-stone-400 block font-mono max-w-[130px] truncate">{user.email}</span>
                </div>
                <button 
                  onClick={handleSignOut}
                  title="Sign Out Google Workspace"
                  className="p-1.5 text-stone-400 hover:text-red-400 transition-colors cursor-pointer"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={handleGoogleSignIn}
                disabled={isAuthLoading}
                className="bg-white hover:bg-stone-100 text-stone-900 border border-stone-200 hover:-translate-y-0.5 shadow-sm transition-all rounded-xl py-3 px-5 text-xs font-bold font-sans flex items-center gap-2.5 cursor-pointer"
              >
                {isAuthLoading ? (
                  <RefreshCw className="h-4 w-4 animate-spin text-stone-600" />
                ) : (
                  <svg className="h-4.5 w-4.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path fill="#EA4335" d="M12.24 10.285V14.4h6.887c-.648 2.41-2.519 4.144-5.136 4.144-3.41 0-6.19-2.78-6.19-6.19s2.78-6.19 6.19-6.19c1.554 0 2.969.578 4.053 1.523l3.111-3.111C19.006 2.378 15.86 1 12.24 1c-6.075 0-11 4.925-11 11s4.925 11 11 11c5.8 0 10.665-4.225 11-10.285h-11z" />
                  </svg>
                )}
                <span>Activate Google Chat Account</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Primary Tab Selector */}
      <div className="flex border-b border-stone-200">
        <button
          onClick={() => setActiveTab('dispatcher')}
          className={`px-5 py-3 text-xs sm:text-sm font-semibold border-b-2 transition-all cursor-pointer ${
            activeTab === 'dispatcher'
              ? 'border-emerald-600 text-emerald-800 font-bold'
              : 'border-transparent text-stone-500 hover:text-stone-850'
          }`}
        >
          💬 Message Dispatcher Console
        </button>
        <button
          onClick={() => setActiveTab('webhooks')}
          className={`px-5 py-3 text-xs sm:text-sm font-semibold border-b-2 transition-all cursor-pointer ${
            activeTab === 'webhooks'
              ? 'border-emerald-600 text-emerald-800 font-bold'
              : 'border-transparent text-stone-500 hover:text-stone-850'
          }`}
        >
          🔌 Live Checkouts Webhooks
        </button>
        <button
          onClick={() => setActiveTab('guide')}
          className={`px-5 py-3 text-xs sm:text-sm font-semibold border-b-2 transition-all cursor-pointer ${
            activeTab === 'guide'
              ? 'border-emerald-600 text-emerald-800 font-bold'
              : 'border-transparent text-stone-500 hover:text-stone-850'
          }`}
        >
          📜 Integration Setup Guide
        </button>
      </div>

      {/* Tab Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Panel Content Left */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* TAB 1: DISPATCHER */}
          {activeTab === 'dispatcher' && (
            <div className="bg-white rounded-3xl border border-stone-200 shadow-xs p-6 space-y-6">
              <div className="space-y-1">
                <h3 className="font-serif text-lg font-bold text-stone-900 flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-emerald-700" /> Dispatcher Messaging Center
                </h3>
                <p className="text-stone-500 text-xs leading-relaxed">
                  Post formatted communication alerts direct to connected channels. Great for updating warehousing staff, logistics teams, or sales channels instantly.
                </p>
              </div>

              {/* Status checklist if there are no webhooks or oauth active */}
              {!user && !webhookUrl && (
                <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4 flex items-start gap-3.5 text-left">
                  <Info className="h-5 w-5 text-stone-500 shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-xs font-bold text-stone-900 leading-normal">Interactive Sandbox Notice</p>
                    <p className="text-[11px] text-stone-500 leading-relaxed font-sans">
                      You are not currently logged into a Google Workspace account and have no incoming Webhook Url registered. To experience live posts, either **Authenticate with your Google Account** above, or navigate to <strong>🔌 Live Checkouts Webhooks</strong> to paste a regular chat webhook.
                    </p>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs font-bold text-stone-500 self-center mr-1">Preloaded Snippets:</span>
                  <button 
                    onClick={() => loadTemplate('sourcing')}
                    className="bg-stone-50 hover:bg-stone-100 border border-stone-200 text-stone-700 text-[10px] font-semibold tracking-tight px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                  >
                    🌾 Sourced Bulk Batch
                  </button>
                  <button 
                    onClick={() => loadTemplate('order')}
                    className="bg-emerald-50 hover:bg-emerald-150 border border-emerald-100 text-emerald-800 text-[10px] font-semibold tracking-tight px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                  >
                    📦 Simulated Online Order
                  </button>
                  <button 
                    onClick={() => loadTemplate('mandi')}
                    className="bg-stone-50 hover:bg-stone-100 border border-stone-200 text-stone-700 text-[10px] font-semibold tracking-tight px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
                  >
                    💼 Mandi Stats Update
                  </button>
                </div>

                <form onSubmit={handlePostMessage} className="space-y-5">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 uppercase tracking-widest mb-1.5">
                      Destination Select Mode
                    </label>

                    {webhookUrl ? (
                      <div className="bg-emerald-50/50 border border-emerald-200/60 rounded-xl p-3 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-emerald-700" />
                          <span className="text-xs font-bold text-emerald-950 font-sans">Posting via Active Chat Webhook</span>
                        </div>
                        <span className="text-[9px] font-mono font-bold bg-emerald-200/40 border border-emerald-200 px-2.5 py-1 rounded-md text-emerald-800 uppercase leading-none">
                          Registered Link
                        </span>
                      </div>
                    ) : user ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="text-[10px] text-stone-500 font-bold block mb-1">Discovered Spaces List</label>
                          {isLoadingSpaces ? (
                            <div className="w-full bg-stone-50 border border-stone-200 py-2.5 px-3 rounded-xl flex items-center justify-center gap-2">
                              <RefreshCw className="h-3.5 w-3.5 animate-spin text-stone-500" />
                              <span className="text-xs text-stone-500 font-medium">Scanning spaces...</span>
                            </div>
                          ) : spaces.length > 0 ? (
                            <select
                              value={selectedSpace}
                              onChange={(e) => setSelectedSpace(e.target.value)}
                              className="w-full bg-stone-50 border border-stone-250 rounded-xl py-2.5 px-3 text-xs text-stone-850 font-medium focus:bg-white focus:border-emerald-600 outline-hidden"
                            >
                              {spaces.map((s) => (
                                <option key={s.name} value={s.name}>{s.displayName || s.name}</option>
                              ))}
                            </select>
                          ) : (
                            <div className="w-full bg-stone-50 border border-stone-200 py-2.5 px-3 rounded-xl text-left text-[11px] text-stone-500">
                              No spaces found on this account.
                            </div>
                          )}
                        </div>
                        <div>
                          <label className="text-[10px] text-stone-500 font-bold block mb-1">Custom Space Identifier Code</label>
                          <input 
                            type="text" 
                            placeholder="e.g. AAAAs_X3_g8"
                            value={customSpaceId}
                            onChange={(e) => setCustomSpaceId(e.target.value)}
                            className="w-full bg-stone-50 border border-stone-200 rounded-xl py-2.5 px-3 text-xs text-stone-850 font-mono outline-hidden focus:bg-white focus:border-emerald-600"
                          />
                        </div>
                      </div>
                    ) : (
                      <div className="bg-stone-50 border border-stone-200 rounded-xl p-3.5 text-center text-xs font-semibold text-stone-500">
                        Please sign in with Google or specify a Webhook in the next tab to route messages.
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-705 uppercase tracking-widest mb-1.5 flex justify-between items-center">
                      <span>Message String (supports Markdown Markup)</span>
                      <span className="text-[10px] text-stone-400 font-mono normal-case">text-only string</span>
                    </label>
                    <textarea
                      required
                      rows={6}
                      value={messageText}
                      onChange={(e) => setMessageText(e.target.value)}
                      placeholder="Type your message details here..."
                      className="w-full bg-stone-50 border border-stone-250 rounded-2xl p-4 text-xs font-mono text-stone-850 outline-hidden focus:bg-white focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600"
                    />
                    <p className="text-[9px] text-stone-450 mt-1.5 font-sans leading-relaxed">
                      💡 Tip: Use <strong className="font-bold text-stone-600">*bold*</strong> for headers, <strong className="font-bold text-stone-600">_italics_</strong> for status lines, and <strong className="font-bold text-stone-600">\n</strong> for line breaks. These look incredibly neat in Google Chat Cards!
                    </p>
                  </div>

                  {sendError && (
                    <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-left text-[11px] text-red-900 font-sans flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 shrink-0 mt-0.5" />
                      <div>
                        <strong className="font-bold">Error Posting Message:</strong> {sendError}
                      </div>
                    </div>
                  )}

                  {sendSuccess && (
                    <div className="bg-emerald-50 border border-emerald-250 rounded-xl p-3 text-left text-[11px] text-emerald-850 font-sans flex items-start gap-2.5 animate-pulse">
                      <CheckCircle className="h-4 w-4 shrink-0 text-emerald-700 mt-0.5" />
                      <div>
                        <strong className="font-bold">Dispatch Complete!</strong> Message posted to Google Chat. Verify your space or group chat.
                      </div>
                    </div>
                  )}

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      disabled={isSending || (!webhookUrl && !user)}
                      className={`w-full sm:w-auto bg-stone-900 hover:bg-emerald-900 text-white font-bold text-xs px-6 py-3 rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                        (!webhookUrl && !user) ? 'opacity-50 cursor-not-allowed' : ''
                      }`}
                    >
                      {isSending ? (
                        <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Send className="h-3.5 w-3.5" />
                      )}
                      <span>{isSending ? 'Sending to Google Chat...' : 'Dispatch Live Message'}</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* TAB 2: WEBHOOKS */}
          {activeTab === 'webhooks' && (
            <div className="bg-white rounded-3xl border border-stone-200 shadow-xs p-6 space-y-6">
              <div className="space-y-1">
                <h3 className="font-serif text-lg font-bold text-stone-900 flex items-center gap-2">
                  <Settings className="h-5 w-5 text-emerald-700" /> Incoming Webhook Configurations
                </h3>
                <p className="text-stone-500 text-xs leading-relaxed">
                  Incoming Webhooks provide an incredibly simple way to push store booking updates automatically into Google Chat channels without requiring manual team logins.
                </p>
              </div>

              <div className="space-y-4">
                <div className="bg-stone-50 border border-stone-200 rounded-2xl p-4.5 space-y-1">
                  <h4 className="text-xs font-bold text-stone-950">How to get a Google Chat Webhook URL?</h4>
                  <p className="text-[11px] text-stone-500 leading-relaxed font-sans">
                    1. Open Google Chat on your desktop browser.<br />
                    2. Expand the dropdown menu next to the target Space name &gt; Click <strong>Apps & Integrations</strong>.<br />
                    3. Click <strong>Webhooks</strong> &gt; Set name as <em>"AMD Store Assistant"</em> and choose an avatar.<br />
                    4. Click <strong>Save</strong> and copy the generated Webhook URL link &amp; paste below!
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-stone-750 uppercase mb-1">
                      Paste Google Chat Webhook URL Link
                    </label>
                    <input 
                      type="url"
                      placeholder="e.g. https://chat.googleapis.com/v1/spaces/AAAA.../webhooks/..."
                      value={webhookUrl}
                      onChange={(e) => setWebhookUrl(e.target.value)}
                      className="w-full bg-stone-50 border border-stone-250 focus:border-emerald-600 focus:bg-white rounded-xl px-3.5 py-3 text-xs font-mono text-stone-850 outline-hidden transition-all"
                    />
                  </div>

                  <div className="p-4 bg-emerald-50/50 border border-emerald-150 rounded-2xl space-y-3 text-left">
                    <div className="flex items-start justify-between">
                      <div className="space-y-0.5">
                        <label className="text-xs font-bold text-stone-900 block cursor-pointer" htmlFor="autoPostCheck">
                          Auto-Post Checkout Alerts
                        </label>
                        <p className="text-[10px] text-stone-500 font-sans leading-tight">
                          When checked, any retail shop booking completed by clients will instantly dispatch a detailed invoice message to this webhook space.
                        </p>
                      </div>
                      <input 
                        type="checkbox"
                        id="autoPostCheck"
                        checked={autoPostOrders}
                        onChange={(e) => setAutoPostOrders(e.target.checked)}
                        className="h-4.5 w-4.5 text-emerald-600 focus:ring-emerald-500 border-stone-300 rounded-md shrink-0 cursor-pointer"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <button
                      onClick={handleSaveWebhookSettings}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-5 py-2.5 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <CheckCircle className="h-3.5 w-3.5" />
                      <span>Save Webhook Rules</span>
                    </button>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 3: INTEGRATION SETUP GUIDE */}
          {activeTab === 'guide' && (
            <div className="bg-white rounded-3xl border border-stone-200 shadow-xs p-6 space-y-6">
              <div className="space-y-1">
                <h3 className="font-serif text-lg font-bold text-stone-900">
                  Google Workspace Chat Setup Instructions
                </h3>
                <p className="text-stone-500 text-xs">
                  A comprehensive developer summary to configure Google Workspace endpoints and credentials to receive live updates.
                </p>
              </div>

              <div className="space-y-5 text-xs text-stone-750 font-sans leading-relaxed">
                <div className="p-4.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-2">
                  <h4 className="font-bold text-emerald-850 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <PlusCircle className="h-4 w-4" /> 1. Enabling Scopes and Developer Console
                  </h4>
                  <p className="text-[11px] text-stone-500">
                    To authorize the Google Chat Space APIs, you must ensure that <strong>Google Chat API</strong> is enabled inside your Google Cloud Developer Console. Navigate to <strong>APIs & Services &gt; Library</strong> inside your GCP project and search for Chat.
                  </p>
                </div>

                <div className="p-4.5 bg-stone-50 border border-stone-200 rounded-2xl space-y-2">
                  <h4 className="font-bold text-emerald-850 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <Database className="h-4 w-4" /> 2. Real-Time Webhook Store Syncing Architecture
                  </h4>
                  <p className="text-[11px] text-stone-500">
                    When buyers submit digital invoices to our Firestore database, the applet reads the Webhook parameters from local storage and immediately executes an asynchronous broadcast payload. This simulates microservice dispatching, enabling warehouse handlers to prepare AMD makhana sacks for loading within seconds of payment checkout.
                  </p>
                </div>

                <div className="p-4.5 bg-stone-50 border border-stone-250 rounded-2xl space-y-2">
                  <h4 className="font-bold text-stone-950 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    <Layers className="h-4 w-4" /> 3. Card-Format Message Layouts
                  </h4>
                  <p className="text-[11px] text-stone-500">
                    The Google Chat REST endpoints allow card configurations which display thumbnail images, order breakdown tables, and quick action redirects. In addition to manual text alerts, our webhook module sends clean emojis and headers rendering beautifully inside both Mobile Chat apps and desktop chat panels.
                  </p>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Panel Sidebar Right */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Active Settings Summary */}
          <div className="bg-stone-50 border border-stone-200 rounded-3xl p-5 space-y-5">
            <h3 className="font-serif text-base font-bold text-stone-950 border-b border-stone-200 pb-2">
              System Connections
            </h3>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center text-xs">
                <span className="text-stone-500 font-medium">Google Account:</span>
                <span className={`font-semibold px-2.5 py-0.5 rounded-full text-[10px] uppercase font-mono ${
                  user ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-stone-200 text-stone-500'
                }`}>
                  {user ? 'Linked' : 'Disconnected'}
                </span>
              </div>

              <div className="flex justify-between items-center text-xs">
                <span className="text-stone-500 font-medium">Active Webhook:</span>
                <span className={`font-semibold px-2.5 py-0.5 rounded-full text-[10px] uppercase font-mono ${
                  webhookUrl ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-stone-200 text-stone-500'
                }`}>
                  {webhookUrl ? 'Configured' : 'None'}
                </span>
              </div>

              <div className="flex justify-between items-center text-xs">
                <span className="text-stone-500 font-medium">Auto-Post Store Orders:</span>
                <span className={`font-semibold px-2.5 py-0.5 rounded-full text-[10px] uppercase font-mono ${
                  autoPostOrders ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-stone-200 text-stone-500'
                }`}>
                  {autoPostOrders ? 'Enabled' : 'Disabled'}
                </span>
              </div>
            </div>

            <div className="bg-stone-900 text-stone-200 rounded-2xl p-3.5 border border-stone-800 shadow-2xs text-left space-y-2">
              <span className="text-[9px] font-mono text-emerald-400 font-bold uppercase tracking-wider block">Real-Time Payload Preview</span>
              <div className="text-[10px] font-mono text-stone-300 leading-normal max-h-[140px] overflow-hidden truncate">
                {"{"} <br />
                &nbsp;&nbsp;"text": "{messageText.split('\n')[0] || ''}..." <br />
                {"}"}
              </div>
              <span className="text-[8px] text-stone-400 block border-t border-stone-800 pt-1.5 font-sans">
                Matches expected Google Chat webhook JSON formatting specs.
              </span>
            </div>
          </div>

          {/* Quick Info Box */}
          <div className="bg-emerald-50/40 border border-emerald-100 rounded-3xl p-5 space-y-3 text-left">
            <h4 className="font-serif text-sm font-bold text-stone-900 flex items-center gap-1.5">
              <Sparkles className="h-4.5 w-4.5 text-emerald-700" /> B2B Logistics Perks
            </h4>
            <p className="text-xs text-stone-600 leading-relaxed font-sans">
              AMD Trading Co. serves large grain markets across Northern and Central India. Coupling checkout orders with dynamic Google Chat channels allows sales managers and shipping dispatch teams to process weight loads and truck clearings immediately!
            </p>
          </div>

        </div>

      </div>

    </div>
  );
}
