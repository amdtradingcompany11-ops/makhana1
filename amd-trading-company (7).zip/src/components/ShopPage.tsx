import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Order } from '../types';
import { 
  db, 
  auth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  RecaptchaVerifier, 
  signInWithPhoneNumber, 
  signOut, 
  onAuthStateChanged,
  collection, 
  doc, 
  getDoc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  getDocs, 
  onSnapshot, 
  serverTimestamp,
  handleFirestoreError,
  OperationType,
  ConfirmationResult
} from '../firebase';
import { IMAGES } from '../data/makhanaData';
import { 
  ShoppingBag, 
  Check, 
  Trash2, 
  Truck, 
  User, 
  MapPin, 
  Phone, 
  Mail, 
  Lock, 
  Download, 
  Search, 
  FileSpreadsheet, 
  TrendingUp, 
  ShoppingCart, 
  Plus, 
  Minus, 
  ArrowRight,
  Sparkles,
  ClipboardList,
  RefreshCw,
  Clock,
  Briefcase,
  CheckCircle2,
  LogIn,
  LogOut,
  Navigation,
  FileText,
  Bell,
  Volume2,
  MessageSquare,
  HelpCircle
} from 'lucide-react';


export const INDIAN_STATES_CITIES: Record<string, string[]> = {
  "Andhra Pradesh": ["Visakhapatnam", "Vijayawada", "Guntur", "Nellore", "Tirupati", "Kurnool", "Kakinada", "Rajamahendravaram", "Kadapa", "Anantapur", "Other"],
  "Arunachal Pradesh": ["Itanagar", "Naharlagun", "Pasighat", "Namsai", "Changlang", "Khonsa", "Tawang", "Ziro", "Other"],
  "Assam": ["Guwahati", "Dibrugarh", "Silchar", "Jorhat", "Nagaon", "Tinsukia", "Tezpur", "Bongaigaon", "Other"],
  "Bihar": ["Patna", "Gaya", "Bhagalpur", "Muzaffarpur", "Darbhanga", "Bihar Sharif", "Purnia", "Arrah", "Begusarai", "Madhubani", "Samastipur", "Katihar", "Other"],
  "Chhattisgarh": ["Raipur", "Bhilai", "Bilaspur", "Korba", "Rajnandgaon", "Jagdalpur", "Ambikapur", "Other"],
  "Goa": ["Panaji", "Margao", "Vasco da Gama", "Mapusa", "Ponda", "Other"],
  "Gujarat": ["Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Junagadh", "Gandhinagar", "Anand", "Morbi", "Vapi", "Navsari", "Other"],
  "Haryana": ["Faridabad", "Gurugram", "Panipat", "Ambala", "Yamunanagar", "Rohtak", "Hisar", "Karnal", "Sonipat", "Panchkula", "Bahadurgarh", "Other"],
  "Himachal Pradesh": ["Shimla", "Dharamshala", "Solan", "Mandi", "Bilaspur", "Kullu", "Hamirpur", "Other"],
  "Jharkhand": ["Ranchi", "Jamshedpur", "Dhanbad", "Bokaro Steel City", "Deoghar", "Phusro", "Hazaribagh", "Giridih", "Other"],
  "Karnataka": ["Bengaluru", "Mysuru", "Hubballi-Dharwad", "Mangaluru", "Belagavi", "Davanagere", "Ballari", "Kalaburagi", "Tumakuru", "Shivamogga", "Udupi", "Other"],
  "Kerala": ["Thiruvananthapuram", "Kochi", "Kozhikode", "Kollam", "Thrissur", "Alappuzha", "Palakkad", "Kannur", "Kottayam", "Other"],
  "Madhya Pradesh": ["Indore", "Bhopal", "Jabalpur", "Gwalior", "Ujjain", "Sagar", "Dewas", "Satna", "Ratlam", "Rewa", "Murwara", "Other"],
  "Maharashtra": ["Mumbai", "Pune", "Nagpur", "Thane", "Pimpri-Chinchwad", "Nashik", "Kalyan-Dombivli", "Vasai-Virar", "Aurangabad", "Navi Mumbai", "Solapur", "Kolhapur", "Other"],
  "Manipur": ["Imphal", "Churachandpur", "Thoubal", "Kakching", "Ukhrul", "Other"],
  "Meghalaya": ["Shillong", "Tura", "Nongpoh", "Jowai", "Baghmara", "Other"],
  "Mizoram": ["Aizawl", "Lunglei", "Champhai", "Kolasib", "Serchhip", "Other"],
  "Nagaland": ["Dimapur", "Kohima", "Mokokchung", "Tuensang", "Wokha", "Other"],
  "Odisha": ["Bhubaneswar", "Cuttack", "Rourkela", "Berhampur", "Sambalpur", "Puri", "Balasore", "Bhadrak", "Other"],
  "Punjab": ["Ludhiana", "Amritsar", "Jalandhar", "Patiala", "Bathinda", "Mohali", "Hoshiarpur", "Pathankot", "Moga", "Other"],
  "Rajasthan": ["Jaipur", "Jodhpur", "Kota", "Bikaner", "Ajmer", "Udaipur", "Bhilwara", "Alwar", "Sikar", "Sri Ganganagar", "Other"],
  "Sikkim": ["Gangtok", "Namchi", "Geyzing", "Mangan", "Jorethang", "Other"],
  "Tamil Nadu": ["Chennai", "Coimbatore", "Madurai", "Trichy", "Salem", "Tiruppur", "Erode", "Vellore", "Thoothukudi", "Tirunelveli", "Other"],
  "Telangana": ["Hyderabad", "Warangal", "Nizamabad", "Khammam", "Karimnagar", "Ramagundam", "Mahbubnagar", "Other"],
  "Tripura": ["Agartala", "Dharmanagar", "Udaipur", "Kailasahar", "Belonia", "Other"],
  "Uttar Pradesh": ["Lucknow", "Kanpur", "Ghaziabad", "Agra", "Meerut", "Varanasi", "Prayagraj", "Bareilly", "Aligarh", "Moradabad", "Saharanpur", "Gorakhpur", "Noida", "Greater Noida", "Firozabad", "Jhansi", "Mathura", "Other"],
  "Uttarakhand": ["Dehradun", "Haridwar", "Roorkee", "Haldwani", "Rudrapur", "Kashipur", "Rishikesh", "Other"],
  "West Bengal": ["Kolkata", "Howrah", "Darjeeling", "Siliguri", "Asansol", "Durgapur", "Bardhaman", "Malda", "Kharagpur", "Haldia", "Jalpaiguri", "Other"],
  "Andaman and Nicobar Islands": ["Port Blair", "Other"],
  "Chandigarh": ["Chandigarh", "Other"],
  "Dadra and Nagar Haveli and Daman and Diu": ["Daman", "Diu", "Silvassa", "Other"],
  "Delhi": ["New Delhi", "Delhi", "Rohini", "Dwarka", "Karol Bagh", "Shahdara", "Pitampura", "Connaught Place", "South Delhi", "West Delhi", "North Delhi", "East Delhi", "Faridabad NCR", "Gurugram NCR", "Noida NCR", "Other"],
  "Jammu and Kashmir": ["Srinagar", "Jammu", "Anantnag", "Baramulla", "Kathua", "Sopore", "Other"],
  "Ladakh": ["Leh", "Kargil", "Other"],
  "Lakshadweep": ["Kavaratti", "Minicoy", "Amini", "Other"],
  "Puducherry": ["Puducherry", "Karaikal", "Mahe", "Yanam", "Other"]
};

export const CATEGORIES = [
  { id: 'all', name: 'All Products', icon: '🛍️' },
  { id: 'packets', name: '250g Retail Packets', icon: '📦' },
  { id: 'suta-grades', name: 'Bulk Suta Grades (Min 10kg)', icon: '👑' }
];

export const SHOP_PRODUCTS = [
  {
    id: 'shuddh-premium',
    category: 'packets',
    name: 'Shuddh Premium Makhana',
    subtitle: 'Elite Handpicked White Gold Foxnuts',
    description: 'Double-sorted, premium export quality foxnuts in Airtight 250g retail packing. Flawless snowy white appearance, exceptionally large puff sizes, high crispiness, and zero debris.',
    price: 300,
    weight: '250g',
    features: ['Grade: Premium Jumbo Selection', 'Moisture level strictly under 5%', 'Highly crispy & fresh harvest', 'Ideal for premium gifting & daily nutrition'],
    image: IMAGES.shuddh || IMAGES.suta6,
    images: [IMAGES.shuddh || IMAGES.suta6],
    badge: 'Premium Segment',
    minQty: 1
  },
  {
    id: 'rozana-makhana',
    category: 'packets',
    name: 'Rozana Makhana',
    subtitle: 'High Nutrition Daily Consumer Foxnuts',
    description: 'Reliable, highly nutritious daily consumer grade makhana. Wholesome and ideal for high-volume processors, everyday home consumption, and general retail.',
    price: 250,
    weight: '250g',
    features: ['Standard Caliber Daily Pack', '100% natural, no bleach', 'Double-sorted for everyday roasting', 'Super affordable family choice'],
    image: IMAGES.rozana || IMAGES.sutaMix,
    images: [IMAGES.rozana || IMAGES.sutaMix],
    badge: 'Value Segment',
    minQty: 1
  },
  {
    id: 'suta-mix',
    category: 'packets',
    name: 'AMD All Suta Mix Makhana',
    subtitle: 'Natural Sorter Mix Puffs',
    description: 'A nutritious field-select mix of makhana puffs, combining sizes from 4 to 7 Suta. Double Sortex cleaned for standard domestic wholesale and general home snacking.',
    price: 230,
    weight: '250g',
    features: ['Grade: 4 to 7 Suta Mix', 'Hygienically Sortex Sorted', '100% Bleach Free Puffy White', 'High Plant-Based Protein Content'],
    image: IMAGES.sutaMix,
    images: [IMAGES.sutaMix],
    badge: 'Popular',
    minQty: 1
  },
  {
    id: 'suta-6',
    category: 'suta-grades',
    name: 'AMD 6+ Suta Premium Makhana',
    subtitle: 'Super XL Calibrated Puffs (Bulk)',
    description: 'Calibrated meticulously using 6+ Suta screens to guarantee magnificent size consistency and snowy white appearance. Extremely crispy with long shelf preservation.',
    price: 1250,
    weight: '1 kg',
    features: ['Grade: 6+ Suta Super XL Bulk', 'Double Sortex Cleaned & Polished', 'Less than 1% defective count', 'Minimum booking 10kg'],
    image: IMAGES.suta6,
    images: [IMAGES.suta6, IMAGES.suta5],
    badge: '6+ Suta Bulk',
    minQty: 10
  },
  {
    id: 'suta-5',
    category: 'suta-grades',
    name: 'AMD 5+ Suta Standard Makhana',
    subtitle: 'Calibrated Premium Family Pack (Bulk)',
    description: 'Perfect, mid-large makhana puffs sorted exactly with 5+ Suta grids. Excellent for regular homestyle roasting, health diets, gourmet soups, and dessert kheer applications.',
    price: 1000,
    weight: '1 kg',
    features: ['Grade: 5+ Suta Standard Large Bulk', 'Natural Crispy & Fresh Taste', 'Ideal density for spices adsorption', 'Minimum booking 10kg'],
    image: IMAGES.suta5,
    images: [IMAGES.suta5],
    badge: '5+ Suta Bulk',
    minQty: 10
  },
  {
    id: 'suta-4',
    category: 'suta-grades',
    name: 'AMD 4+ Suta Economy Makhana',
    subtitle: 'Compact Snacking Grade Foxnuts (Bulk)',
    description: 'Economical, standard snacking grade makhana. Contains exactly the same rich fibers, proteins, and minerals in a slightly smaller, highly affordable compact puff size.',
    price: 900,
    weight: '1 kg',
    features: ['Grade: 4+ Suta Compact Size Bulk', 'Excellent affordable prices', 'Hygienically sorted and packed', 'Minimum booking 10kg'],
    image: IMAGES.suta4,
    images: [IMAGES.suta4],
    badge: '4+ Suta Bulk',
    minQty: 10
  },
  {
    id: 'suta-4-pure',
    category: 'suta-grades',
    name: 'AMD 4 Suta Basic Makhana',
    subtitle: 'Core Value Snacking Foxnuts (Bulk)',
    description: 'Standard 4 suta basic makhana puffs, perfect for bulk roasted commercial snacks, grinding into makhana powder, or economy sorting lines at highly budget-friendly prices.',
    price: 650,
    weight: '1 kg',
    features: ['Grade: 4 Suta Core Size Bulk', 'Highly cost-effective segment', 'Pure natural crunchy makhana', 'Minimum booking 10kg'],
    image: IMAGES.suta4,
    images: [IMAGES.suta4],
    badge: '4 Suta Bulk',
    minQty: 10
  }
];

const ORDERS_STORAGE_KEY = 'amd_makhana_retail_orders';
const ACTIVE_USER_KEY = 'amd_active_customer';

interface CustomerUser {
  uid?: string; // Firebase Authentication UID
  name: string;
  phone: string;
  email?: string;
  address?: string;
  pincode?: string;
  city?: string;
  state?: string;
  avatarUrl?: string;
  authMethod: 'phone' | 'google';
  gstNumber?: string;
  createdAt?: any;
  updatedAt?: any;
}

const getStoredOrders = (): Order[] => {
  if (typeof window === 'undefined') return [];
  const stored = localStorage.getItem(ORDERS_STORAGE_KEY);
  if (!stored) {
    const seedOrders: Order[] = [
      {
        id: 'AMD-R-2001',
        date: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
        productName: 'Shuddh Premium Makhana',
        packetSize: '250g',
        quantity: 2,
        pricePerUnit: 399,
        totalPrice: 798,
        customerName: 'Anand Sharma',
        customerPhone: '9876543210',
        customerEmail: 'anand@gmail.com',
        address: 'Flat 402, Shiv Shakti Apartments, Sector 15',
        pincode: '110085',
        city: 'Rohini, New Delhi',
        state: 'Delhi',
        status: 'Delivered'
      },
      {
        id: 'AMD-R-2002',
        date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        productName: 'Rozana Makhana',
        packetSize: '250g',
        quantity: 3,
        pricePerUnit: 299,
        totalPrice: 897,
        customerName: 'Anand Sharma',
        customerPhone: '9876543210',
        customerEmail: 'anand@gmail.com',
        address: 'Flat 402, Shiv Shakti Apartments, Sector 15',
        pincode: '110085',
        city: 'Rohini, New Delhi',
        state: 'Delhi',
        status: 'Shipped'
      },
      {
        id: 'AMD-R-2003',
        date: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
        productName: 'Rozana Makhana',
        packetSize: '250g',
        quantity: 1,
        pricePerUnit: 299,
        totalPrice: 299,
        customerName: 'Priyanka Patel',
        customerPhone: '9554433221',
        customerEmail: 'priyanka.p@yahoo.com',
        address: '12-A, Shanti Nagar, Near Ganesh Temple',
        pincode: '400053',
        city: 'Andheri West, Mumbai',
        state: 'Maharashtra',
        status: 'Pending'
      }
    ];
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(seedOrders));
    return seedOrders;
  }
  try {
    return JSON.parse(stored);
  } catch (e) {
    return [];
  }
};

export const calculateShippingCharge = (stateName: string, items: Array<{ quantity: number, weight: string }>) => {
  if (!items || items.length === 0) return 0;
  
  const totalWeight = items.reduce((sum, item) => {
    const isBulk = item.weight.toLowerCase().includes('kg');
    const unitWeight = isBulk ? 1.0 : 0.25;
    return sum + (item.quantity * unitWeight);
  }, 0);

  const st = (stateName || 'Delhi').trim().toLowerCase();

  // Zone 1: Local / North (Delhi, Haryana, Punjab, Uttar Pradesh)
  if (st === 'delhi' || st === 'haryana' || st === 'punjab' || st === 'uttar pradesh') {
    const baseRate = 70;
    if (totalWeight <= 2) return baseRate;
    return baseRate + Math.ceil(totalWeight - 2) * 25;
  }
  // Zone 2: Central / West / East (Bihar, Rajasthan, Madhya Pradesh, Gujarat, West Bengal)
  else if (
    st === 'bihar' || 
    st === 'rajasthan' || 
    st === 'madhya pradesh' || 
    st === 'gujarat' || 
    st === 'west bengal'
  ) {
    const baseRate = 100;
    if (totalWeight <= 2) return baseRate;
    return baseRate + Math.ceil(totalWeight - 2) * 40;
  }
  // Zone 3: South / Rest of India & fallback (Maharashtra, Karnataka, Tamil Nadu, etc)
  else {
    const baseRate = 150;
    if (totalWeight <= 2) return baseRate;
    return baseRate + Math.ceil(totalWeight - 2) * 65;
  }
};

export default function ShopPage() {
  const [productsCatalog, setProductsCatalog] = useState<any[]>(SHOP_PRODUCTS);
  const [isShopifySynced, setIsShopifySynced] = useState<boolean>(false);
  const [shopifyDomain, setShopifyDomain] = useState<string>('');
  const [shopifySyncLoading, setShopifySyncLoading] = useState<boolean>(false);
  const [shopifySyncError, setShopifySyncError] = useState<string>('');

  const fetchShopifyProducts = async () => {
    setShopifySyncLoading(true);
    setShopifySyncError('');
    
    // Determine domains & tokens from env for client-side fallback
    const clientDomain = (import.meta.env.VITE_SHOPIFY_STORE_DOMAIN as string) || "shuddh-premium-makhana.myshopify.com";
    const clientToken = (import.meta.env.VITE_SHOPIFY_STOREFRONT_ACCESS_TOKEN as string) || "";

    try {
      // 1. Try server-side secure API proxy first
      const response = await fetch('/api/shopify/products');
      if (!response.ok) {
        throw new Error(`Server API returned status ${response.status} (Likely static-only deployment)`);
      }
      const data = await response.json();
      if (data.domain) {
        setShopifyDomain(data.domain);
      }
      if (data.isConfigured && data.products && data.products.length > 0) {
        setIsShopifySynced(true);
        setProductsCatalog([...data.products, ...SHOP_PRODUCTS]);
        setShopifySyncLoading(false);
        return;
      }
      throw new Error("Server proxy is unconfigured or returned no items.");
    } catch (err: any) {
      console.log("Server fetch could not be mapped, trying direct client-side fallback:", err.message);
      
      // 2. Client-side fallback if token is provided via VITE_ prefix
      if (clientToken) {
        try {
          const cleanDomain = clientDomain.replace(/https?:\/\//, "").split("/")[0];
          const url = `https://${cleanDomain}/api/2024-01/graphql.json`;
          
          const productsQuery = {
            query: `query GetProducts {
              products(first: 25) {
                edges {
                  node {
                    id
                    title
                    handle
                    description
                    productType
                    vendor
                    tags
                    images(first: 5) {
                      edges {
                        node {
                          url
                          altText
                        }
                      }
                    }
                    variants(first: 5) {
                      edges {
                        node {
                          id
                          title
                          weight
                          weightUnit
                          price {
                            amount
                            currencyCode
                          }
                        }
                      }
                    }
                  }
                }
              }
            }`
          };

          const directResp = await fetch(url, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "X-Shopify-Storefront-Access-Token": clientToken
            },
            body: JSON.stringify(productsQuery)
          });

          if (!directResp.ok) {
            throw new Error(`Shopify returned status ${directResp.status}`);
          }

          const directBody = await directResp.json();
          if (directBody.errors) {
            throw new Error(directBody.errors[0]?.message || "Shopify GraphQL error");
          }

          const rawProducts = directBody.data?.products?.edges || [];
          const mappedProducts = rawProducts.map((edge: any) => {
            const node = edge.node;
            const firstVariant = node.variants?.edges?.[0]?.node;
            const weightVal = firstVariant?.weight 
              ? `${firstVariant.weight} ${firstVariant.weightUnit || "kg"}` 
              : "250g";

            const featuresStr = node.tags?.length > 0 
              ? node.tags.slice(0, 4) 
              : ["Authentic Premium Grade", "Sourced and Popped Fresh", "Zero Bleach or Added Chemicals", "Quality Certified"];

            const tagsString = (node.tags || []).join(" ").toLowerCase();
            const typeString = (node.productType || "").toLowerCase();
            let category = "packets";
            if (tagsString.includes("suta") || tagsString.includes("bulk") || typeString.includes("bulk") || typeString.includes("wholesale")) {
              category = "suta-grades";
            }

            const variantsList = (node.variants?.edges || []).map((vEdge: any) => {
              let variantPrice = parseFloat(vEdge.node.price?.amount || "0");
              if (variantPrice === 100) {
                variantPrice = 300;
              }
              return {
                id: vEdge.node.id,
                numericId: vEdge.node.id.split("/").pop() || "",
                title: vEdge.node.title,
                price: variantPrice,
                weight: vEdge.node.weight ? `${vEdge.node.weight} ${vEdge.node.weightUnit || "kg"}` : ""
              };
            });

            let originalPrice = parseFloat(firstVariant?.price?.amount || "0");
            if (originalPrice === 100) {
              originalPrice = 300;
            }

            return {
              id: node.id,
              shopifyId: node.id,
              handle: node.handle,
              category: category,
              name: node.title,
              subtitle: node.vendor || "AMD Imported Partner Lot",
              description: node.description || "Premium graded popped Lotus Seeds, sourced fresh and processed at high-safety calibration grids.",
              price: originalPrice,
              weight: weightVal,
              features: featuresStr,
              image: node.images?.edges?.[0]?.node?.url || "https://images.unsplash.com/photo-1608686207856-001b95cf60ca?auto=format&fit=crop&q=80&w=600",
              images: node.images?.edges?.map((imgEdge: any) => imgEdge.node.url) || [],
              badge: node.productType || "Shopify Live",
              minQty: category === "suta-grades" ? 10 : 1,
              variants: variantsList,
              activeVariantId: firstVariant?.id || ""
            };
          });

          setShopifyDomain(cleanDomain);
          setIsShopifySynced(true);
          setProductsCatalog([...mappedProducts, ...SHOP_PRODUCTS]);
          return;
          
        } catch (directErr: any) {
          console.error("Client fallback sync failed:", directErr);
          setShopifySyncError(directErr.message || "Failed client-side sync fallback");
        }
      }

      setShopifyDomain(clientDomain);
      setIsShopifySynced(false);
      setProductsCatalog(SHOP_PRODUCTS);
      setShopifySyncError(err.message || "Failed to sync catalog server proxy. Define client env configs or import token.");
    } finally {
      setShopifySyncLoading(false);
    }
  };

  useEffect(() => {
    fetchShopifyProducts();
  }, []);

  const [orders, setOrders] = useState<Order[]>([]);
  const [activeTab, setActiveTab] = useState<'shop' | 'track' | 'admin'>('shop');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Auth state
  const [activeUser, setActiveUser] = useState<CustomerUser | null>(null);
  const [authStep, setAuthStep] = useState<'none' | 'login' | 'register' | 'otp_verification' | 'google_window'>('none');
  const [authPhone, setAuthPhone] = useState('');
  const [authName, setAuthName] = useState('');
  const [authEmail, setAuthEmail] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [otpTimer, setOtpTimer] = useState(60);
  const [otpError, setOtpError] = useState('');
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [bypassPhoneAuth, setBypassPhoneAuth] = useState(false);

  // Cart State (Keys are product IDs e.g. suta-mix, suta-6, etc)
  const [cart, setCart] = useState<Record<string, number>>({
    'suta-mix': 1
  });

  // Admin Dashboard State
  const [adminPin, setAdminPin] = useState('');
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [pinError, setPinError] = useState('');
  const [adminSearch, setAdminSearch] = useState('');

  // Active tracking ID query
  const [trackingId, setTrackingId] = useState('');
  const [searchedTrackingId, setSearchedTrackingId] = useState('');
  const [liveTrackedOrder, setLiveTrackedOrder] = useState<Order | null>(null);
  const [trackingError, setTrackingError] = useState('');

  // Checkout Form State (autofills if customer logged in)
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    pincode: '',
    city: '',
    state: 'Delhi',
    gstNumber: ''
  });

  // Success State
  const [placedOrder, setPlacedOrder] = useState<Order | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Toast state matching high quality elegant branding
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [activeImageIndexes, setActiveImageIndexes] = useState<Record<string, number>>({});

  // Merchant Notification Configuration States
  const [notifyGchatWebhook, setNotifyGchatWebhook] = useState(() => localStorage.getItem('amd_google_chat_webhook') || '');
  const [notifyGchatEnabled, setNotifyGchatEnabled] = useState(() => localStorage.getItem('amd_auto_post_orders') === 'true');
  const [notifyWaPhone, setNotifyWaPhone] = useState(() => localStorage.getItem('amd_whatsapp_notify_phone') || '');
  const [notifyWaApikey, setNotifyWaApikey] = useState(() => localStorage.getItem('amd_whatsapp_notify_apikey') || '');
  const [notifyWaEnabled, setNotifyWaEnabled] = useState(() => localStorage.getItem('amd_whatsapp_notify_enabled') === 'true');
  const [notifyCustomWebhook, setNotifyCustomWebhook] = useState(() => localStorage.getItem('amd_custom_webhook_url') || '');
  const [notifyCustomEnabled, setNotifyCustomEnabled] = useState(() => localStorage.getItem('amd_custom_webhook_enabled') === 'true');
  const [notifySoundAlerts, setNotifySoundAlerts] = useState(() => localStorage.getItem('amd_sound_alerts_enabled') !== 'false');
  const [notifyDesktopEnabled, setNotifyDesktopEnabled] = useState(() => localStorage.getItem('amd_desktop_notifications_enabled') === 'true');

  // Product Detail View state
  const [selectedProduct, setSelectedProduct] = useState<any | null>(null);
  const [detailQty, setDetailQty] = useState<number>(1);
  const [activeDetailImageIdx, setActiveDetailImageIdx] = useState<number>(0);
  const [showDirectCheckout, setShowDirectCheckout] = useState<boolean>(false);
  const [localDirectForm, setLocalDirectForm] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    pincode: '',
    city: '',
    state: 'Delhi',
    gstNumber: ''
  });

  useEffect(() => {
    if (selectedProduct) {
      setDetailQty(selectedProduct.minQty || 1);
      setActiveDetailImageIdx(0);
      setShowDirectCheckout(false);
      setLocalDirectForm({
        name: formData.name || activeUser?.name || '',
        phone: formData.phone || activeUser?.phone || '',
        email: formData.email || activeUser?.email || '',
        address: formData.address || activeUser?.address || '',
        pincode: formData.pincode || activeUser?.pincode || '',
        city: formData.city || activeUser?.city || '',
        state: formData.state || activeUser?.state || 'Delhi',
        gstNumber: formData.gstNumber || activeUser?.gstNumber || ''
      });
    }
  }, [selectedProduct, formData, activeUser]);

  const showToastMessage = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
  };

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

    // Synchronize onAuthStateChanged with Firestore User Profile and Orders Collection
    useEffect(() => {
      // Make sure we carry legacy/local seed orders on load as well
      setOrders(getStoredOrders());
      
      const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
        if (firebaseUser) {
          try {
            if (!firebaseUser.isAnonymous) {
              const userDocRef = doc(db, 'users', firebaseUser.uid);
              const userSnap = await getDoc(userDocRef);
              
              let userData: CustomerUser;
              if (userSnap.exists()) {
                userData = userSnap.data() as CustomerUser;
                setActiveUser(userData);
                localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(userData));
                
                // Prefill checkout form
                setFormData(prev => ({
                  ...prev,
                  name: userData.name || firebaseUser.displayName || prev.name,
                  phone: userData.phone || firebaseUser.phoneNumber?.replace('+91', '') || prev.phone,
                  email: userData.email || firebaseUser.email || prev.email,
                  address: userData.address || prev.address,
                  pincode: userData.pincode || prev.pincode,
                  city: userData.city || prev.city,
                  state: userData.state || prev.state
                }));
              } else {
                // New register
                const sanitizedPhone = firebaseUser.phoneNumber?.replace('+91', '') || '';
                const freshUser: CustomerUser = {
                  uid: firebaseUser.uid,
                  name: firebaseUser.displayName || authName || 'Makhana Enthusiast',
                  phone: authPhone || sanitizedPhone || '9876543210',
                  email: firebaseUser.email || authEmail || '',
                  authMethod: firebaseUser.providerData[0]?.providerId === 'google.com' ? 'google' : 'phone',
                  avatarUrl: firebaseUser.photoURL || `https://api.dicebear.com/7.x/pixel-art/svg?seed=${firebaseUser.uid}`,
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp()
                };
                
                await setDoc(userDocRef, freshUser);
                setActiveUser(freshUser);
                localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(freshUser));
                
                setFormData(prev => ({
                  ...prev,
                  name: freshUser.name,
                  phone: freshUser.phone || prev.phone,
                  email: freshUser.email || prev.email,
                  address: freshUser.address || prev.address,
                  pincode: freshUser.pincode || prev.pincode,
                  city: freshUser.city || prev.city,
                  state: freshUser.state || prev.state
                }));
              }
            } else {
              // Anonymous guest user - resolve local user attributes profile from storage if available
              const savedUser = localStorage.getItem(ACTIVE_USER_KEY);
              if (savedUser) {
                try {
                  const u = JSON.parse(savedUser) as CustomerUser;
                  setActiveUser(u);
                } catch (e) {}
              }
            }

            // Pull real Orders where userId == current authenticated client UID from Firestore for verified or anonymous users
            const q = query(collection(db, 'orders'), where('userId', '==', firebaseUser.uid));
            const unsubOrders = onSnapshot(q, (snapshot) => {
              const fbOrders: Order[] = [];
              snapshot.forEach((snapDoc) => {
                const oData = snapDoc.data();
                const orderDateIso = oData.date?.toDate 
                  ? oData.date.toDate().toISOString() 
                  : (oData.date || new Date().toISOString());
                
                fbOrders.push({
                  id: snapDoc.id,
                  date: orderDateIso,
                  productName: oData.productName,
                  packetSize: oData.packetSize || '250g',
                  quantity: oData.quantity,
                  pricePerUnit: oData.pricePerUnit,
                  totalPrice: oData.totalPrice,
                  customerName: oData.customerName,
                  customerPhone: oData.customerPhone,
                  customerEmail: oData.customerEmail,
                  address: oData.address,
                  pincode: oData.pincode,
                  city: oData.city,
                  state: oData.state,
                  status: oData.status
                });
              });

              setOrders(prev => {
                const combinedList = [...fbOrders];
                prev.forEach((prevItem) => {
                  if (!combinedList.some(item => item.id === prevItem.id)) {
                    combinedList.push(prevItem);
                  }
                });
                return combinedList;
              });
            }, (err) => {
              console.error("Firestore orders listen blocked: ", err);
            });

            return () => {
              unsubOrders();
            };

          } catch (err) {
            console.error("Firebase synchronizing payload failed: ", err);
          }
      } else {
        const savedUser = localStorage.getItem(ACTIVE_USER_KEY);
        if (savedUser) {
          try {
            const u = JSON.parse(savedUser) as CustomerUser;
            if (!u.uid) {
              setActiveUser(u);
            } else {
              setActiveUser(null);
              localStorage.removeItem(ACTIVE_USER_KEY);
            }
          } catch (e) {
            setActiveUser(null);
          }
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // Timer for OTP Countdowns
  useEffect(() => {
    let interval: any;
    if (authStep === 'otp_verification' && otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer(prev => prev - 1);
      }, 1005);
    }
    return () => clearInterval(interval);
  }, [authStep, otpTimer]);

  // Synchronize ALL live orders on real-time snapshot when admin PIN details verify
  useEffect(() => {
    if (!isAdminAuthenticated) return;

    try {
      const q = query(collection(db, 'orders'));
      const unsubAllOrders = onSnapshot(q, (snapshot) => {
        const fbOrders: Order[] = [];
        snapshot.forEach((snapDoc) => {
          const oData = snapDoc.data();
          const orderDateIso = oData.date?.toDate 
            ? oData.date.toDate().toISOString() 
            : (oData.date || new Date().toISOString());
          
          fbOrders.push({
            id: snapDoc.id,
            date: orderDateIso,
            productName: oData.productName,
            packetSize: oData.packetSize || '250g',
            quantity: Number(oData.quantity),
            pricePerUnit: Number(oData.pricePerUnit),
            totalPrice: Number(oData.totalPrice),
            customerName: oData.customerName,
            customerPhone: oData.customerPhone,
            customerEmail: oData.customerEmail,
            address: oData.address,
            pincode: oData.pincode,
            city: oData.city,
            state: oData.state,
            status: oData.status,
            gstNumber: oData.gstNumber
          });
        });

        setOrders(prev => {
          // Merge unique orders, prioritizing newer live values from db
          const combined = [...fbOrders];
          prev.forEach((prevItem) => {
            if (!combined.some(item => item.id === prevItem.id)) {
              combined.push(prevItem);
            }
          });
          // Sort by date descending
          return combined.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        });
      }, (err) => {
        console.warn("Global admin real-time listener blocked. Ensure Merchant Google login completed. Falling back to local/cached queries. Details:", err);
      });

      return () => {
        unsubAllOrders();
      };
    } catch (e) {
      console.warn("Could not initiate global real-time admin listener:", e);
    }
  }, [isAdminAuthenticated]);

  const adminInitialLoadRef = React.useRef(false);
  const adminPrevOrdersCountRef = React.useRef<number | null>(null);

  // Real-time sound chime and desktop alerts for Admin
  useEffect(() => {
    if (!isAdminAuthenticated) {
      adminInitialLoadRef.current = false;
      adminPrevOrdersCountRef.current = null;
      return;
    }

    if (adminPrevOrdersCountRef.current === null) {
      adminPrevOrdersCountRef.current = orders.length;
      const t = setTimeout(() => {
        adminInitialLoadRef.current = true;
      }, 3500);
      return () => clearTimeout(t);
    }

    if (adminInitialLoadRef.current && orders.length > adminPrevOrdersCountRef.current) {
      const newlyReceivedOrder = orders[0]; // sorted descending
      if (newlyReceivedOrder) {
        // Trigger browser audio chime
        const activeSound = localStorage.getItem('amd_sound_alerts_enabled') !== 'false';
        if (activeSound) {
          playNotificationSound();
        }

        // Trigger native browser push notification
        const activeDesktop = localStorage.getItem('amd_desktop_notifications_enabled') === 'true';
        if (activeDesktop && 'Notification' in window && Notification.permission === 'granted') {
          new Notification('🛒 New AMD Order Recieved!', {
            body: `Order ${newlyReceivedOrder.id} from ${newlyReceivedOrder.customerName} for ₹${newlyReceivedOrder.totalPrice}/-`,
            icon: 'https://api.dicebear.com/7.x/pixel-art/svg?seed=makhana'
          });
        }

        showToastMessage(`📢 NEW ORDER: Received Order ${newlyReceivedOrder.id} from ${newlyReceivedOrder.customerName} for ₹${newlyReceivedOrder.totalPrice}/-!`, 'success');
      }
    }

    adminPrevOrdersCountRef.current = orders.length;
  }, [orders, isAdminAuthenticated]);

  const handleSaveNotificationSettings = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    localStorage.setItem('amd_google_chat_webhook', notifyGchatWebhook);
    localStorage.setItem('amd_auto_post_orders', notifyGchatEnabled ? 'true' : 'false');
    localStorage.setItem('amd_whatsapp_notify_phone', notifyWaPhone);
    localStorage.setItem('amd_whatsapp_notify_apikey', notifyWaApikey);
    localStorage.setItem('amd_whatsapp_notify_enabled', notifyWaEnabled ? 'true' : 'false');
    localStorage.setItem('amd_custom_webhook_url', notifyCustomWebhook);
    localStorage.setItem('amd_custom_webhook_enabled', notifyCustomEnabled ? 'true' : 'false');
    localStorage.setItem('amd_sound_alerts_enabled', notifySoundAlerts ? 'true' : 'false');
    localStorage.setItem('amd_desktop_notifications_enabled', notifyDesktopEnabled ? 'true' : 'false');
    
    showToastMessage('Notification settings saved and active!', 'success');
  };

  const handleToggleDesktopNotifications = async () => {
    if (!('Notification' in window)) {
      showToastMessage('This browser does not support push notifications.', 'error');
      return;
    }

    if (Notification.permission === 'granted') {
      const newVal = !notifyDesktopEnabled;
      setNotifyDesktopEnabled(newVal);
      localStorage.setItem('amd_desktop_notifications_enabled', newVal ? 'true' : 'false');
      showToastMessage(newVal ? 'Desktop notifications enabled!' : 'Desktop notifications disabled.', 'info');
      return;
    }

    const permission = await Notification.requestPermission();
    if (permission === 'granted') {
      setNotifyDesktopEnabled(true);
      localStorage.setItem('amd_desktop_notifications_enabled', 'true');
      showToastMessage('Push permission granted! Test message dispatched.', 'success');
      new Notification('🔔 AMD Trading Company Notifier', {
        body: 'Automated order notifications active on this device!',
        icon: 'https://api.dicebear.com/7.x/pixel-art/svg?seed=makhana'
      });
    } else {
      showToastMessage('Permission denied for browser alerts.', 'error');
    }
  };

  const handleTestWhatsAppCallMeBot = async () => {
    if (!notifyWaPhone || !notifyWaApikey) {
      showToastMessage('Please save your WhatsApp Phone & CallMeBot API key first.', 'error');
      return;
    }

    showToastMessage(`Sending test WhatsApp to ${notifyWaPhone}...`, 'info');
    try {
      const callmebotUrl = `https://api.callmebot.com/whatsapp.php?phone=${notifyWaPhone.trim()}&text=${encodeURIComponent('🔔 *AMD Trading Company Alert test!* Your automated WhatsApp order notifications are working correctly.')}&apikey=${notifyWaApikey.trim()}`;
      await fetch(callmebotUrl);
      showToastMessage('Test WhatsApp request dispatched! Please check your phone.', 'success');
    } catch (e) {
      showToastMessage('WhatsApp request dispatched. If you cleared signup on CallMeBot, it should arrive.', 'success');
    }
  };

  const handleTestGoogleChatWebhookUrl = async () => {
    if (!notifyGchatWebhook) {
      showToastMessage('Please setup your Google Chat Webhook URL first.', 'error');
      return;
    }

    showToastMessage('Sending test Webhook payload...', 'info');
    try {
      await fetch(notifyGchatWebhook.trim(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: JSON.stringify({ text: '🔔 *AMD Trading Company Webhook test!* Your automated order notifications are working correctly.' }),
      });
      showToastMessage('Test Webhook posted successfully!', 'success');
    } catch (e) {
      showToastMessage('Failed to dispatch webhook: ' + String(e), 'error');
    }
  };

  const handleQtyChange = (key: string, val: number) => {
    const product = productsCatalog.find(p => p.id === key);
    const min = product?.minQty || 1;
    const currentVal = cart[key] || 0;
    let finalVal = Math.max(0, val);
    
    if (finalVal > 0 && finalVal < min) {
      if (val < currentVal) {
        finalVal = 0; // Decrease below minimum -> remove from cart
      } else {
        finalVal = min; // Increase from zero -> snap to minimum
      }
    }

    setCart(prev => ({
      ...prev,
      [key]: finalVal
    }));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // Dynamic calculations supporting NexDrop Mart categories
  const cartSummaryItems = Object.entries(cart)
    .filter(([_, qty]) => Number(qty) > 0)
    .map(([productId, qty]) => {
      const q = Number(qty);
      const product = productsCatalog.find(p => p.id === productId);
      return product ? { ...product, quantity: q, total: (product.price || 0) * q } : null;
    })
    .filter((item): item is (any & { quantity: number; total: number }) => item !== null);

  const cartSubtotal = cartSummaryItems.reduce((sum, item) => sum + item.total, 0);
  const shippingCharge = calculateShippingCharge(formData.state, cartSummaryItems);
  const grandTotal = cartSubtotal + shippingCharge;
  const totalQtyOfAllPresents = cartSummaryItems.reduce((sum, item) => sum + item.quantity, 0);

  const playNotificationSound = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      
      // Warm double-chime beep
      const osc1 = audioCtx.createOscillator();
      const gain1 = audioCtx.createGain();
      osc1.connect(gain1);
      gain1.connect(audioCtx.destination);
      osc1.frequency.setValueAtTime(587.33, audioCtx.currentTime); // D5
      gain1.gain.setValueAtTime(0.25, audioCtx.currentTime);
      gain1.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.12);
      osc1.start(audioCtx.currentTime);
      osc1.stop(audioCtx.currentTime + 0.12);
      
      const osc2 = audioCtx.createOscillator();
      const gain2 = audioCtx.createGain();
      osc2.connect(gain2);
      gain2.connect(audioCtx.destination);
      osc2.frequency.setValueAtTime(880, audioCtx.currentTime + 0.12); // A5
      gain2.gain.setValueAtTime(0.25, audioCtx.currentTime + 0.12);
      gain2.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.35);
      osc2.start(audioCtx.currentTime + 0.12);
      osc2.stop(audioCtx.currentTime + 0.35);
    } catch (err) {
      console.warn("Could not play notification alert audio chime:", err);
    }
  };

  const triggerMerchantAlerts = async (order: Order, isDirect: boolean = false) => {
    try {
      const orderItemsText = isDirect && selectedProduct
        ? `- ${selectedProduct.name} (${selectedProduct.weight}) x ${detailQty} ${selectedProduct.weight === '1 kg' ? 'kg' : 'Pkt'} [₹${selectedProduct.price * detailQty}/-]`
        : cartSummaryItems.map(
            item => `- ${item.name} (${item.weight}) x ${item.quantity} ${item.weight === '1 kg' ? 'kg' : 'Pkt'} [₹${item.total}/-]`
          ).join('\n');

      const deliveryChargeVal = order.deliveryCharge !== undefined ? order.deliveryCharge : 0;
      const subTotalVal = order.subTotal !== undefined ? order.subTotal : order.totalPrice;

      const summaryText = `🛒 *NEW AMD RETAIL ORDER BOOKED!*\n\n` +
        `• *Order Reference:* ${order.id}\n` +
        `• *Date:* ${new Date(order.date).toLocaleDateString()}\n\n` +
        `*Items Ordered:*\n${orderItemsText}\n\n` +
        `• *Subtotal:* ₹${subTotalVal}/-\n` +
        `• *Delivery Fee (${order.state}):* ₹${deliveryChargeVal}/-\n` +
        `• *Grand Total:* ₹${order.totalPrice}/-\n\n` +
        `🏠 *Delivery Client Address:*\n` +
        `• *Recipient:* ${order.customerName}\n` +
        `• *Phone:* ${order.customerPhone}\n` +
        `• *Pincode:* ${order.pincode} - ${order.city}\n` +
        `• *Address:* ${order.address}\n` +
        (order.gstNumber ? `• *GST Number:* ${order.gstNumber}\n` : '') +
        `\n⚡ _Dispatched automatically from AMD Store Notifier._`;

      // 1. Google Chat / Slack Webhook
      try {
        const webhookUrl = localStorage.getItem('amd_google_chat_webhook');
        const autoPost = localStorage.getItem('amd_auto_post_orders') === 'true';
        if (webhookUrl && autoPost) {
          await fetch(webhookUrl.trim(), {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json; charset=UTF-8',
            },
            body: JSON.stringify({ text: summaryText }),
          });
          console.log("Successfully auto-posted order alert to Google Chat webhook!");
        }
      } catch (wcErr) {
        console.warn("Failed to auto-post order alert to Google Chat:", wcErr);
      }

      // 2. Direct WhatsApp Alert via CallMeBot
      try {
        const waEnabled = localStorage.getItem('amd_whatsapp_notify_enabled') === 'true';
        const waPhone = localStorage.getItem('amd_whatsapp_notify_phone');
        const waApikey = localStorage.getItem('amd_whatsapp_notify_apikey');

        if (waEnabled && waPhone && waApikey) {
          const cleanMessage = summaryText
            .replace(/\*/g, '')
            .replace(/• /g, '- ');

          const callmebotUrl = `https://api.callmebot.com/whatsapp.php?phone=${waPhone.trim()}&text=${encodeURIComponent(cleanMessage)}&apikey=${waApikey.trim()}`;
          await fetch(callmebotUrl);
          console.log("CallMeBot WhatsApp notification request dispatched!");
        }
      } catch (waErr) {
        console.warn("Failed to dispatch WhatsApp CallMeBot webhook:", waErr);
      }

      // 3. Custom Developer Webhook URL
      try {
        const customWebhookEnabled = localStorage.getItem('amd_custom_webhook_enabled') === 'true';
        const customWebhookUrl = localStorage.getItem('amd_custom_webhook_url');

        if (customWebhookEnabled && customWebhookUrl) {
          await fetch(customWebhookUrl.trim(), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              event: 'order.created',
              timestamp: new Date().toISOString(),
              orderId: order.id,
              details: order,
              items: isDirect && selectedProduct ? [{
                name: selectedProduct.name,
                weight: selectedProduct.weight,
                quantity: detailQty,
                price: selectedProduct.price
              }] : cartSummaryItems
            })
          });
          console.log("Custom Developer Webhook dispatched successfully!");
        }
      } catch (cwErr) {
        console.warn("Custom Developer Webhook dispatch failed:", cwErr);
      }

    } catch (error) {
      console.warn("Unified notification dispatch encountered a warning:", error);
    }
  };

  // Handle order submission and registration coupling
  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (grandTotal === 0) {
      showToastMessage('Your shopping bag is empty! Please select at least 1 packet.', 'error');
      return;
    }

    // Validate minimum booking requirements (e.g. min 10kg for bulk grades)
    const violateMinBookingItem = cartSummaryItems.find(item => item.minQty && item.quantity < item.minQty);
    if (violateMinBookingItem) {
      showToastMessage(`Minimum order quantity for ${violateMinBookingItem.name} is ${violateMinBookingItem.minQty} kg. Please adjust.`, 'error');
      return;
    }

    if (!formData.name || !formData.phone || !formData.address || !formData.pincode || !formData.city) {
      showToastMessage('Please fill in all the required delivery details.', 'error');
      return;
    }

    setIsSubmitting(true);

    try {
      const orderId = `AMD-R-${Math.floor(1000 + Math.random() * 9000)}`;
      
      // Format combined order product items
      const cartItemNames = cartSummaryItems.map(item => `${item.name} (${item.weight} x${item.quantity})`);
      const productNameText = cartItemNames.join(', ') || 'Various Makhana Grades';
      const qty = totalQtyOfAllPresents;
      const unitPrice = qty > 0 ? Math.round(grandTotal / qty) : 0;
      const primaryPacketSize = cartSummaryItems[0]?.weight || '250g';

      const newOrder: Order = {
        id: orderId,
        date: new Date().toISOString(),
        productName: productNameText,
        packetSize: primaryPacketSize,
        quantity: qty,
        pricePerUnit: unitPrice,
        totalPrice: grandTotal,
        customerName: formData.name,
        customerPhone: formData.phone,
        customerEmail: formData.email,
        address: formData.address,
        pincode: formData.pincode,
        city: formData.city,
        state: formData.state,
        status: 'Pending',
        subTotal: cartSubtotal,
        deliveryCharge: shippingCharge,
        gstNumber: formData.gstNumber
      };

      // Populate local state backup instantly
      const updatedOrders = [newOrder, ...orders];
      setOrders(updatedOrders);
      localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(updatedOrders));

      // Guest profile backup local state instantly
      const localUserData: CustomerUser = {
        uid: auth.currentUser?.uid || '',
        name: formData.name,
        phone: formData.phone,
        email: formData.email,
        address: formData.address,
        pincode: formData.pincode,
        city: formData.city,
        state: formData.state,
        authMethod: 'phone',
        gstNumber: formData.gstNumber
      };
      setActiveUser(localUserData);
      localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(localUserData));

      // Instantly confirm success on the screen
      setPlacedOrder(newOrder);
      setIsSubmitting(false);

      // Async/background dispatches for merchant and database save (does NOT block the loading screen)
      triggerMerchantAlerts(newOrder, false);

      // Save to Firebase Firestore in the background
      (async () => {
        try {
          let currentUid = auth.currentUser?.uid;
          
          if (!currentUid) {
            try {
              const { signInAnonymously } = await import('firebase/auth');
              const anonResult = await signInAnonymously(auth);
              currentUid = anonResult.user.uid;
            } catch (anonError) {
              console.warn("Anonymous login failed or disabled, continuing guest checkout:", anonError);
            }
          }

          // Construct Firestore parameters meeting strict rule schema validation
          const firestoreOrderData: any = {
            id: orderId,
            productName: productNameText,
            packetSize: primaryPacketSize,
            quantity: Number(qty),
            pricePerUnit: Number(unitPrice),
            totalPrice: Number(grandTotal),
            customerName: formData.name,
            customerPhone: formData.phone,
            customerEmail: formData.email || '',
            address: formData.address,
            pincode: formData.pincode,
            city: formData.city,
            state: formData.state,
            status: 'Pending',
            subTotal: cartSubtotal,
            deliveryCharge: shippingCharge,
            gstNumber: formData.gstNumber || '',
            date: serverTimestamp() // Required Timestamp
          };

          if (currentUid) {
            firestoreOrderData.userId = currentUid;
          }

          // Save to orders db
          await setDoc(doc(db, 'orders', orderId), firestoreOrderData);

          if (currentUid) {
            const userProfileData: CustomerUser = {
              uid: currentUid,
              name: formData.name,
              phone: formData.phone,
              email: formData.email,
              address: formData.address,
              pincode: formData.pincode,
              city: formData.city,
              state: formData.state,
              authMethod: activeUser?.authMethod || 'phone',
              gstNumber: formData.gstNumber,
              updatedAt: serverTimestamp()
            };
            
            const userDocRef = doc(db, 'users', currentUid);
            const userExistsSnap = await getDoc(userDocRef);
            if (userExistsSnap.exists()) {
              const existingData = userExistsSnap.data();
              if (existingData && existingData.createdAt) {
                userProfileData.createdAt = existingData.createdAt;
              }
            } else {
              userProfileData.createdAt = serverTimestamp();
            }
            await setDoc(userDocRef, userProfileData);
            
            const updatedWithUid = { ...localUserData, uid: currentUid };
            setActiveUser(updatedWithUid);
            localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(updatedWithUid));
          }
        } catch (fError) {
          console.warn("Bg Firebase sync suspended / handled offline safely:", fError);
        }
      })();

    } catch (err) {
      console.error("Checkout transaction failed: ", err);
      setIsSubmitting(false);
      showToastMessage("Checkout failed. Please confirm details and try again.", "error");
    }
  };

  const handleDirectCheckoutSubmit = async (e: React.FormEvent, localForm: typeof formData) => {
    e.preventDefault();
    if (!selectedProduct) return;
    if (selectedProduct.minQty && detailQty < selectedProduct.minQty) {
      showToastMessage(`Minimum order quantity for ${selectedProduct.name} is ${selectedProduct.minQty} kg.`, 'error');
      return;
    }
    if (!localForm.name || !localForm.phone || !localForm.address || !localForm.pincode || !localForm.city) {
      showToastMessage('Please fill in all the required delivery details.', 'error');
      return;
    }

    setIsSubmitting(true);

    try {
      const totalCost = selectedProduct.price * detailQty;
      const directItems = [{ quantity: detailQty, weight: selectedProduct.weight }];
      const directShipping = calculateShippingCharge(localForm.state, directItems);
      const grandTotalCost = totalCost + directShipping;

      const orderId = `AMD-R-${Math.floor(1000 + Math.random() * 9000)}`;
      const productNameText = `${selectedProduct.name} (${selectedProduct.weight} x${detailQty})`;

      // Instantly sync cart state so cartSummaryItems and invoice displays align dynamically
      setCart({ [selectedProduct.id]: detailQty });
      setFormData(localForm);

      const newOrder: Order = {
        id: orderId,
        date: new Date().toISOString(),
        productName: productNameText,
        packetSize: selectedProduct.weight,
        quantity: detailQty,
        pricePerUnit: selectedProduct.price,
        totalPrice: grandTotalCost,
        customerName: localForm.name,
        customerPhone: localForm.phone,
        customerEmail: localForm.email,
        address: localForm.address,
        pincode: localForm.pincode,
        city: localForm.city,
        state: localForm.state,
        status: 'Pending',
        subTotal: totalCost,
        deliveryCharge: directShipping,
        gstNumber: localForm.gstNumber
      };

      // Populate local state backup instantly
      const updatedOrders = [newOrder, ...orders];
      setOrders(updatedOrders);
      localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(updatedOrders));

      // Guest profile local state backup instantly
      const localUserData: CustomerUser = {
        uid: auth.currentUser?.uid || '',
        name: localForm.name,
        phone: localForm.phone,
        email: localForm.email,
        address: localForm.address,
        pincode: localForm.pincode,
        city: localForm.city,
        state: localForm.state,
        authMethod: 'phone',
        gstNumber: localForm.gstNumber
      };
      setActiveUser(localUserData);
      localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(localUserData));

      // Instantly confirm success on the screen
      setPlacedOrder(newOrder);
      setIsSubmitting(false);
      setSelectedProduct(null); // Close the detail modal
      showToastMessage("Direct order booked successfully! Confirm on WhatsApp.", "success");

      // Non-blocking asynchronous merchant notification dispatch
      triggerMerchantAlerts(newOrder, true);

      // Async/background Firebase Firestore upload
      (async () => {
        try {
          let currentUid = auth.currentUser?.uid;
          if (!currentUid) {
            try {
              const { signInAnonymously } = await import('firebase/auth');
              const anonResult = await signInAnonymously(auth);
              currentUid = anonResult.user.uid;
            } catch (anonError) {
              console.warn("Direct checkout anonymous sign-in skipped:", anonError);
            }
          }

          const firestoreOrderData: any = {
            id: orderId,
            productName: productNameText,
            packetSize: selectedProduct.weight,
            quantity: Number(detailQty),
            pricePerUnit: Number(selectedProduct.price),
            totalPrice: Number(grandTotalCost),
            customerName: localForm.name,
            customerPhone: localForm.phone,
            customerEmail: localForm.email || '',
            address: localForm.address,
            pincode: localForm.pincode,
            city: localForm.city,
            state: localForm.state,
            status: 'Pending',
            subTotal: totalCost,
            deliveryCharge: directShipping,
            gstNumber: localForm.gstNumber || '',
            date: serverTimestamp()
          };

          if (currentUid) {
            firestoreOrderData.userId = currentUid;
          }

          // Save direct order document to DB
          await setDoc(doc(db, 'orders', orderId), firestoreOrderData);

          if (currentUid) {
            const userProfileData: CustomerUser = {
              uid: currentUid,
              name: localForm.name,
              phone: localForm.phone,
              email: localForm.email,
              address: localForm.address,
              pincode: localForm.pincode,
              city: localForm.city,
              state: localForm.state,
              authMethod: activeUser?.authMethod || 'phone',
              gstNumber: localForm.gstNumber,
              updatedAt: serverTimestamp()
            };

            const userDocRef = doc(db, 'users', currentUid);
            const userExistsSnap = await getDoc(userDocRef);
            if (userExistsSnap.exists()) {
              const existingData = userExistsSnap.data();
              if (existingData && existingData.createdAt) {
                userProfileData.createdAt = existingData.createdAt;
              }
            } else {
              userProfileData.createdAt = serverTimestamp();
            }
            await setDoc(userDocRef, userProfileData);
            
            const updatedWithUid = { ...localUserData, uid: currentUid };
            setActiveUser(updatedWithUid);
            localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(updatedWithUid));
          }
        } catch (fError) {
          console.warn("Bg Firestore direct booking syncer suspended safely:", fError);
        }
      })();

    } catch (err) {
      console.error("Direct checkout transaction failed:", err);
      setIsSubmitting(false);
      showToastMessage("Checkout transaction failed. Please retry.", "error");
    }
  };

  const triggerWhatsAppConfirmation = (order: Order) => {
    const cartSummary = cartSummaryItems.map(
      item => `- ${item.name} (${item.weight}) x ${item.quantity} ${item.weight === '1 kg' ? 'kg' : 'Pkt'} [₹${item.total}/-]`
    );

    const deliveryChargeVal = order.deliveryCharge !== undefined ? order.deliveryCharge : 0;
    const subTotalVal = order.subTotal !== undefined ? order.subTotal : order.totalPrice;

    const message = `Hello AMD Trading Company!\n` +
      `🛒 *New Retail Order Booking!* \n\n` +
      `📦 *Order Details:*\n` +
      `• *Order ID:* ${order.id}\n` +
      `• *Date:* ${new Date(order.date).toLocaleDateString()}\n` +
      `${cartSummary.join('\n')}\n` +
      `• *Subtotal:* ₹${subTotalVal}/-\n` +
      `• *Delivery Charge (${order.state}):* ₹${deliveryChargeVal}/-\n` +
      `• *Grand Total:* ₹${order.totalPrice}/-\n\n` +
      `🏠 *Delivery Address:*\n` +
      `• *Recipient:* ${order.customerName}\n` +
      `• *Phone:* ${order.customerPhone}\n` +
      `${order.customerEmail ? `• *Email:* ${order.customerEmail}\n` : ''}` +
      `• *Address:* ${order.address}\n` +
      `• *City:* ${order.city}\n` +
      `• *State:* ${order.state}\n` +
      `• *Pincode:* ${order.pincode}\n\n` +
      `Please confirm my retail order and share UPI payment QR scanner details to process shipment. Thank you!`;

    window.open(`https://wa.me/919555761477?text=${encodeURIComponent(message)}`, '_blank');
  };

  const handleResetForNewOrder = () => {
    setCart({ 'suta-mix': 1 });
    setPlacedOrder(null);
  };

  // Secure Admin Credentials Verify
  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPin === '1122' || adminPin === 'admin') {
      setIsAdminAuthenticated(true);
      setPinError('');
    } else {
      setPinError('Incorrect security PIN. Access denied.');
    }
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    setAdminPin('');
    setActiveTab('shop');
  };

  // Status Modifiers
  const handleUpdateStatus = async (id: string, newStats: 'Pending' | 'Shipped' | 'Delivered' | 'Cancelled') => {
    const nextOrders = orders.map(o => o.id === id ? { ...o, status: newStats } : o);
    setOrders(nextOrders);
    localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(nextOrders));

    try {
      await updateDoc(doc(db, 'orders', id), {
        status: newStats
      });
      showToastMessage(`Order status updated to ${newStats} in Database.`, 'success');
    } catch (fError) {
      console.warn("Firestore order update failed (it requires admin authenticated email or owner permissions):", fError);
      showToastMessage(`Order status updated locally.`, 'info');
    }
  };

  // Customer Authentication Logic
  const handleStartAuth = (type: 'login' | 'register') => {
    setAuthStep(type);
    setPinError('');
    setOtpError('');
  };

  const submitPhoneAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authPhone || authPhone.length < 10) {
      setOtpError('Please enter a valid 10-digit Indian Mobile phone number.');
      return;
    }
    setIsAuthLoading(true);
    setOtpError('');
    setBypassPhoneAuth(false);

    // Sandbox bypass support
    if (authPhone === '9876543210') {
      setIsAuthLoading(false);
      setBypassPhoneAuth(true);
      setAuthStep('otp_verification');
      setOtpTimer(60);
      setOtpCode('');
      return;
    }

    try {
      // Initialize reCAPTCHA element dynamically if it doesn't exist
      let recaptchaContainer = document.getElementById('recaptcha-container');
      if (!recaptchaContainer) {
        recaptchaContainer = document.createElement('div');
        recaptchaContainer.id = 'recaptcha-container';
        recaptchaContainer.style.display = 'none';
        document.body.appendChild(recaptchaContainer);
      }

      const verifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
        size: 'invisible'
      });

      const phoneNumberWithCountry = authPhone.startsWith('+') ? authPhone : `+91${authPhone}`;
      const confirmationResult = await signInWithPhoneNumber(auth, phoneNumberWithCountry, verifier);
      
      (window as any).confirmationResult = confirmationResult;
      
      setIsAuthLoading(false);
      setAuthStep('otp_verification');
      setOtpTimer(60);
      setOtpCode('');
    } catch (error: any) {
      setIsAuthLoading(false);
      console.warn('Real SMS SMS dispatch failed, falling back to sandbox bypass mode', error);
      
      setBypassPhoneAuth(true);
      setAuthStep('otp_verification');
      setOtpTimer(60);
      setOtpCode('');
      setOtpError("Sms warning: To trigger real SMS, configure 'Phone Auth' on Firebase. Development sandbox active: enter code '1234' to verify.");
    }
  };

  const confirmOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    if (otpCode.length !== 4 && otpCode.length !== 6) {
      setOtpError('Please enter the verification code sent to your phone.');
      return;
    }
    setIsAuthLoading(true);
    setOtpError('');

    try {
      if (bypassPhoneAuth || authPhone === '9876543210') {
        if (otpCode !== '1234') {
          setIsAuthLoading(false);
          setOtpError('Incorrect sandbox verification code. Please type 1234.');
          return;
        }

        // Authenticate anonymously so we get a real profile write privilege
        const { signInAnonymously } = await import('firebase/auth');
        const anonResult = await signInAnonymously(auth);
        
        const isExisting = authPhone === '9876543210';
        const sampleUser: CustomerUser = {
          uid: anonResult.user.uid,
          name: isExisting ? 'Anand Sharma' : (authName || 'Makhana Lover'),
          phone: authPhone,
          email: authEmail || (isExisting ? 'anand@gmail.com' : undefined),
          address: isExisting ? 'Flat 402, Shiv Shakti Apartments, Sector 15' : undefined,
          pincode: isExisting ? '110085' : undefined,
          city: isExisting ? 'Rohini, New Delhi' : undefined,
          state: isExisting ? 'Delhi' : 'Delhi',
          authMethod: 'phone',
          avatarUrl: `https://api.dicebear.com/7.x/pixel-art/svg?seed=${authPhone}`
        };

        await setDoc(doc(db, 'users', anonResult.user.uid), sampleUser);
        setActiveUser(sampleUser);
        localStorage.setItem(ACTIVE_USER_KEY, JSON.stringify(sampleUser));

        setFormData(prev => ({
          ...prev,
          name: sampleUser.name,
          phone: sampleUser.phone,
          email: sampleUser.email || '',
          address: sampleUser.address || '',
          pincode: sampleUser.pincode || '',
          city: sampleUser.city || '',
          state: sampleUser.state || 'Delhi'
        }));

        setIsAuthLoading(false);
        setAuthStep('none');
        setAuthPhone('');
        setAuthName('');
        setAuthEmail('');
      } else {
        const confirmationResult = (window as any).confirmationResult;
        if (!confirmationResult) {
          throw new Error('Sms verification result is missing. Try again.');
        }

        const result = await confirmationResult.confirm(otpCode);
        const user = result.user;

        // Listener 'onAuthStateChanged' handles rest of document parsing automatically!
        setIsAuthLoading(false);
        setAuthStep('none');
        setAuthPhone('');
        setAuthName('');
        setAuthEmail('');
      }
    } catch (error: any) {
      setIsAuthLoading(false);
      console.error('OTP confirmation failed:', error);
      setOtpError(error.message || 'Incorrect SMS code entered. Please try again.');
    }
  };

  // Real Google Login with Forced Select Account parameters
  const triggerGoogleAuth = async () => {
    setIsAuthLoading(true);
    setOtpError('');
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({
        prompt: 'select_account'
      });
      
      await signInWithPopup(auth, provider);
      setAuthStep('none');
    } catch (error: any) {
      console.error('Google Auth Failed: ', error);
      setOtpError(error.message || 'Google account verification was cancelled or failed.');
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleCustomerLogout = async () => {
    setActiveUser(null);
    localStorage.removeItem(ACTIVE_USER_KEY);
    setFormData({
      name: '',
      phone: '',
      email: '',
      address: '',
      pincode: '',
      city: '',
      state: 'Delhi',
      gstNumber: ''
    });
    try {
      await signOut(auth);
    } catch (e) {
      // ignore
    }
  };

  // Package Tracking Code
  const handleQueryTrackPackage = async (e: React.FormEvent) => {
    e.preventDefault();
    setTrackingError('');
    setSearchedTrackingId('');

    const trimmedId = trackingId.trim().toUpperCase();
    if (!trimmedId) {
      setTrackingError('Please specify an Order Reference ID.');
      return;
    }

    // 1. Search locally in cached context first
    const matches = orders.find(o => o.id.toUpperCase() === trimmedId);
    if (matches) {
      setLiveTrackedOrder(matches);
      setSearchedTrackingId(matches.id);
      return;
    }

    // 2. Direct Firestore fallback query
    try {
      const { getDoc, doc } = await import('firebase/firestore');
      const orderDocRef = doc(db, 'orders', trimmedId);
      const orderSnap = await getDoc(orderDocRef);

      if (orderSnap.exists()) {
        const oData = orderSnap.data();
        const orderDateIso = oData.date?.toDate 
          ? oData.date.toDate().toISOString() 
          : (oData.date || new Date().toISOString());

        const validatedOrder: Order = {
          id: orderSnap.id,
          date: orderDateIso,
          productName: oData.productName,
          packetSize: oData.packetSize || '250g',
          quantity: oData.quantity,
          pricePerUnit: oData.pricePerUnit,
          totalPrice: oData.totalPrice,
          customerName: oData.customerName,
          customerPhone: oData.customerPhone,
          customerEmail: oData.customerEmail,
          address: oData.address,
          pincode: oData.pincode,
          city: oData.city,
          state: oData.state,
          status: oData.status
        };

        // Inject to local state so next lookups or tabs display it
        setOrders(prev => {
          if (!prev.some(item => item.id.toUpperCase() === validatedOrder.id.toUpperCase())) {
            return [validatedOrder, ...prev];
          }
          return prev;
        });

        setLiveTrackedOrder(validatedOrder);
        setSearchedTrackingId(validatedOrder.id);
      } else {
        setLiveTrackedOrder(null);
        setTrackingError(`Order reference ID "${trackingId}" was not found. Please verify details (e.g., AMD-R-2001).`);
      }
    } catch (dbError) {
      console.warn("Direct document tracking fallback failed: ", dbError);
      setLiveTrackedOrder(null);
      setTrackingError(`Order reference ID "${trackingId}" was not found. Please verify details.`);
    }
  };

  const selectPreloadTrack = (oId: string) => {
    setTrackingId(oId);
    const matches = orders.find(o => o.id === oId);
    if (matches) {
      setLiveTrackedOrder(matches);
      setSearchedTrackingId(matches.id);
      setActiveTab('track');
    }
  };

  // EXCEL EXPORTERS
  const handleExportCSV = (exportType: 'shuddh' | 'rozana' | 'all') => {
    let filtered = orders;
    let filenamePrefix = "makhana_orders_consolidated";

    if (exportType === 'shuddh') {
      filtered = orders.filter(o => o.productName === 'Shuddh Premium Makhana' || o.totalPrice % 399 === 0);
      filenamePrefix = "shuddh_premium_makhana_retail_sheet";
    } else if (exportType === 'rozana') {
      filtered = orders.filter(o => o.productName === 'Rozana Makhana');
      filenamePrefix = "rozana_makhana_retail_sheet";
    }

    if (filtered.length === 0) {
      showToastMessage(`No active orders represent this specific spreadsheet yet.`, 'info');
      return;
    }

    const headers = [
      'Order ID', 
      'Order Date', 
      'Product Caliber Classification', 
      'Packet Size', 
      'Checkout Quantity', 
      'Price Per Unit (INR)', 
      'Total Paid (INR)', 
      'Recipient Name', 
      'Recipient WhatsApp No', 
      'Recipient Email', 
      'Recipient GST Number',
      'Delivery Address', 
      'Postal Pincode', 
      'City', 
      'State', 
      'Delivery Status'
    ];

    const rows = filtered.map(o => [
      o.id,
      new Date(o.date).toLocaleString('en-IN'),
      o.productName === 'Shuddh Premium Makhana' ? 'Shuddh Premium (5 Suta+)' : 'Rozana Daily Sifter Mix',
      '250 grams',
      o.quantity,
      o.pricePerUnit,
      o.totalPrice,
      `"${o.customerName.replace(/"/g, '""')}"`,
      `"${o.customerPhone.replace(/"/g, '""')}"`,
      o.customerEmail ? `"${o.customerEmail.replace(/"/g, '""')}"` : 'N/A',
      o.gstNumber ? `"${o.gstNumber.replace(/"/g, '""')}"` : 'N/A',
      `"${o.address.replace(/"/g, '""')}"`,
      `"${o.pincode}"`,
      `"${o.city.replace(/"/g, '""')}"`,
      `"${o.state}"`,
      o.status
    ]);

    const csvRows = [headers.join(','), ...rows.map(r => r.join(','))];
    const csvContent = "\uFEFF" + csvRows.join('\r\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", `${filenamePrefix}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredAdminOrders = orders.filter(o => 
    o.customerName.toLowerCase().includes(adminSearch.toLowerCase()) || 
    o.id.toLowerCase().includes(adminSearch.toLowerCase()) ||
    o.customerPhone.includes(adminSearch)
  );

  return (
    <div className="bg-stone-50 min-h-screen py-6 select-none font-sans relative">
      
      {/* Toast Notification HUD */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: -40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-50 w-full max-w-sm px-4"
          >
            <div 
              onClick={() => setToast(null)}
              className={`p-4 rounded-2xl shadow-xl border flex items-start gap-3 backdrop-blur-md cursor-pointer hover:scale-101 transition-transform ${
                toast.type === 'success' 
                  ? 'bg-emerald-900 border-emerald-800 text-emerald-100 shadow-emerald-900/15' 
                  : toast.type === 'error'
                    ? 'bg-rose-950 border-rose-900 text-rose-100 shadow-rose-950/15'
                    : 'bg-stone-900 border-stone-800 text-stone-100 shadow-stone-950/15'
              }`}
            >
              <div className={`p-1.5 rounded-lg shrink-0 ${
                toast.type === 'success' 
                  ? 'bg-emerald-800 text-emerald-300' 
                  : toast.type === 'error'
                    ? 'bg-rose-800 text-rose-300'
                    : 'bg-stone-800/80 text-amber-300'
              }`}>
                {toast.type === 'success' ? <Check className="h-4 w-4" /> : toast.type === 'error' ? <Lock className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
              </div>
              <div className="text-left space-y-0.5">
                <p className="text-xs font-bold tracking-wider uppercase leading-none font-sans">
                  {toast.type === 'success' ? 'Task Succeeded' : toast.type === 'error' ? 'Warning / Error' : 'System Notice'}
                </p>
                <p className="text-[11px] leading-relaxed opacity-90">{toast.message}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Product Detail Modal overlay */}
      <AnimatePresence>
        {selectedProduct && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/60 backdrop-blur-md p-4 sm:p-6 overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 30 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="bg-white border border-stone-200 rounded-3xl shadow-2xl max-w-4xl w-full relative overflow-hidden flex flex-col md:flex-row text-left max-h-[92vh] md:max-h-[85vh] divide-y md:divide-y-0 md:divide-x divide-stone-150"
            >
              {/* Close Button Button */}
              <button
                onClick={() => setSelectedProduct(null)}
                className="absolute top-4 right-4 z-10 text-stone-400 hover:text-stone-600 font-mono text-lg font-bold cursor-pointer hover:bg-stone-100 bg-white/80 backdrop-blur-xs w-8 h-8 rounded-full flex items-center justify-center shadow-xs"
              >
                ✕
              </button>

              {/* Left Side Column Column: Image display and slider navigation */}
              <div className="w-full md:w-1/2 bg-stone-50/50 p-6 flex flex-col justify-between overflow-y-auto max-h-[38vh] md:max-h-full">
                <div className="flex-1 flex items-center justify-center min-h-[200px] relative">
                  <motion.img
                    key={activeDetailImageIdx}
                    initial={{ opacity: 0, scale: 0.97 }}
                    animate={{ opacity: 1, scale: 1 }}
                    src={selectedProduct.images && selectedProduct.images[activeDetailImageIdx] ? selectedProduct.images[activeDetailImageIdx] : selectedProduct.image}
                    alt={selectedProduct.name}
                    referrerPolicy="no-referrer"
                    className="max-h-[220px] object-contain drop-shadow-xl hover:scale-103 transition-transform duration-350"
                  />
                </div>

                {/* Grid of gallery assets */}
                {selectedProduct.images && selectedProduct.images.length > 1 && (
                  <div className="flex gap-2.5 justify-center mt-4 overflow-x-auto pb-1 max-w-xs mx-auto">
                    {selectedProduct.images.map((img, idx) => (
                      <button
                        key={idx}
                        onClick={() => setActiveDetailImageIdx(idx)}
                        className={`w-11 h-11 rounded-xl border-2 transition-all overflow-hidden shrink-0 cursor-pointer bg-white ${
                          activeDetailImageIdx === idx
                            ? 'border-emerald-700 shadow-md scale-105'
                            : 'border-stone-200 hover:border-stone-300'
                        }`}
                      >
                        <img src={img} alt="" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Right Side Column Column: Title specs specifications form state and button flows */}
              <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between overflow-y-auto max-h-[54vh] md:max-h-full font-sans">
                <div className="space-y-4">
                  <div className="space-y-1.5 text-left">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="bg-emerald-50 text-emerald-800 border border-emerald-200 text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full uppercase leading-none tracking-wider">
                        {selectedProduct.badge}
                      </span>
                      <span className="bg-stone-100 text-stone-605 text-[10px] font-bold px-2 py-0.5 rounded-md leading-none">
                        {selectedProduct.weight} Airtight Pouch
                      </span>
                    </div>
                    <h3 className="font-serif text-lg sm:text-xl font-bold text-stone-900 leading-tight">
                      {selectedProduct.name}
                    </h3>
                    <p className="text-xs text-stone-400 font-bold font-mono tracking-wide uppercase leading-none mt-0.5">
                      {selectedProduct.subtitle}
                    </p>
                  </div>

                  <hr className="border-stone-150" />

                  {/* Transition display details vs direct buy */}
                  <AnimatePresence mode="wait">
                    {!showDirectCheckout ? (
                      <motion.div
                        key="product-details-pane"
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        className="space-y-3.5"
                      >
                        <p className="text-xs sm:text-xs text-stone-600 leading-relaxed">
                          {selectedProduct.description}
                        </p>

                        <div className="space-y-2">
                          <span className="text-[10px] text-stone-400 font-bold block uppercase tracking-wider leading-none">
                            Key Specifications:
                          </span>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10.5px] font-medium text-stone-650">
                            {selectedProduct.features.map((feature, featureIdx) => (
                              <div key={featureIdx} className="flex items-start gap-1.5 bg-stone-50 rounded-lg p-2 border border-stone-150/55">
                                <Check className="h-3.5 w-3.5 text-emerald-600 shrink-0 mt-0.5" />
                                <span className="leading-tight text-stone-850">{feature}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-baseline gap-2 pt-1 bg-stone-50 p-2.5 border border-stone-150 rounded-xl justify-between">
                          <span className="text-[10px] text-stone-400 font-bold block uppercase tracking-wider leading-none">Single pouch price:</span>
                          <span className="text-base font-bold font-mono text-emerald-800 leading-none">₹{selectedProduct.price}/- <span className="text-[10px] text-stone-400 font-sans font-normal">per 250g bag</span></span>
                        </div>
                      </motion.div>
                    ) : (
                      <motion.div
                        key="direct-checkout-pane"
                        initial={{ opacity: 0, x: 10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -10 }}
                        className="space-y-3.5"
                      >
                        <div className="bg-emerald-50/50 border border-emerald-150 rounded-2xl p-3 text-left space-y-1">
                          <div className="flex justify-between items-center text-xs font-bold text-stone-850">
                            <span className="flex items-center gap-1.5 text-emerald-800"><ShoppingBag className="h-4 w-4" /> Order Invoice:</span>
                            <span className="font-mono text-emerald-900">
                              ₹{selectedProduct.price * detailQty + calculateShippingCharge(localDirectForm.state, [{ quantity: detailQty, weight: selectedProduct.weight }])}/-
                            </span>
                          </div>
                          <div className="flex justify-between text-[10px] text-stone-500 font-mono">
                            <span>Subtotal:</span>
                            <span>₹{selectedProduct.price * detailQty}/-</span>
                          </div>
                          <div className="flex justify-between text-[10px] text-emerald-800 font-mono font-semibold">
                            <span>Courier Fee ({localDirectForm.state}):</span>
                            <span>₹{calculateShippingCharge(localDirectForm.state, [{ quantity: detailQty, weight: selectedProduct.weight }])}/-</span>
                          </div>
                          <p className="text-[9px] text-stone-400 leading-relaxed font-sans pt-1 border-t border-stone-200/60">
                            Ordering <strong>{detailQty} {selectedProduct.weight === '1 kg' ? 'kg' : 'Bag(s)'}</strong> of {selectedProduct.name} ({selectedProduct.weight === '1 kg' ? 'Loose Bulk' : selectedProduct.weight}). Includes premium packing with fast air/surface express delivery.
                          </p>
                        </div>

                        <form onSubmit={(e) => handleDirectCheckoutSubmit(e, localDirectForm)} className="space-y-2 text-left">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div className="space-y-0.5">
                              <label className="text-[9px] font-bold text-stone-605 block uppercase">Customer name *</label>
                              <input
                                type="text"
                                required
                                placeholder="e.g. Anand Sharma"
                                value={localDirectForm.name}
                                onChange={(e) => setLocalDirectForm({ ...localDirectForm, name: e.target.value })}
                                className="w-full bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-1.5 text-xs outline-hidden focus:bg-white focus:border-emerald-600 font-medium text-stone-900"
                              />
                            </div>
                            <div className="space-y-0.5">
                              <label className="text-[9px] font-bold text-stone-605 block uppercase">WhatsApp Phone *</label>
                              <input
                                type="tel"
                                required
                                maxLength={10}
                                placeholder="10-digit number"
                                value={localDirectForm.phone}
                                onChange={(e) => setLocalDirectForm({ ...localDirectForm, phone: e.target.value.replace(/\D/g, '') })}
                                className="w-full bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-1.5 text-xs outline-hidden focus:bg-white focus:border-emerald-600 font-medium text-stone-900 font-mono"
                              />
                            </div>
                          </div>

                          <div className="space-y-0.5">
                            <label className="text-[9px] font-bold text-stone-605 block uppercase">GST Number (Optional)</label>
                            <input
                              type="text"
                              placeholder="e.g. 07AAAAA1111A1Z1"
                              value={localDirectForm.gstNumber || ''}
                              onChange={(e) => setLocalDirectForm({ ...localDirectForm, gstNumber: e.target.value.toUpperCase() })}
                              className="w-full bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-1.5 text-xs outline-hidden focus:bg-white focus:border-emerald-600 font-medium text-stone-900 font-mono uppercase"
                            />
                          </div>

                          <div className="space-y-0.5">
                            <label className="text-[9px] font-bold text-stone-605 block uppercase">Delivery Location Address *</label>
                            <input
                              type="text"
                              required
                              placeholder="House details, street, locality"
                              value={localDirectForm.address}
                              onChange={(e) => setLocalDirectForm({ ...localDirectForm, address: e.target.value })}
                              className="w-full bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-1.5 text-xs outline-hidden focus:bg-white focus:border-emerald-600 font-medium text-stone-900"
                            />
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                            <div className="space-y-0.5">
                              <label className="text-[9px] font-bold text-stone-605 block uppercase">State *</label>
                              <select
                                value={localDirectForm.state}
                                onChange={(e) => {
                                  const selectedSt = e.target.value;
                                  const defaultCities = INDIAN_STATES_CITIES[selectedSt] || [];
                                  setLocalDirectForm({ 
                                    ...localDirectForm, 
                                    state: selectedSt, 
                                    city: defaultCities[0] || '' 
                                  });
                                }}
                                className="w-full bg-stone-50 border border-stone-200 rounded-lg px-2 py-1.5 text-xs outline-hidden focus:bg-white focus:border-emerald-600 font-medium text-stone-900"
                              >
                                {Object.keys(INDIAN_STATES_CITIES).map(st => (
                                  <option key={st} value={st}>{st}</option>
                                ))}
                              </select>
                            </div>
                            <div className="space-y-0.5">
                              <label className="text-[9px] font-bold text-stone-605 block uppercase">City *</label>
                              <select
                                value={
                                  (localDirectForm.city === 'Other' || (localDirectForm.city && !((INDIAN_STATES_CITIES[localDirectForm.state] || []).filter(c => c !== 'Other')).includes(localDirectForm.city)))
                                    ? 'Other'
                                    : localDirectForm.city
                                }
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setLocalDirectForm({ ...localDirectForm, city: val });
                                }}
                                className="w-full bg-stone-50 border border-stone-200 rounded-lg px-2 py-1.5 text-xs outline-hidden focus:bg-white focus:border-emerald-600 font-medium text-stone-900 font-sans"
                              >
                                {((INDIAN_STATES_CITIES[localDirectForm.state] || []).filter(c => c !== 'Other')).map(ct => (
                                  <option key={ct} value={ct}>{ct}</option>
                                ))}
                                <option value="Other">Other / Type Custom City</option>
                              </select>
                              {(localDirectForm.city === 'Other' || (localDirectForm.city && !((INDIAN_STATES_CITIES[localDirectForm.state] || []).filter(c => c !== 'Other')).includes(localDirectForm.city))) && (
                                <input
                                  type="text"
                                  required
                                  placeholder="Type custom city"
                                  value={localDirectForm.city === 'Other' ? '' : localDirectForm.city}
                                  onChange={(e) => setLocalDirectForm({ ...localDirectForm, city: e.target.value })}
                                  className="w-full mt-1 bg-stone-100 border border-stone-250 rounded-lg px-2.5 py-1 text-[11px] outline-hidden focus:bg-white focus:border-emerald-600 font-medium text-stone-800"
                                />
                              )}
                            </div>
                            <div className="space-y-0.5">
                              <label className="text-[9px] font-bold text-stone-605 block uppercase">Pincode *</label>
                              <input
                                  type="text"
                                  required
                                  maxLength={6}
                                  placeholder="6-digit PIN"
                                  value={localDirectForm.pincode}
                                  onChange={(e) => setLocalDirectForm({ ...localDirectForm, pincode: e.target.value.replace(/\D/g, '') })}
                                  className="w-full bg-stone-50 border border-stone-200 rounded-lg px-2.5 py-1.5 text-xs outline-hidden focus:bg-white focus:border-emerald-600 font-medium text-stone-900 font-mono"
                              />
                            </div>
                          </div>

                          <div className="pt-1.5 flex gap-2">
                            <button
                              type="button"
                              onClick={() => setShowDirectCheckout(false)}
                              className="border border-stone-200 hover:border-stone-300 bg-white hover:bg-stone-50 text-stone-705 px-3 rounded-xl text-xs font-bold transition-all h-9 shrink-0 cursor-pointer"
                            >
                              ← Details
                            </button>
                            <button
                              type="submit"
                              disabled={isSubmitting}
                              className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition-all h-9 cursor-pointer shadow-xs border border-emerald-700 uppercase tracking-wider flex items-center justify-center space-x-1.5"
                            >
                              {isSubmitting ? (
                                <RefreshCw className="h-4 w-4 animate-spin" />
                              ) : (
                                <>
                                  <Phone className="h-4 w-4 fill-current" />
                                  <span>Secure direct booking</span>
                                </>
                              )}
                            </button>
                          </div>
                        </form>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* Footer Controls for regular details layout */}
                {!showDirectCheckout && (
                  <div className="pt-4 mt-4 border-t border-stone-150 space-y-3.5">
                    {/* Packets selection row */}
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-stone-400 uppercase tracking-wider leading-none">
                        {selectedProduct.weight === '1 kg' ? 'Order Size (kg):' : 'Number of Packets:'}
                      </span>
                      <div className="flex items-center space-x-1.5 bg-stone-50 border border-stone-200 rounded-xl p-1 select-none">
                        <button
                          type="button"
                          onClick={() => setDetailQty(prev => Math.max(selectedProduct.minQty || 1, prev - 1))}
                          className="p-1 hover:bg-stone-100 text-stone-605 rounded-lg transition-all cursor-pointer h-7 w-7 flex items-center justify-center border border-transparent hover:border-stone-200"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="w-11 text-center text-xs font-bold font-mono text-stone-850 gap-0.5">
                          {detailQty}{selectedProduct.weight === '1 kg' ? ' kg' : ''}
                        </span>
                        <button
                          type="button"
                          onClick={() => setDetailQty(prev => prev + 1)}
                          className="p-1 hover:bg-stone-100 text-stone-605 rounded-lg transition-all cursor-pointer h-7 w-7 flex items-center justify-center border border-transparent hover:border-stone-200"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-2">
                      {/* Normal shopping bag */}
                      <button
                        type="button"
                        onClick={() => {
                          handleQtyChange(selectedProduct.id, (cart[selectedProduct.id] || 0) + detailQty);
                          const unitLabel = selectedProduct.weight === '1 kg' ? 'kg' : 'packet(s)';
                          showToastMessage(`${detailQty} ${unitLabel} of ${selectedProduct.name} appended to your Shopping Bag!`, 'success');
                          setSelectedProduct(null);
                        }}
                        className="flex-1 border border-stone-200 hover:border-emerald-600 hover:bg-emerald-50/10 text-stone-705 hover:text-emerald-800 font-bold p-2.5 rounded-xl text-xs transition-all flex items-center justify-center space-x-1.5 cursor-pointer h-11"
                      >
                        <ShoppingCart className="h-4 w-4" />
                        <span>{selectedProduct.weight === '1 kg' ? 'Add Bulk Grade' : 'Add Packets'}</span>
                      </button>

                      {/* Buy Directly / Shopify Checkout */}
                      {selectedProduct.shopifyId ? (
                        <button
                          type="button"
                          onClick={() => {
                            const variantNumericId = selectedProduct.activeVariantId 
                              ? selectedProduct.activeVariantId.split('/').pop() 
                              : (selectedProduct.variants?.[0]?.numericId || "");
                            if (variantNumericId && shopifyDomain) {
                              const checkoutUrl = `https://${shopifyDomain}/cart/${variantNumericId}:${detailQty}`;
                              window.open(checkoutUrl, '_blank');
                            } else {
                              showToastMessage("Could not retrieve Shopify variant checkout link.", "error");
                            }
                          }}
                          className="flex-1 bg-amber-600 hover:bg-amber-700 text-white font-bold p-2.5 rounded-xl border border-amber-700 text-xs transition-all flex items-center justify-center space-x-1.5 cursor-pointer h-11 shadow-xs tracking-wider uppercase"
                        >
                          <svg className="h-4.5 w-4.5" fill="none" stroke="currentColor" strokeWidth="2.2" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 10.5V6a3.75 3.75 0 10-7.5 0v4.5m11.356-1.993l1.263 12c.07.665-.45 1.243-1.119 1.243H4.25a1.125 1.125 0 01-1.12-1.243l1.264-12A1.125 1.125 0 015.513 7.5h12.974c.576 0 1.059.435 1.119 1.007zM8.625 10.5a.375.375 0 11-.75 0 .375.375 0 01.75 0zm7.5 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" />
                          </svg>
                          <span>Shopify Checkout</span>
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setShowDirectCheckout(true)}
                          className="flex-1 bg-emerald-700 hover:bg-emerald-850 text-white font-bold p-2.5 rounded-xl border border-emerald-800 text-xs transition-all flex items-center justify-center space-x-1.5 cursor-pointer h-11 shadow-xs tracking-wider uppercase"
                        >
                          <Sparkles className="h-4 w-4" />
                          <span>Buy Directly Now</span>
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* UPPER NAVIGATION CONSOLE */}
        <div className="bg-white border border-stone-200/80 p-4.5 rounded-3xl shadow-xs flex flex-col lg:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-emerald-700 flex items-center justify-center text-white text-2xl shadow-sm shadow-emerald-700/20">
              🌾
            </div>
            <div className="text-left">
              <h1 className="font-serif text-xl sm:text-2xl font-bold text-stone-900 leading-tight">
                Shuddh & Rozana Retail Outlet
              </h1>
              <p className="text-xs text-stone-500 font-medium font-sans">Standardized 250g Airtight Foil Packets | Bihar Origin Guaranteed</p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveTab('shop')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'shop' 
                  ? 'bg-emerald-700 border border-emerald-800 text-white shadow-xs' 
                  : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
              }`}
            >
              <ShoppingCart className="h-4 w-4" />
              <span>Browse Shop</span>
            </button>

            <button
              onClick={() => setActiveTab('track')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'track' 
                  ? 'bg-emerald-700 border border-emerald-800 text-white shadow-xs' 
                  : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
              }`}
            >
              <Truck className="h-4 w-4" />
              <span>Track Orders ({orders.filter(o => activeUser && o.customerPhone === activeUser.phone).length})</span>
            </button>

            <button
              onClick={() => setActiveTab('admin')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'admin' 
                  ? 'bg-amber-600 border border-amber-700 text-white shadow-xs' 
                  : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
              }`}
            >
              <FileSpreadsheet className="h-4 w-4" />
              <span>Admin Excel Sheets</span>
            </button>
          </div>

          {/* User authentication actions status */}
          <div className="border-t lg:border-t-0 lg:border-l border-stone-200/80 pt-3 lg:pt-0 lg:pl-4.5 flex items-center gap-3">
            {activeUser ? (
              <div className="flex items-center gap-3">
                <div className="relative">
                  <img 
                    src={activeUser.avatarUrl || 'https://api.dicebear.com/7.x/pixel-art/svg?seed=user'} 
                    alt={activeUser.name} 
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 rounded-full bg-stone-100 border border-emerald-500 p-0.5 object-cover"
                  />
                  <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-green-500 rounded-full border-2 border-white"></span>
                </div>
                <div className="text-left">
                  <span className="text-[10px] text-stone-400 block font-semibold uppercase leading-none">Logged In Client</span>
                  <span className="text-xs font-bold text-stone-800 leading-none block mt-0.5 max-w-[120px] truncate">{activeUser.name}</span>
                </div>
                <button
                  onClick={handleCustomerLogout}
                  title="Sign Out Account"
                  className="p-1.5 bg-stone-100 hover:bg-red-50 text-stone-500 hover:text-red-600 rounded-lg transition-all cursor-pointer border border-stone-200/50"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleStartAuth('login')}
                  className="bg-stone-100 hover:bg-stone-200 text-stone-700 px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1 transition-all cursor-pointer border border-stone-200/50"
                >
                  <LogIn className="h-3.5 w-3.5" />
                  <span>Log In</span>
                </button>
                <button
                  onClick={() => handleStartAuth('register')}
                  className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/60 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  Register
                </button>
              </div>
            )}
          </div>
        </div>

        {/* AUTHENTICATIONS OVERLAYS */}
        <AnimatePresence>
          {authStep !== 'none' && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-900/40 backdrop-blur-xs p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 15 }}
                className="bg-white border border-stone-200 rounded-3xl p-6 sm:p-8 shadow-2xl max-w-md w-full relative space-y-6 text-left"
              >
                <button
                  onClick={() => setAuthStep('none')}
                  className="absolute top-4 right-4 text-stone-400 hover:text-stone-600 font-mono text-lg font-bold cursor-pointer hover:bg-stone-100 px-2 py-1 rounded-lg"
                >
                  ✕
                </button>

                {authStep === 'google_window' ? (
                  <div className="text-center py-6 space-y-4">
                    <RefreshCw className="h-10 w-10 animate-spin text-emerald-700 mx-auto" />
                    <h4 className="font-semibold text-stone-800 text-sm">Connecting securely with Google Accounts...</h4>
                    <p className="text-xs text-stone-400 max-w-xs mx-auto">This simulates returning credential tokens via Google popup integrations safely without capturing passwords.</p>
                  </div>
                ) : authStep === 'otp_verification' ? (
                  <form onSubmit={confirmOTP} className="space-y-4 text-center">
                    <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center mx-auto text-xl font-mono">
                      💬
                    </div>
                    <div className="space-y-1">
                      <h4 className="font-serif text-lg font-bold text-stone-900">Verify Your Phone Number</h4>
                      <p className="text-xs text-stone-400">
                        We sent a 4-digit verification code to <span className="font-mono text-stone-700 font-bold">{authPhone}</span>
                      </p>
                    </div>

                    <div className="py-2">
                      <input
                        type="text"
                        required
                        maxLength={4}
                        placeholder="0 0 0 0"
                        value={otpCode}
                        onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                        className="w-40 text-center tracking-widest text-2xl font-mono border-b-2 border-emerald-600 focus:outline-hidden py-1.5 focus:border-emerald-800 text-stone-850 font-bold"
                      />
                    </div>

                    {otpError && <p className="text-xs text-red-600 font-medium">{otpError}</p>}

                    <div className="text-xs text-stone-400">
                      Did not receive sms? {otpTimer > 0 ? (
                        <span>Resend in <strong className="font-mono">{otpTimer}s</strong></span>
                      ) : (
                        <button 
                          type="button" 
                          onClick={() => { setOtpTimer(60); setOtpError(''); }}
                          className="font-bold text-emerald-700 hover:underline cursor-pointer"
                        >
                          Request Code Again
                        </button>
                      )}
                    </div>

                    <button
                      type="submit"
                      disabled={otpCode.length !== 4 || isAuthLoading}
                      className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3 rounded-xl transition-all border border-emerald-800 shadow-xs text-xs uppercase tracking-wider mt-4 cursor-pointer"
                    >
                      {isAuthLoading ? 'Confirming OTP...' : 'Verify & Setup Account'}
                    </button>
                  </form>
                ) : (
                  <div className="space-y-5">
                    <div className="text-center">
                      <h3 className="font-serif text-xl sm:text-2xl font-bold text-stone-950">
                        {authStep === 'register' ? 'Register Premium Account' : 'Welcome back! Log In'}
                      </h3>
                      <p className="text-xs text-stone-400 mt-1">Unlock live package tracking and fast delivery checkout.</p>
                    </div>

                    <button
                      type="button"
                      onClick={triggerGoogleAuth}
                      className="w-full border border-stone-200 hover:border-stone-300 bg-white hover:bg-stone-50 p-3 rounded-xl text-xs font-bold font-sans text-stone-700 flex items-center justify-center gap-2.5 transition-all cursor-pointer shadow-3xs"
                    >
                      <svg className="h-4 w-4" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22-.03-.63z" />
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                      </svg>
                      <span>Continue with Google Account</span>
                    </button>

                    <div className="flex items-center justify-between text-stone-300 text-xs py-1">
                      <span className="h-px bg-stone-200 w-full"></span>
                      <span className="px-3 font-semibold uppercase tracking-wider text-[10px] text-stone-400 shrink-0">Or phone OTP validation</span>
                      <span className="h-px bg-stone-200 w-full"></span>
                    </div>

                    <form onSubmit={submitPhoneAuth} className="space-y-4">
                      {authStep === 'register' && (
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-stone-700 block">Full Recipient Name *</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Anand Sharma"
                            value={authName}
                            onChange={(e) => setAuthName(e.target.value)}
                            className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 text-xs outline-hidden focus:bg-white focus:border-emerald-600 font-medium text-stone-900"
                          />
                        </div>
                      )}

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-stone-700 block">WhatsApp Phone Number *</label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-3 h-4 w-4 text-stone-400" />
                          <input
                            type="tel"
                            maxLength={10}
                            required
                            placeholder="e.g. 9876543210"
                            value={authPhone}
                            onChange={(e) => setAuthPhone(e.target.value.replace(/\D/g, ''))}
                            className="w-full bg-stone-50 border border-stone-200 rounded-xl focus:bg-white focus:border-emerald-600 pl-9 py-2.5 text-xs text-stone-850 font-mono outline-hidden transition-all"
                          />
                        </div>
                        <p className="text-[9px] text-stone-400 mt-1 italic">Use <strong className="text-stone-750 font-bold">9876543210</strong> to quickly test credentials with demo order data.</p>
                      </div>

                      {authStep === 'register' && (
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-stone-700 block">Email Address (Optional)</label>
                          <input
                            type="email"
                            placeholder="email@example.com"
                            value={authEmail}
                            onChange={(e) => setAuthEmail(e.target.value)}
                            className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 text-xs focus:bg-white focus:border-emerald-600 outline-hidden"
                          />
                        </div>
                      )}

                      {otpError && <p className="text-xs text-red-600 font-medium font-sans">{otpError}</p>}

                      <button
                        type="submit"
                        disabled={isAuthLoading}
                        className="w-full bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-3 rounded-xl shadow-xs transition-all text-xs uppercase tracking-wider flex items-center justify-center space-x-1 border border-emerald-800 cursor-pointer"
                      >
                        {isAuthLoading ? (
                          <>
                            <RefreshCw className="h-4.5 w-4.5 animate-spin" />
                            <span>Requesting Secure Token...</span>
                          </>
                        ) : (
                          <>
                            <span>Generate SMS Verification PIN</span>
                            <ArrowRight className="h-3.5 w-3.5" />
                          </>
                        )}
                      </button>
                    </form>

                    <div className="text-center pt-2 text-xs text-stone-500">
                      {authStep === 'register' ? (
                        <span>Already registered? <button onClick={() => handleStartAuth('login')} className="font-bold text-emerald-700 hover:underline cursor-pointer">Log In</button></span>
                      ) : (
                        <span>New retail customer? <button onClick={() => handleStartAuth('register')} className="font-bold text-emerald-700 hover:underline cursor-pointer">Register Profile</button></span>
                      )}
                    </div>
                  </div>
                )}
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* SHOP WINDOW TAB */}
        {activeTab === 'shop' && (
          <div className="space-y-8 text-left">
            
            {/* Promo banner header */}
            <div className="bg-emerald-800 text-white p-6 sm:p-10 rounded-3xl relative overflow-hidden flex flex-col md:flex-row justify-between items-center gap-6 border border-emerald-990 shadow-md">
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(16,185,129,0.3),transparent_50%50)]"></div>
              <div className="space-y-3 relative z-10 text-center md:text-left max-w-2xl">
                <span className="bg-amber-500 text-emerald-950 text-[10px] font-mono tracking-widest px-3.5 py-1 rounded-full uppercase leading-none font-bold">
                  🌱 100% Indian Lotus Seeds Popped Fresh
                </span>
                <h2 className="font-serif text-2xl sm:text-4xl font-bold leading-tight">Gourmet Bihar Makhana Directly To Your Door</h2>
                <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed max-w-xl font-sans">
                  Order premium Shuddh Sieve calibrated jumbo puffs or affordable daily Rozana packs. Secure processing at our Delhi hub - prices include air cargo logistics, tax, and packaging setup.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 shrink-0 relative z-10 w-full md:w-auto">
                <div className="bg-emerald-750 p-4 rounded-2xl border border-emerald-600/70 flex items-center space-x-3">
                  <CheckCircle2 className="h-7 w-7 text-amber-500 shrink-0" />
                  <div className="text-left font-sans">
                    <span className="text-xs uppercase block text-stone-200 font-bold">Sortex Clean</span>
                    <span className="text-[10px] text-emerald-205 block">No Empty Shells</span>
                  </div>
                </div>

                <div className="bg-emerald-750 p-4 rounded-2xl border border-emerald-600/70 flex items-center space-x-3">
                  <Truck className="h-7 w-7 text-amber-500 shrink-0" />
                  <div className="text-left font-sans">
                    <span className="text-xs uppercase block text-stone-200 font-bold">Free Air Courier</span>
                    <span className="text-[10px] text-emerald-205 block">24 Hour Dispatch</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Content area: either checkout finished or cart layout */}
            <AnimatePresence mode="wait">
              {placedOrder ? (
                <motion.div
                  key="checkout-success"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  className="bg-white border border-emerald-600 rounded-3xl p-6 sm:p-10 shadow-lg text-center space-y-6 max-w-xl mx-auto"
                >
                  <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600 border border-emerald-200 mx-auto text-3xl font-mono">
                    ✓
                  </div>
                  <div className="space-y-1.5">
                    <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">Retail Booking Confirmed!</h3>
                    <p className="text-xs text-stone-400 max-w-sm mx-auto leading-relaxed">
                      Your order hash tag is logged! Our sieve controllers and dispatch handlers have recorded your details onto our local spreadsheets to schedule shipment.
                    </p>
                  </div>

                  <div className="bg-stone-50 border border-stone-200 rounded-2xl p-5 text-left text-xs sm:text-sm font-sans space-y-2.5 max-w-sm mx-auto">
                    <div className="flex justify-between font-mono font-bold text-stone-900">
                      <span>Order Reference ID:</span>
                      <span className="text-emerald-700">{placedOrder.id}</span>
                    </div>

                    <div className="flex justify-between border-t border-stone-200/50 pt-2 text-stone-600">
                      <span>Recipient Customer:</span>
                      <span className="font-semibold text-stone-800">{placedOrder.customerName}</span>
                    </div>

                    <div className="flex justify-between border-t border-stone-200/50 pt-2 text-stone-600">
                      <span>Products Caliber:</span>
                      <span className="font-semibold text-stone-800 text-right max-w-[220px] leading-tight truncate">
                        {cartSummaryItems.map(item => `${item.quantity}x ${item.name}`).join(' + ')}
                      </span>
                    </div>

                    <div className="flex justify-between border-t-2 border-dashed border-stone-300 pt-3.5 text-base font-bold text-stone-950">
                      <span>Grand Invoice Total:</span>
                      <span className="text-emerald-700">₹{placedOrder.totalPrice}/-</span>
                    </div>
                  </div>

                  <div className="space-y-2 max-w-sm mx-auto">
                    <button
                      onClick={() => triggerWhatsAppConfirmation(placedOrder)}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white p-3.5 rounded-xl font-bold transition-all text-sm flex items-center justify-center space-x-2 shadow-xs cursor-pointer border border-emerald-700"
                    >
                      <Phone className="h-4.5 w-4.5 fill-current" />
                      <span>Confirm & Pay via WhatsApp</span>
                    </button>
                    
                    <button
                      onClick={handleResetForNewOrder}
                      className="w-full border border-stone-200 hover:border-stone-300 bg-white text-stone-700 font-bold p-3 py-2.5 rounded-xl text-xs transition-all cursor-pointer"
                    >
                      Continue Shopping Packets
                    </button>
                  </div>
                </motion.div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  {/* Left: Product Choice Grid plus Category and Search Filters */}
                  <div className="lg:col-span-12 xl:col-span-7 space-y-6">
                    <div className="flex flex-col sm:flex-row gap-3 justify-between sm:items-center border-b border-stone-200 pb-4">
                      <div className="space-y-0.5">
                        <h3 className="font-serif text-lg font-bold text-stone-900">1. Select Standardized Packets</h3>
                        <p className="text-[11px] text-stone-400 font-medium">Calibrated suta selections & organic agro items</p>
                      </div>
                      <span className="text-xs bg-stone-100 text-stone-605 font-bold px-2.5 py-1 rounded-md border border-stone-200/65 font-sans leading-none self-start sm:self-center">Prices include tax & logistics</span>
                    </div>

                    {/* Shopify Live Synchronizer Indicator Bar */}
                    <div className="bg-gradient-to-r from-emerald-50 to-stone-50/50 border border-emerald-150 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs font-sans">
                      <div className="flex items-center gap-2.5">
                        <div className="bg-emerald-100 text-emerald-800 p-2 rounded-xl">
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 12c0-1.232-.046-2.453-.138-3.662a4.006 4.006 0 00-3.7-3.7 48.656 48.656 0 00-7.324 0 4.006 4.006 0 00-3.7 3.7c-.017.22-.032.441-.046.662M19.5 12l3-3m-3 3l-3-3m-12 3c0 1.232.046 2.453.138 3.662a4.006 4.006 0 003.7 3.7 48.656 48.656 0 007.324 0 4.006 4.006 0 003.7-3.7c.017-.22.032-.441.046-.662M4.5 12l-3 3m3-3l3 3" />
                          </svg>
                        </div>
                        <div className="text-left font-sans">
                          <span className="font-bold text-stone-850 block">
                            {isShopifySynced ? `Shopify Headless Store Synced` : `Shopify Integration Installed`}
                          </span>
                          <p className="text-[10px] text-stone-500 font-medium">
                            {isShopifySynced 
                              ? `Connected to live products at ${shopifyDomain}` 
                              : `Target domain: ${shopifyDomain || 'shuddh-premium-makhana.myshopify.com'}. Add Storefront Access Token in Settings > Secrets to sync.`
                            }
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        {isShopifySynced && (
                          <span className="bg-emerald-100/80 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full select-none">
                            ● Connected
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={fetchShopifyProducts}
                          disabled={shopifySyncLoading}
                          className="bg-white hover:bg-stone-50 text-[10.5px] font-bold text-stone-700 px-3 py-1.5 rounded-xl border border-stone-250 transition-all cursor-pointer flex items-center gap-1 shadow-3xs"
                        >
                          {shopifySyncLoading ? (
                            <span className="flex items-center gap-1">
                              <span className="w-2 h-2 rounded-full border border-stone-500 border-t-transparent animate-spin"></span>
                              Syncing...
                            </span>
                          ) : "Sync catalog"}
                        </button>
                      </div>
                    </div>

                    {/* NexDrop-style Category Switcher Rail & Search Bar */}
                    <div className="space-y-4 font-sans text-left">
                      <div className="relative">
                        <Search className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-stone-400" />
                        <input
                          type="text"
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          placeholder="Search any grading suta (7 suta, 6 suta, 5 suta), roasted snacks, tea, etc..."
                          className="w-full bg-stone-50 border border-stone-200 focus:bg-white focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 rounded-2xl pl-11 pr-4 py-3 text-xs outline-hidden text-stone-800 font-medium transition-all shadow-2xs"
                        />
                      </div>

                      <div className="relative flex items-center justify-between">
                        <span className="text-[10px] uppercase font-bold text-stone-400 tracking-wider">Shop by NexDrop Categories</span>
                        {selectedCategory !== 'all' && (
                          <button 
                            onClick={() => setSelectedCategory('all')} 
                            className="text-[10px] text-emerald-700 hover:text-emerald-950 font-bold underline cursor-pointer"
                          >
                            Clear Filter
                          </button>
                        )}
                      </div>

                      {/* Horizontal Category Slider Bar */}
                      <div className="flex gap-2 items-center overflow-x-auto pb-2.5 pt-0.5 -mx-1 px-1 scrollbar-thin scrollbar-thumb-stone-205 select-none no-scrollbar">
                        {CATEGORIES.map((cat) => {
                          const isActive = selectedCategory === cat.id;
                          return (
                            <button
                              key={cat.id}
                              type="button"
                              onClick={() => setSelectedCategory(cat.id)}
                              className={`flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border shadow-xs cursor-pointer ${
                                isActive 
                                  ? 'bg-emerald-700 border-emerald-800 text-white font-bold scale-102 shadow-md' 
                                  : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100 hover:text-stone-900'
                              }`}
                            >
                              <span>{cat.icon}</span>
                              <span>{cat.name}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>

                    {/* Filtered Product Listing */}
                    {(() => {
                      const filteredProducts = productsCatalog.filter((p) => {
                        const matchesCat = selectedCategory === 'all' || (p?.category === selectedCategory);
                        const nameStr = p?.name || '';
                        const subtitleStr = p?.subtitle || '';
                        const descStr = p?.description || '';
                        const feats = Array.isArray(p?.features) ? p.features : [];
                        const query = searchQuery.toLowerCase();
                        const matchesSearch = nameStr.toLowerCase().includes(query) || 
                          subtitleStr.toLowerCase().includes(query) ||
                          descStr.toLowerCase().includes(query) ||
                          feats.some(f => (f || '').toLowerCase().includes(query));
                        return matchesCat && matchesSearch;
                      });

                      if (filteredProducts.length === 0) {
                        return (
                          <div className="bg-stone-50/70 border border-stone-250/60 rounded-3xl p-8 py-12 text-center text-stone-500 font-sans space-y-3">
                            <span className="text-4xl block">🌾</span>
                            <p className="font-serif font-bold text-stone-850">No Makhana Caliber Found</p>
                            <p className="text-xs text-stone-400 max-w-xs mx-auto">We couldn't find any products matching those parameters. Please try another category or check spelling of search queries.</p>
                            <button
                              onClick={() => {
                                setSelectedCategory('all');
                                setSearchQuery('');
                              }}
                              className="bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-4 py-2 rounded-xl transition-all border border-emerald-800 cursor-pointer shadow-xs mt-2"
                            >
                              Reset Product Filters
                            </button>
                          </div>
                        );
                      }

                      return (
                        <div className="flex flex-col gap-3.5 font-sans">
                          {filteredProducts.map((p) => {
                            const count = cart[p.id] || 0;
                            const categoryObj = CATEGORIES.find(c => c.id === p.category);
                            return (
                              <div
                                key={p.id}
                                className={`bg-white rounded-2xl border p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all relative text-left ${
                                  count > 0 
                                    ? 'border-emerald-700 ring-2 ring-emerald-600/5 bg-emerald-50/5' 
                                    : 'border-stone-200/90 shadow-2xs hover:border-stone-300'
                                }`}
                              >
                                {/* Left Section: Icon badge and product metadata */}
                                <div onClick={() => setSelectedProduct(p)} className="flex items-start gap-4 flex-1 min-w-0 cursor-pointer group">
                                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center text-lg shrink-0 border transition-all ${
                                    count > 0 
                                      ? 'bg-emerald-100 border-emerald-200 text-emerald-900 font-bold scale-102' 
                                      : 'bg-stone-50 border-stone-200/70 text-stone-500 group-hover:bg-emerald-50 group-hover:border-emerald-250 group-hover:text-emerald-700'
                                  }`}>
                                    {categoryObj ? categoryObj.icon : '🌾'}
                                  </div>
 
                                  <div className="space-y-1 min-w-0 flex-1">
                                    <div className="flex flex-wrap items-center gap-2">
                                      <h4 className="font-serif text-sm sm:text-base font-bold text-stone-900 leading-tight group-hover:text-emerald-700 transition-colors">
                                        {p.name}
                                      </h4>
                                      <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full border leading-none tracking-wider uppercase shrink-0 ${
                                        (p?.category || '').includes('suta') || p?.category === 'mix'
                                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
                                          : 'bg-amber-50 text-amber-855 border-amber-200'
                                      }`}>
                                        {p?.badge || 'Makhana'}
                                      </span>
                                    </div>
 
                                    <div className="flex flex-wrap items-center gap-1.5 text-[11px] font-medium text-stone-400">
                                      <span className="text-emerald-800 font-mono font-semibold uppercase">{p?.subtitle || 'Shuddh Premium Group'}</span>
                                      <span>•</span>
                                      <span className="bg-stone-100 font-bold text-stone-605 px-1.5 py-0.5 rounded-md text-[10px]">
                                        {p?.weight === '1 kg' ? 'Bulk Segment' : `${p?.weight || '250g'} Pouch`}
                                      </span>
                                      {p?.minQty && p.minQty > 1 ? (
                                        <>
                                          <span>•</span>
                                          <span className="bg-amber-100 font-bold text-amber-800 px-1.5 py-0.5 rounded-md text-[10px]">Min. Booking: {p.minQty} kg</span>
                                        </>
                                      ) : null}
                                      <span>•</span>
                                      <span className="text-emerald-705 font-bold group-hover:underline text-[10.5px]">Click to View Details & Buy Directly →</span>
                                    </div>
 
                                    <p className="text-xs text-stone-505 leading-relaxed max-w-xl mt-1.5 line-clamp-2 md:line-clamp-none">
                                      {p?.description || ''}
                                    </p>
                                  </div>
                                </div>

                                {/* Right Section: Price & Quantity select row coupling */}
                                <div className="flex items-center justify-between md:justify-end gap-5 border-t border-stone-100 md:border-t-0 pt-3 md:pt-0 shrink-0 w-full md:w-auto">
                                  <div className="text-left md:text-right">
                                    <span className="text-[10px] text-stone-400 font-bold block uppercase tracking-wider leading-none mb-1">
                                      {p?.weight === '1 kg' ? 'Bulk Price' : 'Packet Price'}
                                    </span>
                                    <span className="text-base sm:text-lg font-bold font-mono text-stone-900 leading-none">
                                      ₹{p?.price || 0}/-{p?.weight === '1 kg' ? <span className="text-[10px] ml-0.5 text-stone-500 font-sans font-normal lowercase">/kg</span> : ''}
                                    </span>
                                  </div>

                                  {count === 0 ? (
                                    <button
                                      type="button"
                                      onClick={() => handleQtyChange(p.id, 1)}
                                      className="bg-emerald-700 hover:bg-emerald-850 border border-emerald-800 text-white font-bold px-4 py-2.5 rounded-xl transition-all text-xs flex items-center space-x-1.5 cursor-pointer shadow-xs whitespace-nowrap h-10 select-none"
                                    >
                                      <Plus className="h-4 w-4" />
                                      <span>{p.weight === '1 kg' ? 'Add Bulk Grade' : 'Add Packet'}</span>
                                    </button>
                                  ) : (
                                    <div className="flex items-center space-x-1.5 bg-emerald-50 border border-emerald-200 rounded-xl p-1 shrink-0 h-10 select-none">
                                      <button
                                        type="button"
                                        onClick={() => handleQtyChange(p.id, count - 1)}
                                        className="p-1.5 hover:bg-emerald-100 text-emerald-800 rounded-lg transition-all cursor-pointer"
                                      >
                                        <Minus className="h-4 w-4" />
                                      </button>
                                      <span className="w-9 text-center text-xs font-bold font-mono text-emerald-950">
                                        {count}{p.weight === '1 kg' ? ' kg' : ''}
                                      </span>
                                      <button
                                        type="button"
                                        onClick={() => handleQtyChange(p.id, count + 1)}
                                        className="p-1.5 hover:bg-emerald-100 text-emerald-800 rounded-lg transition-all cursor-pointer"
                                      >
                                        <Plus className="h-4 w-4" />
                                      </button>
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      );
                    })()}

                    <div className="bg-stone-100/55 border border-stone-200/60 p-5 rounded-3xl text-left font-sans flex items-start gap-4">
                      <span className="text-3xl">🛡️</span>
                      <div className="space-y-1">
                        <h4 className="font-serif text-sm sm:text-base font-bold text-stone-850">The AMD Quality Oath</h4>
                        <p className="text-xs text-stone-500 leading-relaxed font-sans">
                          We perform traditional physical sieve screening tests and sort popped seeds mechanically. The moisture index of each retail packet is maintained strictly beneath 5% to lock in the ultimate crunch. No bleached white chalks are added.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Right: Checkout Delivery Form */}
                  <div className="lg:col-span-12 xl:col-span-5 bg-white border border-stone-200 p-6 sm:p-8 rounded-3xl shadow-sm space-y-6 text-left">
                    <div>
                      <h3 className="font-serif text-lg font-bold text-stone-900 flex items-center gap-1.5">
                        <MapPin className="text-emerald-700 h-5 w-5" />
                        <span>2. Delivery Address Checkout</span>
                      </h3>
                      <p className="text-xs text-stone-400 mt-0.5">Where should we courier your fresh packets?</p>
                    </div>

                    <div className="bg-stone-50 border border-stone-100 p-4 rounded-xl font-mono text-xs text-stone-600 space-y-2 leading-tight max-h-[220px] overflow-y-auto">
                      {cartSummaryItems.length === 0 ? (
                        <div className="text-center py-4 text-stone-400 font-sans italic">Bag is currently empty.</div>
                      ) : (
                        cartSummaryItems.map((item) => (
                          <div key={item.id} className="flex justify-between gap-1 items-center">
                            <span className="truncate pr-2 font-medium">{item.name} ({item.weight}):</span>
                            <span className="font-bold text-stone-755 shrink-0">{item.quantity} × ₹{item.price}</span>
                          </div>
                        ))
                      )}
                      <div className="flex justify-between border-t border-stone-200/50 pt-2 text-stone-500 font-bold text-[10px]">
                        <span>Cart Subtotal:</span>
                        <span>₹{cartSubtotal}/-</span>
                      </div>
                      <div className="flex justify-between text-emerald-800 font-bold text-[10px]">
                        <span>Area Courier Fee ({formData.state}):</span>
                        <span>₹{shippingCharge}/-</span>
                      </div>
                      <div className="flex justify-between border-t-2 border-dashed border-stone-300 pt-3 text-sm font-bold text-stone-900">
                        <span>Grand Invoice Total:</span>
                        <span className="text-emerald-850 text-base font-bold">₹{grandTotal}/-</span>
                      </div>
                    </div>

                    <form onSubmit={handlePlaceOrder} className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-stone-700 block">Full Recipient Name *</label>
                        <div className="relative">
                          <User className="absolute left-3 top-3.5 h-4 w-4 text-stone-400" />
                          <input
                            type="text"
                            required
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            placeholder="Recipient name"
                            className="w-full bg-stone-50 border border-stone-200/85 rounded-xl focus:bg-white focus:border-emerald-600 pl-9 py-2.5 text-xs outline-hidden text-stone-850 font-medium"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-stone-700 block">WhatsApp Mobile Number *</label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-3.5 h-4 w-4 text-stone-400" />
                          <input
                            type="tel"
                            required
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            placeholder="10 digit contact"
                            className="w-full bg-stone-50 border border-stone-200/85 rounded-xl focus:bg-white focus:border-emerald-600 pl-9 py-2.5 text-xs text-stone-850 font-mono outline-hidden"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-stone-700 block">Email Address (Optional)</label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-3.5 h-4 w-4 text-stone-400" />
                          <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            placeholder="recipient@example.com"
                            className="w-full bg-stone-50 border border-stone-200/85 rounded-xl focus:bg-white focus:border-emerald-600 pl-9 py-2.5 text-xs outline-hidden text-stone-850 font-medium"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-stone-700 block">GST Number (Optional)</label>
                        <div className="relative">
                          <FileText className="absolute left-3 top-3.5 h-4 w-4 text-stone-400" />
                          <input
                            type="text"
                            name="gstNumber"
                            value={formData.gstNumber || ''}
                            onChange={handleInputChange}
                            placeholder="e.g. 07AAAAA1111A1Z1"
                            className="w-full bg-stone-50 border border-stone-200/85 rounded-xl focus:bg-white focus:border-emerald-600 pl-9 py-2.5 text-xs outline-hidden text-stone-850 font-mono"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-stone-700 block">Postal Pincode *</label>
                        <input
                          type="text"
                          required
                          maxLength={6}
                          name="pincode"
                          value={formData.pincode}
                          onChange={handleInputChange}
                          placeholder="e.g. 110001"
                          className="w-full bg-stone-50 border border-stone-200/85 rounded-xl focus:bg-white focus:border-emerald-600 px-3.5 py-2.5 text-xs font-mono text-stone-850 outline-hidden"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3.5">
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-stone-700 block">State *</label>
                          <select
                            name="state"
                            value={formData.state}
                            onChange={(e) => {
                              const selectedSt = e.target.value;
                              const defaultCities = INDIAN_STATES_CITIES[selectedSt] || [];
                              setFormData(prev => ({
                                ...prev,
                                state: selectedSt,
                                city: defaultCities[0] || ''
                              }));
                            }}
                            className="w-full bg-stone-50 border border-stone-200/85 rounded-xl focus:bg-white focus:border-emerald-600 px-2 py-2.5 text-xs outline-hidden text-stone-850 font-semibold"
                          >
                            {Object.keys(INDIAN_STATES_CITIES).map(st => (
                              <option key={st} value={st}>{st}</option>
                            ))}
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-stone-700 block">City *</label>
                          <select
                            name="city"
                            value={
                              (formData.city === 'Other' || (formData.city && !((INDIAN_STATES_CITIES[formData.state] || []).filter(c => c !== 'Other')).includes(formData.city)))
                                ? 'Other'
                                : formData.city
                            }
                            onChange={(e) => {
                              const val = e.target.value;
                              setFormData(prev => ({ ...prev, city: val }));
                            }}
                            className="w-full bg-stone-50 border border-stone-200/85 rounded-xl focus:bg-white focus:border-emerald-600 px-2 py-2.5 text-xs outline-hidden text-stone-850 font-semibold"
                          >
                            {((INDIAN_STATES_CITIES[formData.state] || []).filter(c => c !== 'Other')).map(ct => (
                              <option key={ct} value={ct}>{ct}</option>
                            ))}
                            <option value="Other">Other / Type Custom City</option>
                          </select>
                          {(formData.city === 'Other' || (formData.city && !((INDIAN_STATES_CITIES[formData.state] || []).filter(c => c !== 'Other')).includes(formData.city))) && (
                            <input
                              type="text"
                              required
                              placeholder="Type custom city"
                              value={formData.city === 'Other' ? '' : formData.city}
                              onChange={(e) => {
                                const val = e.target.value;
                                setFormData(prev => ({ ...prev, city: val }));
                              }}
                              className="w-full mt-1.5 bg-stone-100 border border-stone-250 rounded-xl px-3 py-2.5 text-xs outline-hidden focus:bg-white focus:border-emerald-600 font-semibold text-stone-850"
                            />
                          )}
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-stone-700 block">Shipping Flat/House, Layout, Landmark Address *</label>
                        <textarea
                          required
                          name="address"
                          value={formData.address}
                          onChange={handleInputChange}
                          rows={2.5}
                          placeholder="Plot No 149-B, Sector 2..."
                          className="w-full bg-stone-50 border border-stone-200/85 rounded-xl focus:bg-white focus:border-emerald-600 p-3 text-xs outline-hidden text-stone-850 font-medium"
                        />
                      </div>

                      <button
                        type="submit"
                        disabled={grandTotal === 0 || isSubmitting}
                        className={`w-full py-4 rounded-xl text-xs font-bold transition-all shadow-xs uppercase tracking-wider flex items-center justify-center space-x-2 border cursor-pointer ${
                          grandTotal === 0 
                            ? 'bg-stone-100 text-stone-400 border-stone-200 cursor-not-allowed' 
                            : 'bg-emerald-700 hover:bg-emerald-800 text-white border-emerald-800'
                        }`}
                      >
                        {isSubmitting ? (
                          <>
                            <RefreshCw className="h-4.5 w-4.5 animate-spin" />
                            <span>Booking Retail Package...</span>
                          </>
                        ) : (
                          <>
                            <ShoppingCart className="h-4.5 w-4.5" />
                            <span>Checkout Retail Order & Pay (₹{grandTotal}/-)</span>
                          </>
                        )}
                      </button>
                    </form>
                  </div>
                </div>
              )}
            </AnimatePresence>
          </div>
        )}

        {/* TRACKING TAB VIEW */}
        {activeTab === 'track' && (
          <div className="space-y-8 text-left">
            <div className="max-w-2xl mx-auto bg-white border border-stone-200/80 p-6 sm:p-10 rounded-3xl shadow-xs space-y-6">
              
              <div className="space-y-1 text-center">
                <span className="text-xs uppercase bg-emerald-50 text-emerald-800 px-3 py-1 border border-emerald-200 rounded-full font-bold font-sans">
                  🚚 Real-Time Retail Dispatch Tracking
                </span>
                <h3 className="font-serif text-xl sm:text-2xl font-bold text-stone-900 mt-2">Locate Package Calibers</h3>
                <p className="text-xs text-stone-500 font-sans">Track shipments using your unique AMD Order Reference ID below</p>
              </div>

              <form onSubmit={handleQueryTrackPackage} className="sm:flex gap-2.5 max-w-md mx-auto relative font-sans">
                <div className="relative w-full">
                  <Search className="absolute left-3 top-3.5 h-4 w-4 text-stone-400" />
                  <input
                    type="text"
                    required
                    value={trackingId}
                    onChange={(e) => setTrackingId(e.target.value)}
                    placeholder="e.g. AMD-R-2002"
                    className="w-full bg-stone-50 border border-stone-200/80 focus:bg-white focus:border-emerald-600 rounded-xl pl-9 py-2.5 text-xs text-stone-850 font-mono py-3 outline-hidden"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full sm:w-auto bg-emerald-700 hover:bg-emerald-800 text-white font-bold p-3 px-6 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all mt-2 sm:mt-0 cursor-pointer shadow-xs border border-emerald-800"
                >
                  <Navigation className="h-3.5 w-3.5 rotate-45" />
                  <span>Locate Shipment</span>
                </button>
              </form>

              {trackingError && (
                <p className="text-xs text-red-600 text-center font-semibold bg-red-50 border border-red-200 p-3 rounded-xl max-w-md mx-auto">
                  {trackingError}
                </p>
              )}

              {liveTrackedOrder && searchedTrackingId && (
                <div className="border border-stone-200/85 rounded-2xl overflow-hidden mt-6 bg-stone-50/50">
                  <div className="bg-stone-100 p-4 border-b border-stone-200 flex justify-between items-center flex-wrap gap-2 text-xs font-sans">
                    <div>
                      <span className="text-stone-400 font-semibold block uppercase text-[10px]">Tracking Order</span>
                      <strong className="text-emerald-850 font-mono text-sm block">{liveTrackedOrder.id}</strong>
                    </div>
                    <div>
                      <span className="text-stone-400 font-semibold block uppercase text-[10px]">Order Stamp</span>
                      <span className="font-mono text-stone-700 font-bold block">{new Date(liveTrackedOrder.date).toLocaleDateString()}</span>
                    </div>
                    <div>
                      <span className="text-stone-400 font-semibold block uppercase text-[10px] mb-0.5">Status Flag</span>
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-wider leading-none border ${
                        liveTrackedOrder.status === 'Delivered' 
                          ? 'bg-emerald-100 text-emerald-800 border-emerald-300' 
                          : liveTrackedOrder.status === 'Shipped' 
                          ? 'bg-blue-100 text-blue-800 border-blue-200' 
                          : liveTrackedOrder.status === 'Cancelled'
                          ? 'bg-red-50 text-red-700 border-red-200'
                          : 'bg-amber-100 text-amber-800 border-amber-200'
                      }`}>
                        {liveTrackedOrder.status}
                      </span>
                    </div>
                  </div>

                  <div className="p-6 space-y-6">
                    <div className="relative flex justify-between items-center max-w-md mx-auto py-4">
                      
                      <span className="absolute left-0 right-0 h-1 bg-stone-200 top-1/2 -translate-y-1/2 z-0"></span>
                      
                      <span className={`absolute left-0 h-1 bg-emerald-600 top-1/2 -translate-y-1/2 z-0 origin-left transition-all duration-700 ${
                        liveTrackedOrder.status === 'Pending' ? 'w-1/4' : liveTrackedOrder.status === 'Shipped' ? 'w-2/3' : 'w-full'
                      }`}></span>

                      <div className="relative z-10 text-center font-sans">
                        <span className="w-8 h-8 rounded-full bg-emerald-700 text-white flex items-center justify-center font-bold text-xs ring-4 ring-white border border-emerald-800 mx-auto">
                          1
                        </span>
                        <span className="text-[10px] text-stone-600 font-bold block mt-1.5">Confirmed</span>
                      </div>

                      <div className="relative z-10 text-center font-sans">
                        <span className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ring-4 ring-white border mx-auto ${
                          ['Shipped', 'Delivered'].includes(liveTrackedOrder.status) 
                            ? 'bg-emerald-700 text-white border-emerald-800' 
                            : 'bg-stone-100 text-stone-400 border-stone-200'
                        }`}>
                          2
                        </span>
                        <span className="text-[10px] text-stone-600 font-bold block mt-1.5">Sort & Pack</span>
                      </div>

                      <div className="relative z-10 text-center font-sans">
                        <span className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ring-4 ring-white border mx-auto ${
                          ['Shipped', 'Delivered'].includes(liveTrackedOrder.status) 
                            ? 'bg-emerald-700 text-white border-emerald-800' 
                            : 'bg-stone-100 text-stone-400 border-stone-200'
                        }`}>
                          3
                        </span>
                        <span className="text-[10px] text-stone-600 font-bold block mt-1.5">Dispatched</span>
                      </div>

                      <div className="relative z-10 text-center font-sans">
                        <span className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ring-4 ring-white border mx-auto ${
                          liveTrackedOrder.status === 'Delivered' 
                            ? 'bg-emerald-700 text-white border-emerald-800' 
                            : 'bg-stone-100 text-stone-400 border-stone-200'
                        }`}>
                          4
                        </span>
                        <span className="text-[10px] text-stone-600 font-bold block mt-1.5">Delivered</span>
                      </div>
                    </div>

                    <div className="bg-white p-4.5 rounded-2xl border border-stone-100 text-stone-600 space-y-3 font-sans text-xs">
                      <div>
                        {liveTrackedOrder.status === 'Pending' && (
                          <div className="flex items-start gap-2.5">
                            <Clock className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
                            <div>
                              <h5 className="font-bold text-stone-900">Crop Sorting & Caliber Verification</h5>
                              <p className="text-[11px] text-stone-400 mt-1 font-sans">Our production team is physical-sieve filtering your fresh batch. Readying for airtight packaging in 250-gram foil. Your order remains pending UPI confirmation flags.</p>
                            </div>
                          </div>
                        )}

                        {liveTrackedOrder.status === 'Shipped' && (
                          <div className="flex items-start gap-2.5">
                            <Truck className="h-5 w-5 text-blue-600 shrink-0 mt-0.5" />
                            <div>
                              <h5 className="font-bold text-stone-900">Handed over to Blue Dart / Delhivery courier</h5>
                              <p className="text-[11px] text-stone-400 mt-1 font-sans font-medium">Dispatched successfully under Air Cargo tracking. Package is flying prompt to your regional destination center hub.</p>
                            </div>
                          </div>
                        )}

                        {liveTrackedOrder.status === 'Delivered' && (
                          <div className="flex items-start gap-2.5">
                            <Check className="h-5 w-5 text-emerald-600 bg-emerald-50 border border-emerald-200 rounded-lg p-0.5 shrink-0 mt-0.5 animate-pulse" />
                            <div>
                              <h5 className="font-bold text-stone-900">Nourishment Delivered Safely</h5>
                              <p className="text-[11px] text-stone-400 mt-1 font-sans font-medium">Order arrived safely at recipient household. We appreciate your purchase with AMD Trading Company. Please roast and chew fresh dried makhana snacks daily!</p>
                            </div>
                          </div>
                        )}

                        {liveTrackedOrder.status === 'Cancelled' && (
                          <div className="flex items-start gap-2.5">
                            <Trash2 className="h-5 w-5 text-red-650 shrink-0 mt-0.5" />
                            <div>
                              <h5 className="font-bold text-red-700">Order Void / Cancelled</h5>
                              <p className="text-[11px] text-stone-400 mt-1 font-sans">This retail booking order is flagged as cancelled. Please feel free to request support over WhatsApp to clarify reasons.</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="pt-3 border-t border-stone-100 flex justify-between items-center flex-wrap gap-2 text-xs font-sans">
                      <span className="text-stone-400 font-semibold">Payment status: <strong className="text-emerald-700">{liveTrackedOrder.status === 'Delivered' ? 'UPI Confirmed' : 'Awaiting confirmation'}</strong></span>
                      <button
                        onClick={() => triggerWhatsAppConfirmation(liveTrackedOrder)}
                        className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1.5"
                      >
                        <Phone className="h-3.5 w-3.5" />
                        <span>Chat Support</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* List personal orders associated with logged in client */}
            {activeUser && (
              <div className="max-w-4xl mx-auto space-y-4 font-sans">
                <h4 className="font-serif text-lg font-bold text-stone-900">Your Booking History ({activeUser.phone})</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {orders.filter(o => o.customerPhone === activeUser.phone).length === 0 ? (
                    <div className="bg-white border border-stone-200 p-8 rounded-3xl text-center text-stone-400 text-xs sm:col-span-2 font-medium">
                      No matching historical checkouts logged beneath your active credentials. Feel free to purchase packets on the retail shop!
                    </div>
                  ) : (
                    orders.filter(o => o.customerPhone === activeUser.phone).map((histOrder) => (
                      <div 
                        key={histOrder.id} 
                        className="bg-white border border-stone-200 hover:border-stone-300 p-5 rounded-2xl flex justify-between items-start transition-all cursor-pointer shadow-3xs"
                        onClick={() => selectPreloadTrack(histOrder.id)}
                      >
                        <div className="space-y-1.5 text-left">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-sm font-bold text-stone-855">{histOrder.id}</span>
                            <span className={`text-[9px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border ${
                              histOrder.status === 'Delivered' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' : 'bg-amber-50 text-amber-805 border-amber-200'
                            }`}>
                              {histOrder.status}
                            </span>
                          </div>
                          <span className="text-[11px] font-semibold text-stone-400 block font-mono">{new Date(histOrder.date).toLocaleDateString()}</span>
                          <span className="text-xs font-bold text-stone-800 block">{histOrder.productName} (250g) x {histOrder.quantity} pkt</span>
                        </div>

                        <div className="text-right space-y-1 bg-stone-50/20 p-2 rounded-xl border border-stone-100">
                          <span className="text-sm font-bold font-mono text-stone-900 block">₹{histOrder.totalPrice}/-</span>
                          {histOrder.deliveryCharge !== undefined && histOrder.deliveryCharge > 0 ? (
                            <span className="text-[9px] text-stone-400 block leading-none">Incl. ₹{histOrder.deliveryCharge} delivery ({histOrder.state})</span>
                          ) : (
                            <span className="text-[9px] text-stone-400 block leading-none">Included shipping</span>
                          )}
                          <span className="text-[9px] text-emerald-800 hover:underline block font-bold uppercase pt-1">Track package →</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ADMIN EXCEL REPORTS TAB */}
        {activeTab === 'admin' && (
          <div className="space-y-8 font-sans">
            
            {!isAdminAuthenticated ? (
              <div className="max-w-md mx-auto bg-white border border-stone-200/80 p-8 rounded-3xl shadow-lg space-y-6 text-center">
                <div className="w-12 h-12 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-center text-amber-700 mx-auto text-xl font-mono">
                  🔒
                </div>
                <div className="space-y-1">
                  <h4 className="font-serif text-xl font-bold text-stone-900">Merchant Back-Office security</h4>
                  <p className="text-xs text-stone-400">Please enter credentials to gain access to order reports.</p>
                </div>

                <form onSubmit={handleAdminLogin} className="space-y-4 text-left">
                  <div className="space-y-2">
                    <label className="text-xs font-semibold text-stone-700 block">Enter Security PIN *</label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-3.5 h-4 w-4 text-stone-400" />
                      <input
                        type="password"
                        required
                        value={adminPin}
                        onChange={(e) => setAdminPin(e.target.value)}
                        placeholder="••••"
                        className="w-full bg-stone-50 border border-stone-200 focus:bg-white focus:border-amber-600 rounded-xl pl-9 py-2.5 text-xs font-mono text-stone-800 outline-hidden transition-all font-semibold"
                      />
                    </div>
                    {pinError && <p className="text-[10px] text-red-500 font-semibold">{pinError}</p>}
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 rounded-xl font-semibold shadow-xs transition-colors flex items-center justify-center space-x-1 border border-amber-700 text-xs cursor-pointer"
                  >
                    <span>Authenticate Control Suite</span>
                    <ArrowRight className="h-3.5 w-3.5" />
                  </button>
                </form>
              </div>
            ) : (
              <div className="space-y-6 text-left font-sans">
                
                {/* Stats cards row */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                  <div className="bg-white border border-stone-200 rounded-2xl p-5 flex items-center space-x-4 shadow-3xs">
                    <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100/50 text-emerald-700">
                      <TrendingUp className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block font-sans">Total Revenue</span>
                      <span className="text-lg font-mono font-bold text-stone-950">
                        ₹{orders.filter(o => o.status !== 'Cancelled').reduce((acc, current) => acc + current.totalPrice, 0)}/-
                      </span>
                    </div>
                  </div>

                  <div className="bg-white border border-stone-200 rounded-2xl p-5 flex items-center space-x-4 shadow-3xs">
                    <div className="p-3 bg-blue-50 rounded-xl border border-blue-100/50 text-blue-700">
                      <ClipboardList className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block font-sans">Total Checkouts</span>
                      <span className="text-lg font-mono font-bold text-stone-950">{orders.length} orders</span>
                    </div>
                  </div>

                  <div className="bg-white border border-stone-200 rounded-2xl p-5 flex items-center space-x-4 shadow-3xs">
                    <div className="p-3 bg-amber-50 rounded-xl border border-amber-100/50 text-amber-700">
                      <Clock className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block font-sans">Pending Sifting</span>
                      <span className="text-lg font-mono font-bold text-stone-950">
                        {orders.filter(o => o.status === 'Pending').length} orders
                      </span>
                    </div>
                  </div>

                  <div className="bg-white border border-stone-200 rounded-2xl p-5 flex items-center space-x-4 shadow-3xs">
                    <div className="p-3 bg-stone-100 rounded-xl border border-stone-200 text-stone-700">
                      <Briefcase className="h-5 w-5" />
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block font-sans">Unique Buyers</span>
                      <span className="text-lg font-mono font-bold text-stone-950">
                        {new Set(orders.map(o => o.customerPhone)).size} customers
                      </span>
                    </div>
                  </div>
                </div>

                {/* EXCEL SHEET DOWNLOADS */}
                <div className="bg-emerald-905 bg-emerald-900 text-white p-6 rounded-3xl flex flex-col lg:flex-row justify-between items-center gap-6 border border-emerald-950 shadow-md">
                  <div className="space-y-1.5 text-center lg:text-left">
                    <div className="flex items-center justify-center lg:justify-start gap-1.5 font-bold text-emerald-300">
                      <FileSpreadsheet className="h-5 w-5 text-emerald-400" />
                      <span className="text-xs uppercase tracking-wider font-mono">B2B Inventory Segments</span>
                    </div>
                    <h4 className="font-serif text-xl sm:text-2xl font-bold">Download Separate Excel Sheets</h4>
                    <p className="text-xs text-emerald-200 max-w-xl leading-relaxed font-sans font-medium">
                      Separate spreadsheet extraction is configured below. Generate independent spreadsheet tables for Shuddh Premium and Rozana to audit packaging pipelines.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2.5 shrink-0 justify-center">
                    <button
                      onClick={() => handleExportCSV('shuddh')}
                      className="bg-amber-500 hover:bg-amber-600 border border-amber-600 text-stone-950 font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer"
                    >
                      <Download className="h-4 w-4" />
                      <span>Shuddh Premium Pkt Sheet (.csv)</span>
                    </button>

                    <button
                      onClick={() => handleExportCSV('rozana')}
                      className="bg-emerald-600 hover:bg-emerald-700 border border-emerald-500 text-white font-bold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-colors shadow-xs cursor-pointer"
                    >
                      <Download className="h-4 w-4" />
                      <span>Rozana Makhana Pkt Sheet (.csv)</span>
                    </button>

                    <button
                      onClick={() => handleExportCSV('all')}
                      className="bg-white/10 hover:bg-white/20 border border-white/20 text-white font-bold px-4.5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-all cursor-pointer"
                    >
                      <FileText className="h-4 w-4" />
                      <span>Consolidated Log</span>
                    </button>
                  </div>
                </div>

                {/* SHOPIFY HEADLESS CONNECTION HUB */}
                <div className="bg-white border border-stone-200/90 rounded-3xl p-6 space-y-6 shadow-3xs text-left">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-stone-900 font-bold">
                        <div className="p-2 bg-gradient-to-r from-emerald-600 to-emerald-700 text-white rounded-xl">
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21v-7.5a.75.75 0 01.75-.75h3a.75.75 0 01.75.75V21m-4.5 0H2.36m11.14 0H18m0 0h3.64m-1.39 0V9.349m-16.5 11.65V9.35m0 0a3.001 3.001 0 003.75-.615A2.993 2.993 0 009.75 9.75c.896 0 1.7-.393 2.25-1.016a2.993 2.993 0 002.25 1.016c.896 0 1.7-.393 2.25-1.015a3.001 3.001 0 003.75.614m-16.5 0a3.004 3.004 0 01-.621-4.72L4.318 3.44A1.5 1.5 0 015.378 3h13.243a1.5 1.5 0 011.06.44l1.19 1.189a3 3 0 01-.621 4.72M6.75 18h3.5a.75.75 0 00.75-.75v-3.5a.75.75 0 00-.75-.75h-3.5a.75.75 0 00-.75.75v3.5a.75.75 0 00.75.75z" />
                          </svg>
                        </div>
                        <h4 className="font-serif text-lg sm:text-xl font-bold text-stone-900">Shopify Headless Sync Control Panel</h4>
                      </div>
                      <p className="text-xs text-stone-500 font-medium">
                        Synchronize your live makhana products, bags count, custom variants, and pricing straight from your Shopify storefront.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-stone-50 p-4 border border-stone-200/60 rounded-2xl">
                    <div className="space-y-3 font-sans text-xs">
                      <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block text-left">Integration Instruction Checklist</span>
                      <ol className="space-y-2 text-stone-600 font-semibold text-left list-decimal list-inside pl-1 bg-white p-3.5 border border-stone-200/60 rounded-xl leading-relaxed">
                        <li>Log into your Shopify Store admin console for <strong className="text-stone-800">shuddh-premium-makhana</strong>.</li>
                        <li>Install or check the <strong className="text-emerald-800">Storefront API</strong> client under Settings &gt; App Development &gt; Create an app.</li>
                        <li>Acquire your <strong>Storefront Access Token</strong> (typically starts with <code className="bg-stone-50 px-1 text-[11px] font-mono">shpca_</code>).</li>
                        <li>Open the AI Studio <strong>Settings &gt; Secrets</strong> modal on the top right, and declare <code className="bg-stone-50 px-1 text-[10.5px] font-mono font-bold text-amber-700">SHOPIFY_STOREFRONT_ACCESS_TOKEN</code> to map live checkout.</li>
                      </ol>
                    </div>

                    <div className="space-y-3.5 flex flex-col justify-between font-sans">
                      <div className="space-y-2 bg-white p-3.5 border border-stone-200/60 rounded-xl text-xs text-left">
                        <span className="text-[10px] uppercase font-bold tracking-wider text-stone-400 block">Active Live Status Check</span>
                        <div className="flex items-center gap-2 pt-1 font-sans">
                          <span className={`w-3 h-3 rounded-full ${isShopifySynced ? 'bg-green-500 animate-pulse' : 'bg-stone-300'}`}></span>
                          <span className="font-bold text-stone-850">
                            {isShopifySynced ? `Shopify Connected!` : `Shopify Status Details`}
                          </span>
                        </div>
                        <div className="space-y-1.5 mt-2 pt-1 border-t border-stone-100 text-[11px] text-stone-500 font-medium leading-relaxed">
                          <p>● Target Host: <strong className="text-stone-750 font-semibold">{shopifyDomain || "shuddh-premium-makhana.myshopify.com"}</strong></p>
                          <p>● Live Products: <strong className="text-stone-750 font-semibold">{isShopifySynced ? `${productsCatalog.filter(p => p.shopifyId).length} Items Connected` : 'बिहार मंदी Fallback Catalog Active'}</strong></p>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={fetchShopifyProducts}
                          disabled={shopifySyncLoading}
                          className="flex-1 bg-emerald-750 bg-emerald-700 hover:bg-emerald-800 text-white font-bold py-2.5 rounded-xl border border-emerald-800 text-xs transition-all cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                        >
                          {shopifySyncLoading ? "Syncing..." : "Force Catalog Sync"}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                {/* MERCHANT NOTIFICATIONS HUB */}
                <div className="bg-white border border-stone-200/90 rounded-3xl p-6 space-y-6 shadow-3xs">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 text-stone-900 font-bold">
                        <div className="p-2 bg-amber-500/10 text-amber-600 rounded-xl border border-amber-500/10">
                          <Bell className="h-5 w-5 animate-pulse" />
                        </div>
                        <h4 className="font-serif text-lg sm:text-xl font-bold">Real-Time Order Notifications & Alarm Hub</h4>
                      </div>
                      <p className="text-xs text-stone-500">
                        Stay notified immediately across devices, WhatsApp, and chat screens when buyers process checkout payments of Shuddh and Rozana Makhana packets.
                      </p>
                    </div>
                    <button
                      onClick={() => handleSaveNotificationSettings()}
                      className="bg-amber-600 hover:bg-amber-700 text-white font-bold px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-xs cursor-pointer select-none"
                    >
                      <Check className="h-4 w-4" />
                      <span>Save Alerts Config</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                    
                    {/* Column 1: Live Browser Sound & Push notifications */}
                    <div className="bg-stone-50/50 border border-stone-150 rounded-2xl p-4.5 space-y-4">
                      <div className="flex items-center gap-2 pb-1 border-b border-stone-200/70">
                        <Volume2 className="h-4 w-4 text-amber-600" />
                        <span className="text-xs font-bold text-stone-800 uppercase tracking-wider font-mono">1. Local Active Screens</span>
                      </div>
                      
                      <div className="space-y-3">
                        <label className="flex items-center justify-between cursor-pointer select-none">
                          <div className="space-y-0.5">
                            <span className="text-xs font-bold text-stone-700 block">Sound Alarms & Chimes</span>
                            <span className="text-[10px] text-stone-400 block max-w-[160px]">Play a pleasant high-notice ring chime when an order lands.</span>
                          </div>
                          <input
                            type="checkbox"
                            checked={notifySoundAlerts}
                            onChange={(e) => setNotifySoundAlerts(e.target.checked)}
                            className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 border-stone-300"
                          />
                        </label>

                        <label className="flex items-center justify-between cursor-pointer select-none pt-2 border-t border-stone-100">
                          <div className="space-y-0.5">
                            <span className="text-xs font-bold text-stone-700 block">Desktop Notification Banners</span>
                            <span className="text-[10px] text-stone-400 block max-w-[160px]">Trigger browser push cards when tab is in background.</span>
                          </div>
                          <input
                            type="checkbox"
                            checked={notifyDesktopEnabled}
                            onChange={handleToggleDesktopNotifications}
                            className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 border-stone-300"
                          />
                        </label>
                      </div>

                      <div className="pt-2 flex flex-wrap gap-2">
                        <button
                          onClick={playNotificationSound}
                          type="button"
                          className="bg-white hover:bg-stone-100 border border-stone-200 text-stone-700 font-bold px-3 py-1.5 rounded-lg text-[10px] flex items-center gap-1 transition-all cursor-pointer"
                        >
                          🎵 Test Ring chime
                        </button>
                        <button
                          onClick={handleToggleDesktopNotifications}
                          type="button"
                          className="bg-white hover:bg-stone-100 border border-stone-200 text-stone-700 font-bold px-3 py-1.5 rounded-lg text-[10px] flex items-center gap-1 transition-all cursor-pointer"
                        >
                          📳 Push Test
                        </button>
                      </div>
                    </div>

                    {/* Column 2: CallMeBot WhatsApp notifications */}
                    <div className="bg-stone-50/50 border border-stone-150 rounded-2xl p-4.5 space-y-4">
                      <div className="flex items-center gap-2 pb-1 border-b border-stone-200/70">
                        <MessageSquare className="h-4 w-4 text-emerald-600" />
                        <span className="text-xs font-bold text-stone-800 uppercase tracking-wider font-mono">2. Live WhatsApp Alerts</span>
                      </div>

                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-stone-700">Auto WhatsApp Alerts</span>
                          <input
                            type="checkbox"
                            checked={notifyWaEnabled}
                            onChange={(e) => setNotifyWaEnabled(e.target.checked)}
                            className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 border-stone-300"
                          />
                        </div>

                        <div className="space-y-1 text-[10px] text-stone-500 bg-amber-55/40 bg-amber-50/50 p-2 rounded-xl border border-amber-100">
                          <span className="font-bold flex items-center gap-0.5 text-stone-700 font-sans">
                            <HelpCircle className="h-3 w-3 text-amber-600" /> WhatsApp Direct Bot Link:
                          </span>
                          <ol className="list-decimal list-inside space-y-0.5 mt-0.5 text-stone-600 text-[9.5px]">
                            <li>Add contact: <b className="text-stone-850 font-mono">+34 644 65 30 17</b></li>
                            <li>Send text: <b className="text-stone-850 font-mono">I allow callmebot to send me messages</b></li>
                            <li>You will immediately receive your free custom API Key!</li>
                          </ol>
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div className="space-y-1">
                            <label className="text-[9px] font-bold text-stone-500 uppercase block">Owner Mobile *</label>
                            <input
                              type="text"
                              value={notifyWaPhone}
                              onChange={(e) => setNotifyWaPhone(e.target.value)}
                              placeholder="e.g. 919555761477"
                              className="w-full bg-white border border-stone-200 px-2 py-1.5 rounded-lg text-xs outline-hidden focus:border-emerald-600 font-mono"
                            />
                          </div>
                          <div className="space-y-1">
                            <label className="text-[9px] font-bold text-stone-500 uppercase block">Bot API Key *</label>
                            <input
                              type="text"
                              value={notifyWaApikey}
                              onChange={(e) => setNotifyWaApikey(e.target.value)}
                              placeholder="e.g. 123456"
                              className="w-full bg-white border border-stone-200 px-2 py-1.5 rounded-lg text-xs outline-hidden focus:border-emerald-600 font-mono"
                            />
                          </div>
                        </div>
                      </div>

                      <div className="pt-1">
                        <button
                          onClick={handleTestWhatsAppCallMeBot}
                          type="button"
                          className="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-bold px-3 py-1.5 rounded-lg text-[10px] flex items-center gap-1 transition-all cursor-pointer w-full justify-center"
                        >
                          💬 Send Test WhatsApp Message
                        </button>
                      </div>
                    </div>

                    {/* Column 3: Webhooks & REST API Integrations */}
                    <div className="bg-stone-50/50 border border-stone-150 rounded-2xl p-4.5 space-y-4">
                      <div className="flex items-center gap-2 pb-1 border-b border-stone-200/70">
                        <RefreshCw className="h-4 w-4 text-stone-600" />
                        <span className="text-xs font-bold text-stone-800 uppercase tracking-wider font-mono">3. Automated Webhooks</span>
                      </div>

                      <div className="space-y-3.5">
                        <div className="space-y-1.5">
                          <div className="flex items-center justify-between">
                            <label className="text-xs font-bold text-stone-700">Google Chat Webhook</label>
                            <input
                              type="checkbox"
                              checked={notifyGchatEnabled}
                              onChange={(e) => setNotifyGchatEnabled(e.target.checked)}
                              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-stone-300"
                            />
                          </div>
                          <input
                            type="text"
                            value={notifyGchatWebhook}
                            onChange={(e) => setNotifyGchatWebhook(e.target.value)}
                            placeholder="Paste Chat space incoming webhook URL..."
                            className="w-full bg-white border border-stone-200 px-2.5 py-1.5 rounded-lg text-[11px] outline-hidden focus:border-stone-400 font-mono truncate"
                          />
                        </div>

                        <div className="space-y-1.5 pt-1.5 border-t border-stone-150">
                          <div className="flex items-center justify-between">
                            <label className="text-xs font-bold text-stone-700">Custom Developer Webhook</label>
                            <input
                              type="checkbox"
                              checked={notifyCustomEnabled}
                              onChange={(e) => setNotifyCustomEnabled(e.target.checked)}
                              className="w-4 h-4 rounded text-stone-700 focus:ring-stone-500 border-stone-300"
                            />
                          </div>
                          <input
                            type="text"
                            value={notifyCustomWebhook}
                            onChange={(e) => setNotifyCustomWebhook(e.target.value)}
                            placeholder="Paste custom POST trigger endpoint URL..."
                            className="w-full bg-white border border-stone-200 px-2.5 py-1.5 rounded-lg text-[11px] outline-hidden focus:border-stone-400 font-mono truncate"
                          />
                        </div>
                      </div>

                      <div className="pt-1 flex gap-2">
                        <button
                          onClick={handleTestGoogleChatWebhookUrl}
                          type="button"
                          className="bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 font-bold px-3 py-1.5 rounded-lg text-[10px] flex items-center gap-1 transition-all cursor-pointer flex-1 justify-center"
                        >
                          🧪 Test Google Chat
                        </button>
                      </div>
                    </div>

                  </div>
                </div>

                {/* Database Reports Table */}
                <div className="bg-white border border-stone-200 rounded-3xl overflow-hidden shadow-3xs">
                  
                  <div className="p-4 bg-stone-50 border-b border-stone-200 flex flex-col sm:flex-row justify-between items-center gap-3 font-sans">
                    <div className="relative w-full sm:w-72">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-stone-400" />
                      <input
                        type="text"
                        value={adminSearch}
                        onChange={(e) => setAdminSearch(e.target.value)}
                        placeholder="Search Buyer name, phone, state..."
                        className="w-full bg-white border border-stone-200 pl-9 py-2 rounded-xl text-xs text-stone-850 outline-hidden focus:border-amber-650"
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <span className="text-[11px] font-semibold text-stone-400">Merchant Hub Session</span>
                      <button
                        onClick={handleAdminLogout}
                        className="bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 px-3 py-1.5 rounded-xl text-xs font-bold font-sans cursor-pointer transition-colors"
                      >
                        Sign Out Admin
                      </button>
                    </div>
                  </div>

                  <div className="overflow-x-auto text-left">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-stone-50 text-[10px] font-mono text-stone-500 uppercase tracking-wider border-b border-stone-200 leading-none">
                          <th className="py-4 px-4 font-bold">Order Ref</th>
                          <th className="py-4 px-4 font-bold">Placed Date</th>
                          <th className="py-4 px-4 font-bold">Item Sieve Type</th>
                          <th className="py-4 px-4 font-bold">Qty (250g)</th>
                          <th className="py-4 px-4 font-bold">Total Paid</th>
                          <th className="py-4 px-4 font-bold font-sans">Recipient Contact</th>
                          <th className="py-4 px-4 font-bold">GST Number</th>
                          <th className="py-4 px-4 font-bold col-pincode">Pincode</th>
                          <th className="py-4 px-4 font-bold">Delivery Address</th>
                          <th className="py-4 px-4 font-bold">Actions Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100 text-xs text-stone-700">
                        {filteredAdminOrders.length === 0 ? (
                          <tr>
                            <td colSpan={10} className="py-12 text-center text-stone-400 font-semibold font-sans">
                              No active client checkout logging reports created.
                            </td>
                          </tr>
                        ) : (
                          filteredAdminOrders.map((o) => (
                            <tr key={o.id} className="hover:bg-stone-50/50 transition-colors">
                              <td className="py-3 px-4 font-mono font-bold text-stone-900">{o.id}</td>
                              <td className="py-3 px-4 font-mono text-[11px] text-stone-405">{new Date(o.date).toLocaleDateString()}</td>
                              <td className="py-3 px-4 font-semibold text-stone-900">{o.productName}</td>
                              <td className="py-3 px-4 font-mono font-bold">{o.quantity} bags</td>
                              <td className="py-3 px-4 font-mono leading-normal">
                                <div className="text-emerald-800 font-bold">₹{o.totalPrice}/-</div>
                                {o.deliveryCharge !== undefined ? (
                                  <div className="text-[9px] text-stone-400 font-sans tracking-tight">
                                    Sub: ₹{o.subTotal ?? (o.totalPrice - o.deliveryCharge)} | Ship: ₹{o.deliveryCharge} ({o.state})
                                  </div>
                                ) : (
                                  <div className="text-[9px] text-stone-400 font-sans tracking-tight">
                                    All-inclusive Free
                                  </div>
                                )}
                              </td>
                              <td className="py-3 px-4">
                                <div className="text-left font-sans">
                                  <strong className="text-stone-950 block leading-tight">{o.customerName}</strong>
                                  <span className="font-mono text-stone-400 text-[11px] mt-0.5 block">{o.customerPhone}</span>
                                </div>
                              </td>
                              <td className="py-3 px-4 font-mono text-[11px]">
                                {o.gstNumber ? (
                                  <span className="bg-emerald-50 text-emerald-800 border border-emerald-205/60 px-2 py-0.5 rounded-md font-bold text-[10px] tracking-wide inline-block">
                                    {o.gstNumber}
                                  </span>
                                ) : (
                                  <span className="text-stone-300 italic text-[10px]">None Provided</span>
                                )}
                              </td>
                              <td className="py-3 px-4 font-mono font-bold text-stone-800">
                                {o.pincode}
                              </td>
                              <td className="py-3 px-4 max-w-xs truncate text-[11px] text-stone-500 font-semibold" title={o.address}>
                                {o.address}, {o.city} ({o.state})
                              </td>
                              <td className="py-3 px-4">
                                <select
                                  value={o.status}
                                  onChange={(e) => handleUpdateStatus(o.id, e.target.value as any)}
                                  className={`px-2 py-1 select-none text-[10px] font-bold rounded-lg border focus:outline-hidden cursor-pointer ${
                                    o.status === 'Delivered' 
                                      ? 'bg-emerald-50 text-emerald-800 border-emerald-250' 
                                      : o.status === 'Shipped' 
                                      ? 'bg-blue-50 text-blue-800 border-blue-200' 
                                      : o.status === 'Cancelled'
                                      ? 'bg-red-50 text-red-700 border-red-200'
                                      : 'bg-amber-50 text-amber-800 border-amber-250'
                                  }`}
                                >
                                  <option value="Pending">Pending</option>
                                  <option value="Shipped">Shipped Dispatch</option>
                                  <option value="Delivered">Delivered Done</option>
                                  <option value="Cancelled">Cancelled</option>
                                </select>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>

                </div>

              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
}
