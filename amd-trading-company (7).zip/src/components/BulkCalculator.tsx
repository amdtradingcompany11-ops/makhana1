/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { InquiryFormData } from '../types';
import { Scale, Phone, ArrowRight, MessageCircle, FileSpreadsheet, Building2, CheckCircle, Smartphone, Lock, Sparkles, Check } from 'lucide-react';

interface BulkCalculatorProps {
  preselectedSize?: string;
}

export default function BulkCalculator({ preselectedSize }: BulkCalculatorProps) {
  const [formData, setFormData] = useState<InquiryFormData>({
    name: '',
    phone: '',
    email: '',
    companyName: '',
    brand: 'shuddh',
    size: '5 Suta+',
    quantity: '1,000 kg (1 Ton)',
    requirement: '',
  });

  const [inquirySent, setInquirySent] = useState(false);
  const [generatedMessageText, setGeneratedMessageText] = useState('');
  
  // High quality elegant toast state matching ShopPage
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToastMessage = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
  };

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Handle preselected size updates from sizing guide
  useEffect(() => {
    if (preselectedSize) {
      setFormData(prev => ({
        ...prev,
        size: preselectedSize,
        // Upgrade to Premium Brand if they selected premium-only size
        brand: ['5 Suta+', '6 Suta+'].includes(preselectedSize) ? 'shuddh' : prev.brand
      }));
      // Smoothly scroll to the calculator card for desktop/mobile
      const el = document.getElementById('b2b-calculator-section');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  }, [preselectedSize]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const constructWhatsAppLink = (data: InquiryFormData) => {
    const brandName = data.brand === 'shuddh' 
      ? 'Shuddh Premium Makhana' 
      : data.brand === 'rozana' 
        ? 'Rozana Daily Makhana' 
        : 'Shuddh & Rozana Brands (Both)';

    const text = `Hello AMD Trading Company!\n\n` +
      `I would like to request a bulk wholesale price quote.\n\n` +
      `📋 *Bulk Inquiry Details:*\n` +
      `• Brand Interest: ${brandName}\n` +
      `• Size Preference: ${data.size}\n` +
      `• Required Qty: ${data.quantity}\n` +
      `• Company Name: ${data.companyName || 'Not Specified'}\n` +
      `• Contact Name: ${data.name}\n` +
      `• Tel / WhatsApp: ${data.phone}\n` +
      (data.email ? `• Email: ${data.email}\n` : '') +
      (data.requirement ? `• Specific Requirements: ${data.requirement}\n` : '') +
      `\nPlease provide your best wholesale pricing and dispatch timeline from Bihar. Thank you!`;

    return encodeURIComponent(text);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.phone) {
      showToastMessage("Please fill in your Name and Phone Number to request a quote.", "error");
      return;
    }

    const message = constructWhatsAppLink(formData);
    setGeneratedMessageText(message);
    setInquirySent(true);
    showToastMessage("Quotation compiled successfully! Transitioning to WhatsApp chat...", "success");
    
    // Auto launch WhatsApp in new tab
    setTimeout(() => {
      window.open(`https://wa.me/919555761477?text=${message}`, '_blank');
    }, 1200);
  };

  const handleWhatsAppRedirect = () => {
    if (generatedMessageText) {
      window.open(`https://wa.me/919555761477?text=${generatedMessageText}`, '_blank');
    }
  };

  const quantityOptions = [
    '100 kg to 250 kg (Sample Order)',
    '250 kg to 500 kg',
    '500 kg to 1,000 kg (1 Ton)',
    '1,000 kg to 2,000 kg (1-2 Tons)',
    '2,000 kg to 5,000 kg (2-5 Tons)',
    '5,000 kg+ (5+ Tons Bulk)',
    'Other (Fill description)'
  ];

  return (
    <div id="b2b-calculator-section" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch pt-2 relative">
      
      {/* Toast Notification for Bulk Bidding */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: -40, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-50 w-full max-w-sm px-4"
          >
            <div 
              onClick={() => setToast(null)}
              className={`p-4 rounded-2xl shadow-xl border flex items-start gap-3 backdrop-blur-md cursor-pointer hover:scale-101 transition-transform ${
                toast.type === 'success' 
                  ? 'bg-emerald-900 border-emerald-800 text-emerald-100 shadow-emerald-900/15' 
                  : toast.type === 'error' 
                    ? 'bg-rose-950 border-rose-900 text-rose-100 shadow-rose-950/15'
                    : 'bg-stone-900 border-stone-800 text-stone-100 shadow-stone-950/15'
              }`}
            >
              <div className={`p-1.5 rounded-lg shrink-0 ${
                toast.type === 'success' 
                  ? 'bg-emerald-800 text-emerald-300' 
                  : toast.type === 'error'
                    ? 'bg-rose-800 text-rose-300'
                    : 'bg-stone-800/80 text-amber-300'
              }`}>
                {toast.type === 'success' ? <Check className="h-4 w-4" /> : toast.type === 'error' ? <Lock className="h-4 w-4" /> : <Sparkles className="h-4 w-4" />}
              </div>
              <div className="text-left space-y-0.5">
                <p className="text-xs font-bold tracking-wider uppercase leading-none font-sans">
                  {toast.type === 'success' ? 'Task Succeeded' : toast.type === 'error' ? 'Warning / Error' : 'System Notice'}
                </p>
                <p className="text-[11px] leading-relaxed opacity-90">{toast.message}</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Interactive Form Card */}
      <div className="lg:col-span-7 bg-white rounded-3xl border border-stone-200 shadow-xs p-6 sm:p-8 flex flex-col justify-between">
        <div>
          <span className="flex items-center space-x-1 text-xs font-semibold text-emerald-800 tracking-wider uppercase mb-1">
            <Scale className="h-4 w-4" />
            <span>Fast Estimate Dispatch Inquiry</span>
          </span>
          <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 mb-2">
            Build Bulk Quote Request
          </h3>
          <p className="text-sm text-stone-500 mb-6 leading-relaxed">
            Fill out your cargo needs. Our pricing engine processes the active mandis rates directly to offer competitive wholesale prices.
          </p>

          <form onSubmit={handleFormSubmit} className="space-y-4">
            
            {/* Split Grid for name & Phone */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                  Contact Person Name *
                </label>
                <input
                  type="text"
                  name="name"
                  required
                  placeholder="e.g. Ramesh Kumar"
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900 font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                  Mobile / WhatsApp Number *
                </label>
                <input
                  type="tel"
                  name="phone"
                  required
                  placeholder="e.g. +91 9876543210"
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900 font-medium"
                />
              </div>
            </div>

            {/* Split Grid for Company and Email */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1 flex items-center space-x-1">
                  <Building2 className="nav-item h-3.5 w-3.5 text-stone-400" />
                  <span>Shop / Company Name (Optional)</span>
                </label>
                <input
                  type="text"
                  name="companyName"
                  placeholder="e.g. Kumar Provisions"
                  value={formData.companyName}
                  onChange={handleChange}
                  className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                  Email Address (Optional)
                </label>
                <input
                  type="email"
                  name="email"
                  placeholder="e.g. ramesh@prov.com"
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900"
                />
              </div>
            </div>

            <div className="border-t border-stone-200/50 my-2 pt-2"></div>

            {/* Brand and Sizing Preferences */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                  Select Makhana Brand Segment
                </label>
                <select
                  name="brand"
                  value={formData.brand}
                  onChange={handleChange}
                  className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900 font-medium"
                >
                  <option value="shuddh">Shuddh Premium Makhana (Large Grades)</option>
                  <option value="rozana">Rozana Makhana (Value/Daily Grades)</option>
                  <option value="both">Both Brands (Mix Procurement)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                  Required Sizing Caliber
                </label>
                <select
                  name="size"
                  value={formData.size}
                  onChange={handleChange}
                  className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900 font-medium"
                >
                  <option value="6 Suta+">6 Suta+ (Jumbo King Elite - Over 19.05 mm)</option>
                  <option value="5 Suta+">5 Suta+ (Shuddh Gold XL - 15.87-19.05 mm)</option>
                  <option value="5 Suta">5 Suta (Standard Sorter Premium - Exactly 15.87 mm)</option>
                  <option value="4 Suta+">4 Suta+ (Classic Sorted Plus - 12.70-15.87 mm)</option>
                  <option value="4 Suta">4 Suta (Retail Pack Standard - Exactly 12.70 mm)</option>
                  <option value="3 Suta+">3 Suta+ (Mixed Wholesome Economy - 9.52-12.70 mm)</option>
                  <option value="3 Suta">3 Suta (Eco-Value Daily Compact - Exactly 9.52 mm)</option>
                  <option value="Mixed Sizing">Custom Sorted Sizing Mix</option>
                </select>
              </div>
            </div>

            {/* Volume Picker and Special Request */}
            <div>
              <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                Estimated Order Quantity
              </label>
              <select
                name="quantity"
                value={formData.quantity}
                onChange={handleChange}
                className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900 font-medium"
              >
                {quantityOptions.map((opt) => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 uppercase tracking-wider mb-1">
                Special Delivery Needs / Remarks (Optional)
              </label>
              <textarea
                name="requirement"
                rows={3}
                placeholder="e.g. Need private white labeling bags, dispatch by next week to South India, or customized PP packing instructions."
                value={formData.requirement}
                onChange={handleChange}
                className="w-full bg-stone-50 border border-stone-200 focus:border-emerald-600 focus:bg-white rounded-xl px-4 py-3 text-sm transition-all outline-hidden text-stone-900"
              />
            </div>

            {/* Submit Banner Button */}
            <button
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold font-sans py-3.5 px-4 rounded-xl shadow-xs hover:shadow-md transition-all duration-200 hover:-translate-y-0.5 flex items-center justify-center space-x-2.5 text-base cursor-pointer"
            >
              <MessageCircle className="h-5 w-5 fill-current" />
              <span>Submit & Open WhatsApp Inquiry</span>
            </button>
          </form>
        </div>

        <p className="text-center text-[11px] text-stone-400 mt-4 leading-normal">
          🔒 By submitting, the configuration redirects to WhatsApp. We respect privacy — zero spam. Actual dispatch quotes directly via official AMD Trading mandis operators.
        </p>
      </div>

      {/* Corporate Invoicing Visualizer Sheet */}
      <div className="lg:col-span-5 flex flex-col justify-between bg-stone-900 rounded-3xl border border-stone-800 p-6 sm:p-8 text-stone-300 relative overflow-hidden">
        
        {/* Background ambient accent */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-700/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-amber-700/5 rounded-full blur-3xl pointer-events-none"></div>

        <div className="space-y-6 relative z-10">
          <div className="border-b border-stone-800 pb-4">
            <span className="bg-emerald-950 text-emerald-400 border border-emerald-900 text-[10px] font-mono tracking-widest uppercase px-2.5 py-1 rounded-full inline-block">
              LIVE B2B Spec Worksheet
            </span>
            <div className="flex items-center space-x-2 mt-2">
              <FileSpreadsheet className="h-5 w-5 text-stone-500" />
              <h4 className="font-serif text-lg font-semibold text-white">Estimated Inquiry Overview</h4>
            </div>
          </div>

          {/* Worksheet Parameters list */}
          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between py-1 border-b border-stone-800/60">
              <span className="text-stone-500">PRODUCER:</span>
              <span className="text-stone-300 font-semibold">AMD TRADING CO.</span>
            </div>
            <div className="flex justify-between py-1 border-b border-stone-800/60">
              <span className="text-stone-500">SOURCE:</span>
              <span className="text-stone-300 font-semibold">BIHAR FARMLANDS HARVEST</span>
            </div>
            <div className="flex justify-between py-1 border-b border-stone-800/60">
              <span className="text-stone-500">CLIENT SEGMENT:</span>
              <span className="text-white font-semibold">
                {formData.companyName ? formData.companyName.toUpperCase() : 'WHOLESALE BUYER'}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-stone-800/60">
              <span className="text-stone-500">BRAND LINEUP:</span>
              <span className="text-emerald-400 font-bold uppercase">
                {formData.brand === 'shuddh' ? 'SHUDDH PREMIUM' : formData.brand === 'rozana' ? 'ROZANA COMS' : 'COMBINED DEALS'}
              </span>
            </div>
            <div className="flex justify-between py-1 border-b border-stone-800/60">
              <span className="text-stone-500">SIZE PREF:</span>
              <span className="text-stone-200 font-semibold">{formData.size}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-stone-800/60">
              <span className="text-stone-500">INQUIRY VOLUME:</span>
              <span className="text-amber-500 font-bold">{formData.quantity}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-stone-800/60">
              <span className="text-stone-500">HYGIENE STATUS:</span>
              <span className="text-emerald-500 font-semibold">DOUBLE SORTED & SIEVED</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-stone-500">MOISTURE RATING:</span>
              <span className="text-stone-300">&lt; 5.0% EX-WAREHOUSE</span>
            </div>
          </div>

          {/* Value props checklist inside quote sheet */}
          <div className="bg-stone-800/40 border border-stone-800 rounded-2xl p-4 space-y-2.5">
            <span className="text-[10px] font-mono tracking-wider uppercase text-stone-500 block">AMD Trading Guarantee</span>
            
            <div className="flex items-start space-x-2.5 text-xs text-stone-300">
              <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>Stable bulk supply even during festival peaks and off-season cycles.</span>
            </div>
            <div className="flex items-start space-x-2.5 text-xs text-stone-300">
              <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>Moisture protection packaging preventing puff decay.</span>
            </div>
            <div className="flex items-start space-x-2.5 text-xs text-stone-300">
              <CheckCircle className="h-4 w-4 text-emerald-500 shrink-0 mt-0.5" />
              <span>Transparent weighment terms and batch-wise quality inspections.</span>
            </div>
          </div>
        </div>

        {/* Status display or quick contact hook */}
        <div className="mt-8 pt-6 border-t border-stone-800 space-y-3.5">
          {inquirySent ? (
            <div className="p-4 bg-emerald-950/60 border border-emerald-900 rounded-2xl text-center space-y-3">
              <div className="h-10 w-10 bg-emerald-500 rounded-full flex items-center justify-center mx-auto text-stone-900 font-bold text-lg">
                ✓
              </div>
              <div>
                <p className="text-sm font-semibold text-white">Draft Quote Generated!</p>
                <p className="text-xs text-stone-400 mt-1">Opening WhatsApp link now. If it didn't open automatically, click button below:</p>
              </div>
              <button
                type="button"
                onClick={handleWhatsAppRedirect}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-stone-900 font-bold text-xs py-2 px-3 rounded-lg flex items-center justify-center space-x-1.5 transition-colors cursor-pointer"
              >
                <Smartphone className="h-4 w-4 text-stone-900 fill-current" />
                <span>Launch Chat Directly</span>
              </button>
            </div>
          ) : (
            <div className="flex flex-col sm:flex-row justify-between items-center bg-stone-950 border border-stone-800 p-4 rounded-2xl gap-3">
              <div>
                <span className="text-[10px] text-stone-500 font-mono block">DO YOU WANT DIRECT RATES?</span>
                <span className="text-xs font-semibold text-white">Dial Mandi Sales Incharge:</span>
              </div>
              <a
                href="tel:+919555761477"
                className="shrink-0 flex items-center space-x-1.5 bg-stone-800 hover:bg-emerald-700 text-white font-medium text-xs px-3.5 py-2 rounded-lg border border-stone-700 hover:border-emerald-500 transition-all cursor-pointer"
              >
                <Phone className="h-3.5 w-3.5" />
                <span>+91 9555761477</span>
              </a>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
