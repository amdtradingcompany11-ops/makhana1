/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ActivePage } from '../types';
import { Menu, X, Leaf, MessageCircle, Phone } from 'lucide-react';

interface NavbarProps {
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
}

export default function Navbar({ activePage, setActivePage }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);

  // WhatsApp click handler
  const handleWhatsAppNav = () => {
    const text = encodeURIComponent("Hello AMD Trading Company! I am visiting your website and would like to inquire about bulk makhana supplies.");
    window.open(`https://wa.me/919555761477?text=${text}`, '_blank');
  };

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'products', label: 'Products & Sizing' },
    { id: 'shop', label: 'Shop / Retail 🛒' },
    { id: 'about', label: 'About Us' },
    { id: 'why-choose-us', label: 'Why Choose Us' },
    { id: 'contact', label: 'Bulk Inquiry' },
    { id: 'workspace-chat', label: 'Google Chat 💬' }
  ] as const;

  const navigate = (page: ActivePage) => {
    setActivePage(page);
    setIsOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav id="app-navbar" className="sticky top-0 z-50 bg-white border-b border-stone-200/80 backdrop-blur-md bg-opacity-95 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          
          {/* Logo Brand Title */}
          <div className="flex items-center space-x-2 cursor-pointer" onClick={() => navigate('home')}>
            <div className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-100 flex items-center justify-center">
              <Leaf className="h-6 w-6 text-emerald-700" />
            </div>
            <div>
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-stone-900 block leading-tight">
                AMD <span className="text-emerald-700 font-sans font-semibold text-lg sm:text-xl">Trading Co.</span>
              </span>
              <span className="text-[10px] sm:text-xs text-emerald-800 font-mono tracking-wider font-semibold uppercase block -mt-0.5">
                Premium Makhana | FSSAI No. 20826004001411
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`px-3 lg:px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 cursor-pointer ${
                  activePage === item.id
                    ? 'text-emerald-800 bg-emerald-50 border border-emerald-100/30 font-semibold'
                    : 'text-stone-600 hover:text-emerald-700 hover:bg-stone-50'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Direct Actions */}
          <div className="hidden md:flex items-center space-x-3">
            <button
              onClick={handleWhatsAppNav}
              className="flex items-center space-x-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-sm transition-all duration-200 hover:-translate-y-0.5 cursor-pointer"
            >
              <MessageCircle className="h-4.5 w-4.5 fill-current" />
              <span>WhatsApp Chat</span>
            </button>
            
            <a
              href="tel:+919555761477"
              className="flex items-center space-x-1.5 border border-stone-200 hover:border-emerald-300 text-stone-700 hover:text-emerald-800 px-4 py-2 rounded-lg text-sm font-medium bg-stone-50 transition-all duration-200 cursor-pointer"
            >
              <Phone className="h-4 w-4" />
              <span>Call Direct</span>
            </a>
          </div>

          {/* Mobile Hamburguer Menu */}
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 rounded-lg text-stone-600 hover:bg-stone-100 focus:outline-hidden cursor-pointer"
              aria-label="Toggle Menu"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="md:hidden border-t border-stone-100 bg-white">
          <div className="px-2 pt-3 pb-5 space-y-1.5 shadow-lg">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                className={`w-full text-left px-4 py-3 rounded-xl text-base font-medium transition-all duration-150 cursor-pointer ${
                  activePage === item.id
                    ? 'bg-emerald-50 text-emerald-800 border-l-4 border-emerald-600 font-semibold pl-3'
                    : 'text-stone-700 hover:bg-stone-50 pl-4'
                }`}
              >
                {item.label}
              </button>
            ))}

            <div className="pt-4 px-3 border-t border-stone-100 flex flex-col space-y-2">
              <button
                onClick={handleWhatsAppNav}
                className="w-full flex items-center justify-center space-x-2 bg-emerald-600 hover:bg-emerald-700 text-white py-3 px-4 rounded-xl text-sm font-medium font-semibold shadow-sm cursor-pointer"
              >
                <MessageCircle className="h-4 w-4 fill-current" />
                <span>WhatsApp Bulk Rates</span>
              </button>
              
              <a
                href="tel:+919555761477"
                className="w-full flex items-center justify-center space-x-2 border border-stone-200 text-stone-800 py-3 px-4 rounded-xl text-sm font-medium bg-stone-50 cursor-pointer"
              >
                <Phone className="h-4 w-4" />
                <span>Call +91 95557 61477</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
