/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SIZES } from '../data/makhanaData';
import { Ruler, ShieldCheck, ArrowRight, Search, CircleCheck } from 'lucide-react';
import { MakhanaSize } from '../types';

interface SizeGuideProps {
  onQuoteRequest: (size: string) => void;
}

export default function SizeGuide({ onQuoteRequest }: SizeGuideProps) {
  const [activeSize, setActiveSize] = useState<string>('5 Suta+');

  const selectedSizeData = SIZES.find(s => s.size === activeSize) || SIZES[0];

  // Visual puff scale generator based on size names
  const getPuffSizeClass = (sizeStr: string) => {
    switch (sizeStr) {
      case '6 Suta+': return 'w-24 h-24 sm:w-28 sm:h-28 bg-white border-4 border-amber-600 shadow-md';
      case '5 Suta+': return 'w-21 h-21 sm:w-23 sm:h-23 bg-white border-4 border-amber-500 shadow-xs';
      case '5 Suta': return 'w-19.5 h-19.5 sm:w-21.5 sm:h-21.5 bg-stone-50 border-2 border-stone-300';
      case '4 Suta+': return 'w-17 w-17 sm:w-19 sm:h-19 bg-stone-50 border-2 border-stone-300';
      case '4 Suta': return 'w-15 h-15 sm:w-16.5 sm:h-16.5 bg-stone-50 border-2 border-stone-300';
      case '3 Suta+': return 'w-12 h-12 sm:w-13.5 sm:h-13.5 bg-stone-100 border border-stone-400';
      case '3 Suta': return 'w-10 h-10 sm:w-11 sm:h-11 bg-stone-100 border border-stone-400';
      default: return 'w-16 h-16 bg-white';
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-stone-200/90 shadow-sm overflow-hidden">
      <div className="p-6 sm:p-8 bg-stone-50 border-b border-stone-200/60">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="flex items-center space-x-1.5 text-xs font-semibold text-emerald-700 tracking-wider uppercase mb-1">
              <Ruler className="h-4 w-4" />
              <span>Standardized B2B Calibration Guide</span>
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900">
              Interactive Sizing & Traditional Suta Scale
            </h3>
            <p className="text-sm text-stone-500 mt-2.5 max-w-2xl leading-relaxed">
              We process, sort, and deliver makhana using both modern millimeter calipers and the traditional Indian <strong>Suta (Suti)</strong> grading system, where <strong>1 Suta equals 1/8 inch (approximately 3.175 mm)</strong>. A higher Suta count indicates exponentially larger, premium puff expansion.
            </p>
          </div>
          <div className="bg-emerald-50 border border-emerald-100/70 p-3 rounded-xl flex items-center space-x-3.5 max-w-sm shrink-0">
            <span className="text-2xl">⚡</span>
            <div>
              <p className="text-xs font-semibold text-emerald-900">100% Sortex Cleaned</p>
              <p className="text-[11px] text-emerald-700 leading-tight">Every batch is metal-detected & free of black nutshell decortication residue.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12">
        
        {/* Sizing Selector List */}
        <div className="lg:col-span-12 xl:col-span-5 border-b lg:border-b-0 lg:border-r border-stone-200 divide-y divide-stone-100">
          <div className="p-3 bg-stone-100/50 text-[11px] font-mono font-semibold tracking-wider uppercase px-5 text-stone-500 flex justify-between items-center">
            <span>Sieve Screen Size</span>
            <span>Grade Names</span>
          </div>
          {SIZES.map((item) => (
            <button
              key={item.size}
              onClick={() => setActiveSize(item.size)}
              className={`w-full text-left px-5 py-4 sm:py-5 flex items-center justify-between transition-all duration-150 cursor-pointer ${
                activeSize === item.size
                  ? 'bg-emerald-50/50 border-l-4 border-emerald-700 pl-4'
                  : 'hover:bg-stone-50/60'
               }`}
            >
              <div className="flex items-center space-x-4">
                <span className={`text-base font-bold font-mono tracking-tight ${
                  activeSize === item.size ? 'text-emerald-800 animate-pulse' : 'text-stone-800'
                }`}>
                  {item.size}
                </span>
                <span className="text-xs bg-stone-100 border border-stone-200 font-medium px-2 py-0.5 rounded-full text-stone-600">
                  {item.diameter}
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`text-xs font-semibold ${
                  activeSize === item.size ? 'text-emerald-950 font-bold' : 'text-stone-500'
                }`}>
                  {item.premiumGrades[0]}
                </span>
                <ArrowRight className={`h-4 w-4 transition-transform ${
                  activeSize === item.size ? 'text-emerald-700 translate-x-1' : 'text-stone-300'
                }`} />
              </div>
            </button>
          ))}
        </div>

        {/* Selected Size Detail Display */}
        <div className="lg:col-span-12 xl:col-span-7 p-6 sm:p-10 flex flex-col justify-between bg-stone-50/30">
          
          <div className="space-y-6">
            
            {/* Visual circle preview */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 pb-6 border-b border-stone-200/50">
              <div className="relative shrink-0 flex items-center justify-center bg-radial from-white to-stone-50 rounded-2xl w-36 h-36 border border-stone-200 shadow-xs">
                {/* Simulated Foxnut circle representation */}
                <div className={`${getPuffSizeClass(selectedSizeData.size)} rounded-full flex flex-col items-center justify-center transition-all duration-300`}>
                  <span className="text-xs font-mono font-bold text-stone-800">{selectedSizeData.size}</span>
                  <span className="text-[9px] text-stone-400 font-medium font-mono">1/8" × {selectedSizeData.size.replace(/\D/g, '')}</span>
                </div>
                {/* Sizing ruler overlays */}
                <div className="absolute bottom-2 left-2 right-2 flex justify-between px-1 text-[8px] font-mono text-stone-400 border-t border-dashed border-stone-300 pt-0.5">
                  <span>0 mm</span>
                  <span>{selectedSizeData.size} screen scale</span>
                </div>
              </div>

              <div className="text-center sm:text-left space-y-1">
                <div className="flex flex-wrap justify-center sm:justify-start items-center gap-2">
                  <span className="bg-amber-100 text-amber-800 text-xs font-bold px-2.5 py-0.5 rounded-full border border-amber-200/80 shadow-2xs">
                    {selectedSizeData.premiumGrades[0]}
                  </span>
                  {selectedSizeData.premiumGrades[1] && (
                    <span className="bg-stone-200/80 text-stone-700 text-xs font-medium px-2 py-0.5 rounded-full">
                      {selectedSizeData.premiumGrades[1]}
                    </span>
                  )}
                </div>
                <h4 className="font-serif text-2xl font-bold text-stone-900 mt-1">
                  Grade Size: {selectedSizeData.size}
                </h4>
                <p className="text-xs text-stone-500 font-mono">
                  Calibrated Diameter Range: <strong className="text-stone-800 font-semibold">{selectedSizeData.diameter}</strong>
                </p>
              </div>
            </div>

            {/* Industrial info */}
            <div className="space-y-4">
              <div>
                <p className="text-xs font-semibold text-stone-500 uppercase tracking-widest font-mono">Size Description</p>
                <p className="text-stone-700 text-sm sm:text-base leading-relaxed mt-1">
                  {selectedSizeData.description}
                </p>
              </div>

              <div className="p-4 bg-white border border-stone-200 rounded-2xl space-y-2">
                <p className="text-xs font-bold text-emerald-800 flex items-center space-x-1">
                  <CircleCheck className="h-4 w-4 shrink-0 text-emerald-600" />
                  <span>Strategic Industrial B2B Applications</span>
                </p>
                <p className="text-stone-600 text-xs sm:text-sm leading-relaxed pl-5">
                  {selectedSizeData.bestFor}
                </p>
              </div>
            </div>

          </div>

          <div className="mt-8 pt-6 border-t border-stone-200/50 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-stone-500 text-center sm:text-left">
              <span className="font-semibold text-stone-700 block">Supply Logistics:</span>
              Moisture: &lt; 5% | Packaging: 10kg/15kg bulk PP bags or custom boxes.
            </div>
            
            <button
              onClick={() => onQuoteRequest(selectedSizeData.size)}
              className="w-full sm:w-auto bg-stone-900 hover:bg-emerald-900 text-white font-medium text-xs sm:text-sm tracking-wide px-5 py-3 rounded-xl shadow-xs transition-all duration-150 hover:-translate-y-0.5 flex items-center justify-center space-x-2 font-semibold uppercase cursor-pointer"
            >
              <span>Get Bulk Quote for {selectedSizeData.size}</span>
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>

        </div>

      </div>
    </div>
  );
}
